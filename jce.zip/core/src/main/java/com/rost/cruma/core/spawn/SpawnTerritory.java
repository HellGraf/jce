package com.rost.cruma.core.spawn;

import java.util.List;

public record SpawnTerritory(
        int index,
        String name,
        boolean domain,
        int domainId,
        List<TerritoryPoint> points,
        int line,
        SourceSpan span,
        SourceSpan nameSpan,
        SourceSpan pointsSpan) {
    public SpawnTerritory {
        points = List.copyOf(points);
    }

    public SpawnTerritory withPoints(List<TerritoryPoint> newPoints) {
        return new SpawnTerritory(index, name, domain, domainId, newPoints, line, span, nameSpan, pointsSpan);
    }

    public SpawnTerritory withName(String newName) {
        return new SpawnTerritory(index, newName, domain, domainId, points, line, span, nameSpan, pointsSpan);
    }

    public int bottom() {
        var bottom = Integer.MAX_VALUE;
        for (var point : points) {
            bottom = Math.min(bottom, point.bottom());
        }
        return points.isEmpty() ? 0 : bottom;
    }

    public int top() {
        var top = Integer.MIN_VALUE;
        for (var point : points) {
            top = Math.max(top, point.top());
        }
        return points.isEmpty() ? 0 : top;
    }

    public int minX() {
        return points.stream().mapToInt(TerritoryPoint::x).min().orElse(0);
    }

    public int maxX() {
        return points.stream().mapToInt(TerritoryPoint::x).max().orElse(0);
    }

    public int minY() {
        return points.stream().mapToInt(TerritoryPoint::y).min().orElse(0);
    }

    public int maxY() {
        return points.stream().mapToInt(TerritoryPoint::y).max().orElse(0);
    }

    public boolean containsXy(double x, double y) {
        var inside = false;
        var count = points.size();
        for (var current = 0; current < count; current++) {
            var first = points.get(current);
            var second = points.get(current + 1 == count ? 0 : current + 1);
            if ((first.y() < y && y <= second.y() || second.y() < y && y <= first.y())
                    && (double) (second.x() - first.x()) * (y - first.y()) / (second.y() - first.y()) < x - first.x()) {
                inside = !inside;
            }
        }
        return inside;
    }

    public boolean reaches(double minX, double minY, double maxX, double maxY) {
        return insideCorners(minX, minY, maxX, maxY) > 0 || crosses(minX, minY, maxX, maxY);
    }

    public boolean covers(double minX, double minY, double maxX, double maxY) {
        return insideCorners(minX, minY, maxX, maxY) == 4 && !crosses(minX, minY, maxX, maxY);
    }

    public boolean contains(double x, double y, double z) {
        var height = (int) z;
        return height >= bottom() && height <= top() && containsXy(x, y);
    }

    public double area() {
        var sum = 0.0;
        var count = points.size();
        for (int i = 0, j = count - 1; i < count; j = i++) {
            sum += (double) points.get(j).x() * points.get(i).y()
                    - (double) points.get(i).x() * points.get(j).y();
        }
        return Math.abs(sum) / 2.0;
    }

    public double centerX() {
        return points.stream().mapToInt(TerritoryPoint::x).average().orElse(0);
    }

    public double centerY() {
        return points.stream().mapToInt(TerritoryPoint::y).average().orElse(0);
    }

    private int insideCorners(double minX, double minY, double maxX, double maxY) {
        var inside = 0;
        inside += containsXy(minX, minY) ? 1 : 0;
        inside += containsXy(maxX, minY) ? 1 : 0;
        inside += containsXy(maxX, maxY) ? 1 : 0;
        inside += containsXy(minX, maxY) ? 1 : 0;
        return inside;
    }

    private boolean crosses(double minX, double minY, double maxX, double maxY) {
        var count = points.size();
        for (var current = 0; current < count; current++) {
            var first = points.get(current);
            var second = points.get(current + 1 == count ? 0 : current + 1);
            if (meets(first, second, minX, minY, maxX, maxY)) {
                return true;
            }
        }
        return false;
    }

    private static boolean meets(
            TerritoryPoint first, TerritoryPoint second, double minX, double minY, double maxX, double maxY) {
        double dx = second.x() - first.x();
        double dy = second.y() - first.y();
        double[] steps = {-dx, dx, -dy, dy};
        double[] rooms = {first.x() - minX, maxX - first.x(), first.y() - minY, maxY - first.y()};
        var enters = 0.0;
        var leaves = 1.0;
        for (var side = 0; side < steps.length; side++) {
            if (steps[side] == 0) {
                if (rooms[side] < 0) {
                    return false;
                }
            } else if (steps[side] < 0) {
                enters = Math.max(enters, rooms[side] / steps[side]);
            } else {
                leaves = Math.min(leaves, rooms[side] / steps[side]);
            }
        }
        return enters <= leaves;
    }
}
