package com.rost.cruma.core.unreal;

import com.rost.cruma.core.unreal.UMeshAnimSequences.Checks;
import glm_.vec3.Vec3;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public final class UMeshAnimation extends UObject {
    private int version;
    private NamedBone[] bones = new NamedBone[0];
    private final List<byte[]> chunks = new ArrayList<>();
    private Sequence[] sequences = new Sequence[0];

    public UMeshAnimation(UArchive archive) {
        super(archive);
    }

    public record NamedBone(String name, int parentIndex) {}

    public record Sequence(
            String name, int startFrame, int frameCount, float rate, float shotTime, List<CameraMark> cameraMarks) {
        public Sequence {
            cameraMarks = List.copyOf(cameraMarks);
        }

        public Sequence(String name, int startFrame, int frameCount, float rate) {
            this(name, startFrame, frameCount, rate, -1f, List.of());
        }
    }

    public record CameraMark(
            float time, Kind kind, int bone, String pawnSequence, float pawnScale, Vec3 pawnOffset, boolean ownCamera) {
        public enum Kind {
            RELEASE,
            AROUND_BONE,
            ON_BONE,
            BONE_TO_BONE,
            CAMERA_PAWN;

            static Kind of(int value) {
                return value > 0 && value < values().length ? values()[value] : RELEASE;
            }
        }
    }

    public record Track(float[] quaternions, float[] positions, float[] times) {
        public int quaternionKeys() {
            return quaternions.length / 4;
        }

        public int positionKeys() {
            return positions.length / 3;
        }
    }

    public record Motion(float trackTime, Track[] tracks) {}

    @Override
    public void deserialize() {
        super.deserialize();
        version = archive.readInt();
        bones = archive.readArray(NamedBone.class, in -> {
            var name = in.readName();
            in.readInt();
            return new NamedBone(name, in.readInt());
        });
        var header = archive.getHeader();
        if (header.getFileVersion() > 122 && header.getLicenseVersion() > 24) {
            var end = archive.readInt();
            var count = archive.readIndex();
            requireCount("motion chunks", count);
            for (var i = 0; i < count; i++) {
                var chunkEnd = archive.readInt();
                var start = archive.getOffset();
                if (chunkEnd < start || chunkEnd > end) {
                    throw malformedException(
                            "motion chunk " + i + " ends at " + chunkEnd + " outside " + start + ".." + end);
                }
                chunks.add(readBytes(start, chunkEnd - start));
                archive.setPosition(chunkEnd);
            }
            archive.setPosition(end);
        } else {
            var count = archive.readIndex();
            requireCount("motion chunks", count);
            for (var i = 0; i < count; i++) {
                var start = archive.getOffset();
                skipMotion();
                chunks.add(readBytes(start, archive.getOffset() - start));
            }
        }
        var checks = new Checks() {
            @Override
            public void remaining(String label, int bytes) {
                if (bytes < 0 || archive.getRemainingInObject() < bytes) {
                    throw malformedException("truncated " + label);
                }
            }

            @Override
            public void count(String label, int count) {
                requireCount(label, count);
            }
        };
        var sequenceCount = archive.readIndex();
        requireCount("sequences", sequenceCount);
        sequences = new Sequence[sequenceCount];
        for (var i = 0; i < sequenceCount; i++) {
            var sequence = UMeshAnimSequences.read(archive, checks);
            sequences[i] = new Sequence(
                    sequence.name(),
                    sequence.startFrame(),
                    sequence.frameCount(),
                    sequence.rate(),
                    sequence.shotTime(),
                    sequence.cameraMarks());
        }
    }

    public int findSequenceIndex(String name) {
        for (var i = 0; i < sequences.length; i++) {
            if (sequences[i].name().equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    public Motion decodeMotion(int sequence) {
        if (sequence < 0 || sequence >= chunks.size()) {
            throw new IndexOutOfBoundsException("sequence " + sequence + " of " + chunks.size());
        }
        var data = ByteBuffer.wrap(chunks.get(sequence)).order(ByteOrder.LITTLE_ENDIAN);
        data.position(12);
        var trackTime = data.getFloat();
        data.getInt();
        data.getInt();
        var boneIndices = compactIndex(data);
        data.position(data.position() + boneIndices * 4);
        var trackCount = compactIndex(data);
        var tracks = new Track[trackCount];
        for (var i = 0; i < trackCount; i++) {
            tracks[i] = track(data);
        }
        return new Motion(trackTime, tracks);
    }

    public int getVersion() {
        return version;
    }

    public NamedBone[] getBones() {
        return bones;
    }

    public Sequence[] getSequences() {
        return sequences;
    }

    private byte[] readBytes(int start, int length) {
        var saved = archive.getOffset();
        archive.setPosition(start);
        var data = new byte[length];
        for (var i = 0; i < length; i++) {
            data[i] = archive.readByte();
        }
        archive.setPosition(saved);
        return data;
    }

    private void skipMotion() {
        archive.skipBytes(12 + 4 + 4 + 4);
        skipArray(4);
        var tracks = archive.readIndex();
        requireCount("tracks", tracks);
        for (var i = 0; i <= tracks; i++) {
            archive.readInt();
            skipArray(16);
            skipArray(12);
            skipArray(4);
        }
    }

    private void skipArray(int elementSize) {
        var count = archive.readIndex();
        requireCount("keys", count);
        archive.skipBytes(Math.multiplyExact(count, elementSize));
    }

    private void requireCount(String label, int count) {
        if (count < 0 || count > 4_000_000) {
            throw malformedException("invalid " + label + " count " + count);
        }
    }

    private IllegalStateException malformedException(String detail) {
        return new IllegalStateException("Malformed MeshAnimation " + getName() + ": " + detail);
    }

    private static Track track(ByteBuffer data) {
        data.getInt();
        var quaternions = readFloats(data, 4);
        var positions = readFloats(data, 3);
        var times = readFloats(data, 1);
        return new Track(quaternions, positions, times);
    }

    private static float[] readFloats(ByteBuffer data, int perKey) {
        var count = compactIndex(data);
        if (count < 0 || count * perKey * 4 > data.remaining()) {
            throw new IllegalStateException("Malformed animation keys: " + count);
        }
        var values = new float[count * perKey];
        for (var i = 0; i < values.length; i++) {
            values[i] = data.getFloat();
        }
        return values;
    }

    private static int compactIndex(ByteBuffer data) {
        var first = data.get() & 0xff;
        var negative = (first & 0x80) != 0;
        var value = first & 0x3f;
        if ((first & 0x40) != 0) {
            var shift = 6;
            int next;
            do {
                next = data.get() & 0xff;
                value |= (next & 0x7f) << shift;
                shift += 7;
            } while ((next & 0x80) != 0 && shift < 32);
        }
        return negative ? -value : value;
    }
}
