package com.rost.cruma.core.editing;

import static com.rost.cruma.core.editing.PackageBytes.littleEndian;
import static com.rost.cruma.core.editing.PackageBytes.malformed;
import static com.rost.cruma.core.editing.PackageBytes.writeIndex;
import static com.rost.cruma.core.editing.PackageBytes.writeInt;

import com.rost.cruma.core.editing.ActorLightingChanges.Actor;
import com.rost.cruma.core.editing.ActorLightingChanges.BeastTexture;
import com.rost.cruma.core.editing.ActorLightingChanges.Instance;
import com.rost.cruma.core.editing.ActorLightingChanges.Light;
import com.rost.cruma.core.editing.ActorTransform.Rotator;
import com.rost.cruma.core.editing.ActorTransform.Vector3;
import com.rost.cruma.core.editing.BeastTextureCodec.Saved;
import com.rost.cruma.core.editing.BeastTextureCodec.Template;
import com.rost.cruma.core.editing.BspLightmapTail.LeafLights;
import com.rost.cruma.core.editing.IsolatedHeightPackage.Prepared;
import com.rost.cruma.core.editing.PackageBytes.Cursor;
import com.rost.cruma.core.editing.PackageBytes.ExportEntry;
import com.rost.cruma.core.editing.PackageBytes.ImportEntry;
import com.rost.cruma.core.editing.PackageRecoveryCodec.Bundle;
import com.rost.cruma.core.editing.PackageRecoveryCodec.Definition;
import com.rost.cruma.core.editing.PackageRecoveryCodec.Frame;
import com.rost.cruma.core.editing.PackageRecoveryCodec.LightAim;
import com.rost.cruma.core.editing.PackageRecoveryCodec.LightValue;
import com.rost.cruma.core.editing.PackageRecoveryCodec.Scalar;
import com.rost.cruma.core.editing.PackageRecoveryCodec.SurfaceValue;
import com.rost.cruma.core.editing.PackageRecoveryCodec.Tables;
import com.rost.cruma.core.editing.PackageRecoveryCodec.Value;
import com.rost.cruma.core.editing.StaticMeshInstanceCodec.Decoded;
import com.rost.cruma.core.unreal.UStaticMeshInstance;
import com.rost.cruma.core.world.UnrealLoader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.function.IntFunction;
import org.jetbrains.annotations.Nullable;

public final class PackageEditDocument {
    private static final Set<String> MATERIAL_CLASSES = Set.of(
            "Material",
            "Texture",
            "WetTexture",
            "TexModifier",
            "TexCoordSource",
            "TexScaler",
            "TexEnvMap",
            "ColorModifier",
            "OpacityModifier",
            "TexPanner",
            "TexPannerTriggered",
            "TexRotator",
            "TexOscillator",
            "TexOscillatorTriggered",
            "Combiner",
            "FinalBlend",
            "Shader",
            "Cubemap",
            "ConstantColor",
            "FadeColor",
            "VertexColor");
    private static final int MAX_SKIN_SLOTS = 256;
    private static final int BEAST_TAIL_VERSION = 132;
    private static final List<String> BEAST_PROPERTIES = List.of("BeastMapScaleSunLight", "BeastMapScaleLocalLight");
    private static final Set<String> COPY_SCALARS = Set.of(
            "beastmapscalesunlight",
            "beastmapscalelocallight",
            "culldistance",
            "scaleglow",
            "ambientglow",
            "maxlights",
            "style",
            "drawtype",
            "translucentrenderpriority",
            "bunlit",
            "bshadowcast",
            "bspeciallit",
            "bunlitcheck",
            "bculledsunlight",
            "bacceptsprojectors",
            "bsunaffect",
            "bstatic",
            "bhidden",
            "busel2actorviewtype",
            "bignoredrange",
            "rangeforignoredrange",
            "l2actorviewduration",
            "l2actorviewtype",
            "bdynamiclight",
            "busedynamiclights",
            "bcollideactors",
            "bblockactors",
            "bblockplayers",
            "bblocknonzeroextenttraces",
            "bblockzeroextenttraces",
            "busecylindercollision",
            "bworldgeometry",
            "collisionradius",
            "collisionheight",
            "bstaticlighting",
            "ambientintensity",
            "lightintensity");
    private final Path source;
    private final String originalSha256;
    private final PackageBytes original;
    private final List<String> names;
    private final List<ImportEntry> imports;
    private final Map<String, ActorState> actorStates = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private final Map<String, LightState> lightStates = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private int brightnessType;
    private int radiusType;
    private BspLeafLightEdit leafLightEdit;
    private String leafLightFailure;
    private @Nullable LeafListsKey leafLightsKey;
    private LeafLights leafLightsCached;
    private BspSurfaceEdit surfaceEdit;
    private String surfaceFailure;
    private final Map<Integer, BspSurfaceMapping> surfaceMappings = new TreeMap<>();
    private final Map<String, MaterialReference> materialReferences = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private final Set<String> dirtyActors = new HashSet<>();
    private int savedImportCount;
    private boolean importsChanged;
    private NativeLevelEditor level;
    private String structuralRestriction;
    private Snapshot savedSnapshot;

    private PackageEditDocument(Path source, byte[] file) throws IOException {
        this.source = source;
        originalSha256 = sha256(file);
        original = new PackageBytes(source, file);
        names = new ArrayList<>(original.names);
        imports = new ArrayList<>(original.imports);
        try {
            level = NativeLevelEditor.read(original);
        } catch (IOException failure) {
            structuralRestriction = failure.getMessage();
        }
        for (var entry : original.exports) {
            var className = original.getClassName(entry);
            if (className.equals("StaticMeshActor")) {
                var path = original.getObjectPath(entry.index());
                var state = readActor(path, className, entry);
                if (!original.getObjectPath(entry.classIndex()).equalsIgnoreCase("Engine.StaticMeshActor")) {
                    state.restriction = "Only Engine.StaticMeshActor has a verified editable layout";
                    state.editable = false;
                }
                if (actorStates.put(path, state) != null) {
                    throw malformed("Duplicate actor path " + path);
                }
            }
            var lightClass = EditableLight.CLASSES.get(className);
            if (lightClass != null && original.getObjectPath(entry.classIndex()).equalsIgnoreCase(lightClass)) {
                var path = original.getObjectPath(entry.index());
                try {
                    var light = EditableLight.read(original, entry, path, className);
                    lightStates.put(path, new LightState(light));
                    if (brightnessType == 0) {
                        brightnessType = light.brightnessType;
                    }
                    if (radiusType == 0 && light.radiusType > 0) {
                        radiusType = light.radiusType;
                    }
                } catch (IOException | RuntimeException unreadable) {
                }
            }
            if (MATERIAL_CLASSES.contains(className)) {
                var path = original.getObjectPath(entry.index());
                materialReferences.putIfAbsent(path, new MaterialReference(path, className, entry.index()));
            }
        }
        for (var i = 0; i < imports.size(); i++) {
            var entry = imports.get(i);
            var className = original.getName(entry.className());
            if (MATERIAL_CLASSES.contains(className)) {
                var path = original.getObjectPath(-i - 1);
                materialReferences.putIfAbsent(path, new MaterialReference(path, className, -i - 1));
            }
        }
        savedImportCount = imports.size();
        if (level != null) {
            var active = new HashSet<>(level.actors);
            for (var state : actorStates.values()) {
                state.deleted = !active.contains(state.entry.index());
                state.baselineDeleted = state.deleted;
            }
            lightStates.values().removeIf(state -> !active.contains(state.light.entry.index()));
        }
        savedSnapshot = snapshot();
    }

    public static PackageEditDocument open(Path source) throws IOException {
        var normalized = source.toAbsolutePath().normalize();
        if (!normalized.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".unr")) {
            throw new IOException("The scene editor opens .unr map packages");
        }
        return new PackageEditDocument(normalized, Files.readAllBytes(normalized));
    }

    public static void validateRecoveryEnvelope(byte[] payload) throws IOException {
        PackageRecoveryCodec.validateEnvelope(payload);
    }

    public static RestoredRecovery restoreRecovery(Path source, byte[] payload) throws IOException {
        try {
            var bundle = PackageRecoveryCodec.decode(payload);
            var document = open(source);
            if (!document.originalSha256.equals(bundle.sourceHash())) {
                throw malformed("Recovery source fingerprint differs");
            }
            if (!document.original.packageName.equals(bundle.packageName())) {
                throw malformed("Recovery source package identity differs");
            }
            return document.restoreRecoveryBundle(bundle);
        } catch (IllegalArgumentException | IndexOutOfBoundsException failure) {
            throw new IOException("Invalid recovery metadata", failure);
        }
    }

    public static List<MaterialReference> inspectMaterials(Path source) throws IOException {
        var asset = new PackageBytes(source, Files.readAllBytes(source));
        var result = new ArrayList<MaterialReference>();
        for (var entry : asset.exports) {
            var type = asset.getClassName(entry);
            if (MATERIAL_CLASSES.contains(type)
                    && asset.getObjectPath(entry.classIndex()).equalsIgnoreCase("Engine." + type)) {
                result.add(new MaterialReference(asset.getObjectPath(entry.index()), type, entry.index()));
            }
        }
        return List.copyOf(result);
    }

    public static List<String> inspectMeshes(Path source) throws IOException {
        var asset = new PackageBytes(source, Files.readAllBytes(source));
        var result = new ArrayList<String>();
        for (var entry : asset.exports) {
            if (asset.getClassName(entry).equals("StaticMesh")
                    && asset.getObjectPath(entry.classIndex()).equalsIgnoreCase("Engine.StaticMesh")) {
                result.add(asset.getObjectPath(entry.index()));
            }
        }
        return List.copyOf(result);
    }

    static String sha256(byte[] bytes) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }

    private record Tag(String name, int type, String struct, int arrayIndex, int start, int payload, int end) {}

    private record ScalarProperty(String name, int type, boolean truth, byte[] payload) {}

    private record MeshReference(int reference, String path) {}

    private record LightCheckpoint(
            LightState state, LightColor color, LightPlacement placement, LightShape shape, boolean deleted) {}

    private static final class LightState {
        final EditableLight light;
        final boolean created;
        final String template;
        LightColor current;
        LightPlacement placement;
        LightShape shape;
        boolean deleted;

        LightState(EditableLight light) {
            this(light, false, "");
        }

        LightState(EditableLight light, boolean created, String template) {
            this.light = light;
            this.created = created;
            this.template = template;
            current = light.color;
            placement = light.getPlacement();
            shape = light.shape;
        }

        boolean isMoved() {
            return !created && !deleted && !placement.equals(light.getPlacement());
        }

        boolean isTurned() {
            return !created && !deleted && !shape.equals(light.shape);
        }

        boolean isPlaced() {
            return isMoved() || created != deleted;
        }

        boolean isRelit() {
            return isPlaced() || isTurned();
        }

        LightCheckpoint getCheckpoint() {
            return new LightCheckpoint(this, current, placement, shape, deleted);
        }

        LightRecord snapshot() {
            return new LightRecord(
                    light.path,
                    light.entry.index(),
                    light.className,
                    placement.location(),
                    placement.radius(),
                    current,
                    light.color,
                    light.location,
                    light.radius,
                    light.isEditable(),
                    light.restriction,
                    created,
                    template,
                    shape,
                    light.shape);
        }
    }

    private static final class ActorState {
        final String path;
        final String className;
        final ExportEntry entry;
        final List<Tag> tags = new ArrayList<>();
        final List<Integer> originalSkins = new ArrayList<>();
        int terminator;
        byte[] tail = new byte[0];
        boolean tailMatchesTags = true;
        String restriction = "";
        boolean editable = true;
        boolean relocatable = true;
        boolean created;
        boolean deleted;
        boolean baselineDeleted;
        int meshReference;
        String meshPath = "";
        String template = "";
        byte[] newTail = new byte[0];
        int lightingInstance;
        List<ScalarProperty> scalarProperties = List.of();
        ActorTransform transform = ActorTransform.IDENTITY;
        ActorTransform current = ActorTransform.IDENTITY;
        ActorTransform savedTransform = ActorTransform.IDENTITY;
        List<Integer> savedSkins = List.of();
        List<Integer> skins = new ArrayList<>();

        ActorState(String path, String className, ExportEntry entry) {
            this.path = path;
            this.className = className;
            this.entry = entry;
        }

        ActorRecord snapshot() {
            return new ActorRecord(
                    path, entry.index(), className, current, skins, editable, restriction, meshPath, template, created);
        }
    }

    public Path getSource() {
        return source;
    }

    public String getOriginalSha256() {
        return originalSha256;
    }

    public int getFileVersion() {
        return original.fileVersion;
    }

    public int getLicenseVersion() {
        return original.licenseVersion;
    }

    public List<ActorRecord> getActors() {
        return actorStates.values().stream()
                .filter(state -> !state.deleted)
                .map(ActorState::snapshot)
                .toList();
    }

    public Optional<ActorRecord> findActor(String sourcePath) {
        var actor = actorStates.get(sourcePath);
        return actor == null || actor.deleted ? Optional.empty() : Optional.of(actor.snapshot());
    }

    public List<MaterialReference> getMaterials() {
        return List.copyOf(materialReferences.values());
    }

    public List<LightRecord> getLights() {
        return lightStates.values().stream()
                .filter(state -> !state.deleted)
                .map(LightState::snapshot)
                .toList();
    }

    public Optional<LightRecord> getLight(String sourcePath) {
        var state = lightStates.get(sourcePath);
        return state == null || state.deleted ? Optional.empty() : Optional.of(state.snapshot());
    }

    public List<LightRecord> getDeletedLights() {
        return lightStates.values().stream()
                .filter(state -> state.deleted && !state.created)
                .map(LightState::snapshot)
                .toList();
    }

    public Optional<LightRecord> findDeletedLight(String sourcePath) {
        var state = lightStates.get(sourcePath);
        return state == null || !state.deleted || state.created ? Optional.empty() : Optional.of(state.snapshot());
    }

    public String getLightColorRestriction(String sourcePath, LightColor color) {
        var state = lightStates.get(sourcePath);
        if (state == null || state.deleted) {
            return "Unknown light " + sourcePath;
        }
        return state.light.getRestriction(color, state.placement, brightnessType, radiusType);
    }

    public String getLightPlacementRestriction(String sourcePath, LightPlacement placement) {
        var state = lightStates.get(sourcePath);
        if (state == null || state.deleted) {
            return "Unknown light " + sourcePath;
        }
        return placementRestriction(state, state.current, placement);
    }

    public String getLightCopyRestriction(String sourcePath) {
        var state = lightStates.get(sourcePath);
        if (state == null || state.deleted) {
            return "Unknown light " + sourcePath;
        }
        if (level == null) {
            return structuralRestriction == null ? "The Level of this map cannot be read" : structuralRestriction;
        }
        if (!state.light.relocatable) {
            return "This light keeps data after its properties, so it cannot be copied";
        }
        return getLightMoveRestriction(sourcePath);
    }

    public LightRecord duplicateLight(String sourcePath, LightPlacement placement) throws IOException {
        Objects.requireNonNull(placement);
        var reason = getLightCopyRestriction(sourcePath);
        if (!reason.isEmpty()) {
            throw new IllegalArgumentException(reason);
        }
        var source = lightStates.get(sourcePath);
        var template = source.created ? lightStates.get(source.template) : source;
        reason = placementRestriction(template, source.current, placement);
        if (!reason.isEmpty()) {
            throw new IllegalArgumentException(reason);
        }
        var state = newLight(template, nextCreatedIndex(), null);
        state.current = source.current;
        state.placement = placement;
        state.shape = source.shape;
        lightStates.put(state.light.path, state);
        refreshDirty(state);
        return state.snapshot();
    }

    public LightTemplate getLightTemplate(boolean spot) {
        LightState best = null;
        var bestRank = Integer.MAX_VALUE;
        for (var state : lightStates.values()) {
            if (state.created || state.deleted) {
                continue;
            }
            var rank = state.light.getTemplateRank(spot);
            if (rank >= 0
                    && (rank < bestRank || rank == bestRank && state.light.entry.index() < best.light.entry.index())) {
                best = state;
                bestRank = rank;
            }
        }
        if (best == null) {
            return new LightTemplate(
                    "",
                    spot
                            ? "This map has no spotlight that a new one can copy"
                            : "This map has no light that a new one can copy");
        }
        return new LightTemplate(best.light.path, getLightCopyRestriction(best.light.path));
    }

    public record LightTemplate(String path, String restriction) {}

    public String getLightDeleteRestriction(String sourcePath) {
        var state = lightStates.get(sourcePath);
        if (state == null || state.deleted) {
            return "Unknown light " + sourcePath;
        }
        if (level == null) {
            return structuralRestriction == null ? "The Level of this map cannot be read" : structuralRestriction;
        }
        if (!state.light.restriction.isEmpty()) {
            return state.light.restriction;
        }
        try {
            leafLightEdit();
            return "";
        } catch (IOException unavailable) {
            return unavailable.getMessage().replace("cannot move", "cannot be deleted");
        }
    }

    public void deleteLight(String sourcePath) {
        var reason = getLightDeleteRestriction(sourcePath);
        if (!reason.isEmpty()) {
            throw new IllegalArgumentException(reason);
        }
        var state = lightStates.get(sourcePath);
        state.deleted = true;
        refreshDirty(state);
    }

    public void undeleteLight(String sourcePath) {
        var state = lightStates.get(sourcePath);
        if (state == null || !state.deleted || state.created) {
            throw new IllegalArgumentException("Only a deleted light of the source map can come back: " + sourcePath);
        }
        state.deleted = false;
        refreshDirty(state);
    }

    public String getLightMoveRestriction(String sourcePath) {
        var state = lightStates.get(sourcePath);
        if (state == null || state.deleted) {
            return "Unknown light " + sourcePath;
        }
        if (!state.light.restriction.isEmpty()) {
            return state.light.restriction;
        }
        if (!state.light.placed) {
            return "This light has no saved place, so it cannot move";
        }
        try {
            leafLightEdit();
            return "";
        } catch (IOException unavailable) {
            return unavailable.getMessage();
        }
    }

    public float getSolidBelow(Vector3 point, float depth) {
        try {
            return leafLightEdit().getSolidBelow(point, depth);
        } catch (IOException unavailable) {
            return Float.NaN;
        }
    }

    public void updateLightPlacement(String sourcePath, LightPlacement placement) {
        Objects.requireNonNull(placement);
        var restriction = getLightPlacementRestriction(sourcePath, placement);
        if (!restriction.isEmpty()) {
            throw new IllegalArgumentException(restriction);
        }
        var state = lightStates.get(sourcePath);
        state.placement = placement;
        refreshDirty(state);
    }

    public String getLightShapeRestriction(String sourcePath, LightShape shape) {
        Objects.requireNonNull(shape);
        var state = lightStates.get(sourcePath);
        if (state == null || state.deleted) {
            return "Unknown light " + sourcePath;
        }
        return state.light.getRestriction(state.current, state.placement, null, shape, brightnessType, radiusType);
    }

    public void updateLightShape(String sourcePath, LightShape shape) {
        var restriction = getLightShapeRestriction(sourcePath, shape);
        if (!restriction.isEmpty()) {
            throw new IllegalArgumentException(restriction);
        }
        var state = lightStates.get(sourcePath);
        state.shape = shape;
        refreshDirty(state);
    }

    public record LightPlacementEdit(
            String path,
            int exportIndex,
            @Nullable LightPlacement original,
            @Nullable LightPlacement current,
            int zone,
            int template,
            LightColor color,
            LightShape shape,
            boolean turned) {
        public List<LightPlacement> placements() {
            var result = new ArrayList<LightPlacement>(2);
            if (original != null) {
                result.add(original);
            }
            if (current != null) {
                result.add(current);
            }
            return result;
        }
    }

    public List<LightPlacementEdit> getLightPlacementEdits() {
        var result = new ArrayList<LightPlacementEdit>();
        for (var state : lightStates.values()) {
            if (!state.isRelit()) {
                continue;
            }
            var template =
                    state.created ? lightStates.get(state.template).light.entry.index() : state.light.entry.index();
            result.add(new LightPlacementEdit(
                    state.light.path,
                    state.light.entry.index(),
                    state.created ? null : state.light.getPlacement(),
                    state.deleted ? null : state.placement,
                    zoneAt(state, state.placement),
                    template,
                    state.current,
                    state.deleted ? state.light.shape : state.shape,
                    !state.deleted && !state.shape.equals(state.light.shape)));
        }
        return List.copyOf(result);
    }

    public void updateLightColor(String sourcePath, LightColor color) {
        Objects.requireNonNull(color);
        var restriction = getLightColorRestriction(sourcePath, color);
        if (!restriction.isEmpty()) {
            throw new IllegalArgumentException(restriction);
        }
        var state = lightStates.get(sourcePath);
        state.current = color;
        refreshDirty(state);
    }

    public record LightColorEdit(String path, int exportIndex, LightColor original, LightColor current) {}

    public List<LightColorEdit> getLightColorEdits() {
        return lightStates.values().stream()
                .filter(state -> !state.created && !state.deleted && !state.current.equals(state.light.color))
                .map(state -> new LightColorEdit(
                        state.light.path, state.light.entry.index(), state.light.color, state.current))
                .toList();
    }

    public String getSurfaceEditRestriction() {
        try {
            surfaceEdit();
            return "";
        } catch (IOException unavailable) {
            return unavailable.getMessage();
        }
    }

    public int pickSurface(Vector3 point, float tolerance) {
        try {
            return surfaceEdit().pick(point, tolerance);
        } catch (IOException unavailable) {
            return -1;
        }
    }

    public String getSurfaceRestriction(int surface) {
        try {
            return surfaceEdit().getRestriction(surface);
        } catch (IOException unavailable) {
            return unavailable.getMessage();
        }
    }

    public String getSurfaceMappingRestriction(int surface, BspSurfaceMapping mapping) {
        var reason = getSurfaceRestriction(surface);
        return reason.isEmpty() ? mapping.restriction() : reason;
    }

    public BspSurfaceMapping getSurfaceMapping(int surface) throws IOException {
        var edited = surfaceMappings.get(surface);
        return edited != null ? edited : getSourceSurfaceMapping(surface);
    }

    public BspSurfaceMapping getSourceSurfaceMapping(int surface) throws IOException {
        var edit = surfaceEdit();
        if (surface < 0 || surface >= edit.getSurfaceCount()) {
            throw new IllegalArgumentException("Unknown BSP surface " + surface);
        }
        return edit.getMapping(surface);
    }

    public Vector3 getSurfaceNormal(int surface) throws IOException {
        return surfaceEdit().getNormal(surface);
    }

    public List<float[]> getSurfacePolygons(int surface) throws IOException {
        return surfaceEdit().getPolygons(surface);
    }

    public int getSurfaceMaterial(int surface) throws IOException {
        return surfaceEdit().getMaterial(surface);
    }

    public float @Nullable [] getSurfaceTile(int surface) throws IOException {
        return surfaceEdit().getMappingSizes(surface);
    }

    public void updateSurfaceMapping(int surface, BspSurfaceMapping mapping) throws IOException {
        Objects.requireNonNull(mapping);
        var restriction = getSurfaceMappingRestriction(surface, mapping);
        if (!restriction.isEmpty()) {
            throw new IllegalArgumentException(restriction);
        }
        if (mapping.equals(getSourceSurfaceMapping(surface))) {
            surfaceMappings.remove(surface);
        } else {
            surfaceMappings.put(surface, mapping);
        }
        refreshSurfaceDirty(surface);
    }

    public record SurfaceMappingEdit(int surface, BspSurfaceMapping original, BspSurfaceMapping current) {}

    public List<SurfaceMappingEdit> getSurfaceMappingEdits() {
        var result = new ArrayList<SurfaceMappingEdit>();
        surfaceMappings.forEach((surface, mapping) ->
                result.add(new SurfaceMappingEdit(surface, surfaceEdit.getMapping(surface), mapping)));
        return result;
    }

    public boolean isDirty() {
        return importsChanged || savedImportCount != imports.size() || !dirtyActors.isEmpty();
    }

    public static final class Snapshot {
        private final PackageEditDocument owner;
        private final List<String> names;
        private final List<ImportEntry> imports;
        private final Map<String, MaterialReference> materials;
        private final Map<String, ActorCheckpoint> actors;
        private final List<ActorCheckpoint> changes;
        private final Map<String, LightCheckpoint> lights;
        private final Map<Integer, BspSurfaceMapping> surfaces;

        private Snapshot(PackageEditDocument owner) {
            this.owner = owner;
            names = List.copyOf(owner.names);
            imports = List.copyOf(owner.imports);
            materials = Map.copyOf(owner.materialReferences);
            var values = new LinkedHashMap<String, ActorCheckpoint>();
            var changed = new ArrayList<ActorCheckpoint>();
            owner.actorStates.forEach((path, state) -> {
                var checkpoint = new ActorCheckpoint(state, state.current, List.copyOf(state.skins), state.deleted);
                values.put(path, checkpoint);
                if (state.created
                        || state.deleted != state.baselineDeleted
                        || !state.current.equals(state.transform)
                        || !state.skins.equals(state.originalSkins)) {
                    changed.add(checkpoint);
                }
            });
            actors = Map.copyOf(values);
            changes = List.copyOf(changed);
            var checkpoints = new LinkedHashMap<String, LightCheckpoint>();
            owner.lightStates.forEach((path, state) -> checkpoints.put(path, state.getCheckpoint()));
            lights = Collections.unmodifiableMap(checkpoints);
            surfaces = Map.copyOf(owner.surfaceMappings);
        }
    }

    public static final class RecoveryBundle {
        private final Bundle bundle;

        private RecoveryBundle(Bundle bundle) {
            this.bundle = bundle;
        }

        public byte[] encode() throws IOException {
            return PackageRecoveryCodec.encode(bundle);
        }
    }

    public record RestoredRecovery(PackageEditDocument document, List<Snapshot> historySnapshots) {
        public RestoredRecovery {
            historySnapshots = List.copyOf(historySnapshots);
        }
    }

    public static final class UnsupportedRecoveryFormat extends IOException {
        public UnsupportedRecoveryFormat(String message) {
            super(message);
        }
    }

    public RecoveryBundle captureRecovery(List<Snapshot> historySnapshots) {
        var history = List.copyOf(historySnapshots);
        for (var snapshot : history) {
            if (snapshot.owner != this) {
                throw new IllegalArgumentException("Snapshot belongs to another map");
            }
        }
        var definitions = new ArrayList<Definition>();
        var identities = new IdentityHashMap<ActorState, Integer>();
        var frames = new IdentityHashMap<Snapshot, Frame>();
        Function<Snapshot, Frame> capture = snapshot -> frames.computeIfAbsent(snapshot, frame -> {
            var values = new ArrayList<Value>();
            for (var value : frame.changes.stream()
                    .sorted(Comparator.comparingInt(checkpoint -> checkpoint.state.entry.index()))
                    .toList()) {
                var state = value.state;
                var identity = identities.get(state);
                if (identity == null) {
                    identity = definitions.size();
                    identities.put(state, identity);
                    var scalars = state.scalarProperties.stream()
                            .map(scalar -> new Scalar(scalar.name, scalar.type, scalar.truth, scalar.payload))
                            .toList();
                    definitions.add(new Definition(
                            state.entry.index(),
                            state.created,
                            state.path,
                            state.entry.classIndex(),
                            state.entry.objectName(),
                            state.meshReference,
                            state.meshPath,
                            state.template,
                            state.newTail,
                            scalars));
                }
                values.add(new Value(identity, value.transform, value.skins, value.deleted));
            }
            var table = new Tables(
                    frame.names.subList(original.names.size(), frame.names.size()),
                    frame.imports.subList(original.imports.size(), frame.imports.size()),
                    frame.materials);
            var lights = new ArrayList<LightValue>();
            frame.lights.forEach((path, checkpoint) -> {
                var state = checkpoint.state();
                if (state.created) {
                    lights.add(new LightValue(
                            path,
                            checkpoint.color(),
                            checkpoint.placement(),
                            checkpoint.deleted(),
                            state.template,
                            state.light.entry.index(),
                            LightAim.of(checkpoint.shape())));
                } else if (checkpoint.deleted()
                        || !checkpoint.color().equals(state.light.color)
                        || !checkpoint.placement().equals(state.light.getPlacement())
                        || !checkpoint.shape().equals(state.light.shape)) {
                    lights.add(new LightValue(
                            path,
                            checkpoint.color(),
                            checkpoint.placement(),
                            checkpoint.deleted(),
                            null,
                            0,
                            LightAim.of(checkpoint.shape())));
                }
            });
            var surfaces = frame.surfaces.entrySet().stream()
                    .sorted(Entry.comparingByKey())
                    .map(entry -> new SurfaceValue(entry.getKey(), entry.getValue()))
                    .toList();
            return new Frame(table, values, lights, surfaces);
        });
        var current = capture.apply(snapshot());
        var saved = capture.apply(savedSnapshot);
        var capturedHistory = history.stream().map(capture).toList();
        return new RecoveryBundle(
                new Bundle(originalSha256, original.packageName, definitions, current, saved, capturedHistory));
    }

    public Snapshot snapshot() {
        return new Snapshot(this);
    }

    public void restore(Snapshot snapshot) {
        if (snapshot.owner != this) {
            throw new IllegalArgumentException("Snapshot belongs to another map");
        }
        names.clear();
        names.addAll(snapshot.names);
        imports.clear();
        imports.addAll(snapshot.imports);
        importsChanged = !imports.equals(savedSnapshot.imports);
        materialReferences.clear();
        materialReferences.putAll(snapshot.materials);
        actorStates.clear();
        snapshot.actors.forEach((path, checkpoint) -> {
            var state = checkpoint.state;
            state.current = checkpoint.transform;
            state.skins = new ArrayList<>(checkpoint.skins);
            state.deleted = checkpoint.deleted;
            actorStates.put(path, state);
        });
        lightStates.clear();
        snapshot.lights.forEach((path, checkpoint) -> {
            var state = checkpoint.state();
            state.current = checkpoint.color();
            state.placement = checkpoint.placement();
            state.shape = checkpoint.shape();
            state.deleted = checkpoint.deleted();
            lightStates.put(path, state);
        });
        surfaceMappings.clear();
        surfaceMappings.putAll(snapshot.surfaces);
        dirtyActors.clear();
        actorStates.values().forEach(this::refreshDirty);
        lightStates.values().forEach(this::refreshDirty);
        var surfaces = new HashSet<>(surfaceMappings.keySet());
        surfaces.addAll(savedSnapshot.surfaces.keySet());
        surfaces.forEach(this::refreshSurfaceDirty);
        for (var path : savedSnapshot.actors.keySet()) {
            if (!actorStates.containsKey(path)) {
                dirtyActors.add(path);
            }
        }
        for (var path : savedSnapshot.lights.keySet()) {
            if (!lightStates.containsKey(path)) {
                dirtyActors.add(path);
            }
        }
    }

    public boolean hasChangesFromSource() {
        return imports.size() != original.imports.size()
                || !getLightColorEdits().isEmpty()
                || !getLightPlacementEdits().isEmpty()
                || lightStates.values().stream().anyMatch(state -> state.created)
                || !surfaceMappings.isEmpty()
                || actorStates.values().stream()
                        .anyMatch(state -> state.created
                                || state.deleted != state.baselineDeleted
                                || !state.current.equals(state.transform)
                                || !state.skins.equals(state.originalSkins));
    }

    public byte[] previewBody() throws IOException {
        return buildBody();
    }

    public byte[] previewBody(ActorLightingChanges lighting) throws IOException {
        return buildBody(null, lighting);
    }

    public byte[] previewBody(NativePackageChanges nativeChanges) throws IOException {
        nativeChanges.validateFor(source, originalSha256, original);
        return buildBody(nativeChanges, null);
    }

    public record LightingEdit(
            String path,
            boolean created,
            boolean deleted,
            ActorTransform original,
            ActorTransform current,
            boolean editable) {}

    public List<LightingEdit> getLightingEdits() {
        var result = new ArrayList<LightingEdit>();
        for (var state : actorStates.values()) {
            if (state.created && state.deleted) {
                continue;
            }
            result.add(new LightingEdit(
                    state.path,
                    state.created,
                    state.deleted && !state.baselineDeleted,
                    state.created ? null : state.transform,
                    state.current,
                    state.editable));
        }
        return List.copyOf(result);
    }

    public boolean canWriteLighting(String sourcePath) {
        var state = actorStates.get(sourcePath);
        if (state == null || state.deleted) {
            return false;
        }
        if (state.created || state.editable && state.relocatable) {
            return true;
        }
        try {
            var reference = instanceReference(state);
            if (reference == 0 || !isInstanceExport(reference)) {
                return false;
            }
            for (var other : actorStates.values()) {
                if (other != state && !other.created && instanceReference(other) == reference) {
                    return false;
                }
            }
            return true;
        } catch (IOException malformed) {
            return false;
        }
    }

    record Unapplied(Map<String, Actor> actors, int beastKept) {}

    Unapplied getUnappliedLighting(Set<Integer> lights) throws IOException {
        var owners = new HashMap<Integer, Integer>();
        for (var state : actorStates.values()) {
            if (!state.created) {
                var reference = instanceReference(state);
                if (reference != 0) {
                    owners.merge(reference, 1, Integer::sum);
                }
            }
        }
        var result = new TreeMap<String, Actor>(String.CASE_INSENSITIVE_ORDER);
        var beastKept = 0;
        for (var state : actorStates.values()) {
            if (state.created || state.deleted) {
                continue;
            }
            var reference = instanceReference(state);
            if (reference == 0 || owners.get(reference) != 1 || !isInstanceExport(reference)) {
                continue;
            }
            var decoded = decodeInstance(reference);
            if (!decoded.beastLightmaps().isEmpty()) {
                if (names(decoded.instance(), lights)) {
                    beastKept++;
                }
                continue;
            }
            Decoded lod1 = null;
            if (decoded.lod1() != 0) {
                if (!isInstanceExport(decoded.lod1())) {
                    continue;
                }
                lod1 = decodeInstance(decoded.lod1());
            }
            var shares = decoded.lod2() != 0 && decoded.lod2() == decoded.lod1();
            Decoded lod2 = null;
            if (decoded.lod2() != 0 && !shares) {
                if (!isInstanceExport(decoded.lod2())) {
                    continue;
                }
                lod2 = decodeInstance(decoded.lod2());
            }
            if (!names(decoded.instance(), lights)
                    && (lod1 == null || !names(lod1.instance(), lights))
                    && (lod2 == null || !names(lod2.instance(), lights))) {
                continue;
            }
            result.put(
                    state.path,
                    new Actor(
                            unapplied(decoded.instance(), lights),
                            lod1 == null ? null : unapplied(lod1.instance(), lights),
                            lod2 == null ? null : unapplied(lod2.instance(), lights),
                            shares));
        }
        return new Unapplied(result, beastKept);
    }

    public boolean hasBeastLighting(String sourcePath) {
        var state = actorStates.get(sourcePath);
        if (state == null || state.created) {
            return false;
        }
        try {
            var reference = instanceReference(state);
            return reference != 0
                    && isInstanceExport(reference)
                    && !decodeInstance(reference).beastLightmaps().isEmpty();
        } catch (IOException malformed) {
            return false;
        }
    }

    record SavedBeast(int lod, int instance, int width, int height, int slot0, int slot1) {}

    List<SavedBeast> getSavedBeast(String sourcePath) {
        var state = actorStates.get(sourcePath);
        if (state == null || state.created) {
            return List.of();
        }
        var result = new ArrayList<SavedBeast>();
        try {
            var reference = instanceReference(state);
            if (reference == 0 || !isInstanceExport(reference)) {
                return List.of();
            }
            var decoded = decodeInstance(reference);
            addSavedBeast(result, 0, reference, decoded);
            if (decoded.lod1() > 0 && isInstanceExport(decoded.lod1())) {
                addSavedBeast(result, 1, decoded.lod1(), decodeInstance(decoded.lod1()));
            }
            if (decoded.lod2() > 0 && decoded.lod2() != decoded.lod1() && isInstanceExport(decoded.lod2())) {
                addSavedBeast(result, 2, decoded.lod2(), decodeInstance(decoded.lod2()));
            }
        } catch (IOException malformed) {
            return List.of();
        }
        return List.copyOf(result);
    }

    Saved getSavedBeastTexture(int exportIndex) throws IOException {
        if (exportIndex <= 0
                || exportIndex > original.exports.size()
                || !isBeastTexture(original.exports.get(exportIndex - 1))) {
            throw malformed("Not a Beast lightmap texture export: " + exportIndex);
        }
        return BeastTextureCodec.read(original, original.exports.get(exportIndex - 1));
    }

    PackageBytes getOriginalPackage() {
        return original;
    }

    List<Integer> getTerrainBeastTextures(String owner) throws IOException {
        int slot0 = 0, slot1 = 0;
        for (var entry : original.exports) {
            if (!original.getClassName(entry).equals("Texture")) {
                continue;
            }
            var name = original.getName(entry.objectName());
            if (name.equalsIgnoreCase(owner + "_Lightmap_0")) {
                slot0 = entry.index();
            } else if (name.equalsIgnoreCase(owner + "_Lightmap_1")) {
                slot1 = entry.index();
            }
        }
        return slot0 > 0 && slot1 > 0 ? List.of(slot0, slot1) : List.of();
    }

    byte[] getOriginalBody() {
        return original.body.clone();
    }

    public boolean hasStaticMeshInstance(String sourcePath) {
        var state = actorStates.get(sourcePath);
        if (state == null || state.created) {
            return false;
        }
        try {
            return instanceReference(state) != 0;
        } catch (IOException malformed) {
            return false;
        }
    }

    public Set<String> getDeletedActorPaths() {
        var paths = new HashSet<String>();
        actorStates.values().stream()
                .filter(state -> state.deleted && !state.baselineDeleted)
                .forEach(state -> paths.add(state.path));
        return Set.copyOf(paths);
    }

    public String importMesh(Path meshPackage, String meshSourcePath) throws IOException {
        var asset = new PackageBytes(meshPackage, Files.readAllBytes(meshPackage));
        for (var entry : asset.exports) {
            if (asset.getObjectPath(entry.index()).equalsIgnoreCase(meshSourcePath)) {
                if (!asset.getObjectPath(entry.classIndex()).equalsIgnoreCase("Engine.StaticMesh")) {
                    throw malformed("Selected asset is not an Engine.StaticMesh");
                }
                validateAssetOuter(asset, entry.outer());
                var canonical = asset.getObjectPath(entry.index());
                importPath(canonical, "Engine", "StaticMesh");
                return canonical;
            }
        }
        throw malformed("Mesh export not found: " + meshSourcePath);
    }

    public List<String> getMeshReferences() throws IOException {
        var result = new ArrayList<String>();
        for (var entry : original.exports) {
            if (original.getClassName(entry).equals("StaticMesh")) {
                result.add(original.getObjectPath(entry.index()));
            }
        }
        for (var i = 0; i < imports.size(); i++) {
            if (names.get(imports.get(i).className()).equals("StaticMesh")) {
                result.add(objectPath(-i - 1));
            }
        }
        return result.stream().sorted(String.CASE_INSENSITIVE_ORDER).distinct().toList();
    }

    public String getStructuralRestriction() {
        return structuralRestriction == null ? "" : structuralRestriction;
    }

    public ActorRecord duplicateActor(String sourcePath, ActorTransform placement) throws IOException {
        var state = requireEditable(sourcePath);
        requireStructural();
        if (state.meshReference == 0) {
            throw malformed("Actor has no StaticMesh reference");
        }
        if (!referenceClass(state.meshReference).equals("StaticMesh")) {
            throw malformed("Actor does not reference a StaticMesh");
        }
        return createActor(
                state.meshReference, state.meshPath, placement, state.skins, state.path, copiedScalars(state));
    }

    public ActorRecord createStaticMeshActor(String meshSourcePath, ActorTransform placement) throws IOException {
        requireStructural();
        var mesh = meshReference(meshSourcePath);
        return createActor(mesh.reference(), mesh.path(), placement, List.of(), "", List.of());
    }

    public ActorRecord replaceActorMesh(String sourcePath, String meshSourcePath, int keptSlots) throws IOException {
        var state = requireEditable(sourcePath);
        requireStructural();
        var mesh = meshReference(meshSourcePath);
        var skins = new ArrayList<>(state.skins.subList(0, Math.clamp(keptSlots, 0, state.skins.size())));
        while (!skins.isEmpty() && skins.getLast() == 0) {
            skins.removeLast();
        }
        var before = snapshot();
        try {
            var created =
                    createActor(mesh.reference(), mesh.path(), state.current, skins, state.path, copiedScalars(state));
            deleteActor(sourcePath);
            return created;
        } catch (IOException | RuntimeException failure) {
            restore(before);
            throw failure;
        }
    }

    public void deleteActor(String sourcePath) throws IOException {
        var state = requireEditable(sourcePath);
        requireStructural();
        if (level.actors.stream().limit(2).anyMatch(index -> index == state.entry.index())) {
            throw malformed("The two reserved Level actor slots cannot be deleted");
        }
        state.deleted = true;
        refreshDirty(state);
    }

    public void undeleteActor(String sourcePath) throws IOException {
        var state = actorStates.get(sourcePath);
        if (state == null || !state.deleted || state.baselineDeleted || state.created) {
            throw new IllegalArgumentException("Only a deleted actor of the source map can come back: " + sourcePath);
        }
        requireStructural();
        state.deleted = false;
        refreshDirty(state);
    }

    public Set<String> getDeletedSourceActors() {
        var paths = new HashSet<String>();
        for (var state : actorStates.values()) {
            if (state.deleted && !state.baselineDeleted && !state.created) {
                paths.add(state.path);
            }
        }
        return Set.copyOf(paths);
    }

    public @Nullable ActorRecord getDeletedActor(String sourcePath) {
        var state = actorStates.get(sourcePath);
        return state == null || !state.deleted ? null : state.snapshot();
    }

    public ActorRecord transferActorTo(String sourcePath, PackageEditDocument target, ActorTransform placement)
            throws IOException {
        Objects.requireNonNull(target);
        if (target == this) {
            throw malformed("Transfer requires a different map");
        }
        var before = snapshot();
        var targetBefore = target.snapshot();
        try {
            requireStructural();
            target.requireStructural();
            if (getFileVersion() != target.getFileVersion() || getLicenseVersion() != target.getLicenseVersion()) {
                throw malformed("Actor transfer requires matching map package versions");
            }
            var state = requireEditable(sourcePath);
            var mesh = target.importReference(this, state.meshReference, "StaticMesh");
            var skins = new ArrayList<Integer>();
            for (var reference : state.skins) {
                var mapped = reference == 0 ? 0 : target.importReference(this, reference, null);
                skins.add(mapped);
                if (mapped != 0) {
                    var path = objectPath(reference);
                    target.materialReferences.put(path, new MaterialReference(path, referenceClass(reference), mapped));
                }
            }
            var result = target.createActor(mesh, state.meshPath, placement, skins, state.path, copiedScalars(state));
            deleteActor(sourcePath);
            return result;
        } catch (IOException | RuntimeException failure) {
            restore(before);
            target.restore(targetBefore);
            throw failure;
        }
    }

    public String transformRestriction(String sourcePath, ActorTransform transform) {
        try {
            var state = requireEditable(sourcePath);
            validateFixedEdits(state, transform, state.skins);
            return "";
        } catch (IllegalArgumentException refused) {
            return refused.getMessage();
        }
    }

    public String deleteRestriction(String sourcePath) {
        try {
            var state = requireEditable(sourcePath);
            if (level == null) {
                return getStructuralRestriction();
            }
            return level.actors.stream().limit(2).anyMatch(index -> index == state.entry.index())
                    ? "The two reserved Level actor slots cannot be deleted"
                    : "";
        } catch (IllegalArgumentException refused) {
            return refused.getMessage();
        }
    }

    public String copyRestriction(String sourcePath) {
        try {
            var state = requireEditable(sourcePath);
            if (level == null) {
                return getStructuralRestriction();
            }
            return state.meshReference == 0 ? "This actor has no StaticMesh" : "";
        } catch (IllegalArgumentException refused) {
            return refused.getMessage();
        }
    }

    public void updateTransform(String sourcePath, ActorTransform transform) {
        var state = requireEditable(sourcePath);
        Objects.requireNonNull(transform);
        validateFixedEdits(state, transform, state.skins);
        state.current = transform;
        refreshDirty(state);
    }

    public void updateSkin(String sourcePath, int slot, String materialSourcePath) {
        if (slot < 0 || slot >= MAX_SKIN_SLOTS) {
            throw new IllegalArgumentException("Invalid material slot " + slot);
        }
        var state = requireEditable(sourcePath);
        var reference = materialSourcePath == null ? null : materialReferences.get(materialSourcePath);
        if (materialSourcePath != null && reference == null) {
            throw new IllegalArgumentException("Material is not referenced by the map: " + materialSourcePath);
        }
        if (slot >= state.skins.size() && reference == null) {
            return;
        }
        var skins = new ArrayList<>(state.skins);
        while (skins.size() <= slot) {
            skins.add(0);
        }
        skins.set(slot, reference == null ? 0 : reference.objectIndex());
        while (skins.size() > state.originalSkins.size() && skins.getLast() == 0) {
            skins.removeLast();
        }
        validateFixedEdits(state, state.current, skins);
        state.skins = skins;
        refreshDirty(state);
    }

    public void updateSkins(String sourcePath, List<Integer> references) {
        var state = requireEditable(sourcePath);
        if (references.size() > MAX_SKIN_SLOTS) {
            throw new IllegalArgumentException("Too many material slots");
        }
        for (var reference : references) {
            if (reference != 0
                    && materialReferences.values().stream().noneMatch(m -> m.objectIndex() == reference)
                    && !state.originalSkins.contains(reference)) {
                throw new IllegalArgumentException("Unknown material reference " + reference);
            }
        }
        validateFixedEdits(state, state.current, references);
        state.skins = new ArrayList<>(references);
        refreshDirty(state);
    }

    public MaterialReference importMaterial(Path materialPackage, String materialSourcePath) throws IOException {
        var existing = materialReferences.get(materialSourcePath);
        if (existing != null) {
            return existing;
        }
        var asset = new PackageBytes(materialPackage, Files.readAllBytes(materialPackage));
        return importMaterial(asset, materialSourcePath);
    }

    public MaterialReference importHeightTexture(Prepared clone) throws IOException {
        verifySourceUnchanged();
        IsolatedHeightPackage.verifyPrepared(clone);
        var asset = new PackageBytes(Path.of(clone.packageName() + ".utx"), clone.bytes());
        return importMaterial(asset, clone.objectPath());
    }

    public Path saveAs(Path outputFile) throws IOException {
        var target = outputFile.toAbsolutePath().normalize();
        var bytes = prepareSave(target);
        var parent = target.getParent();
        if (!Files.isDirectory(parent)) {
            throw new IOException("Output directory does not exist: " + parent);
        }
        var temporary = Files.createTempFile(parent, ".cruma-map-", ".tmp");
        try {
            try (var channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) {
                var buffer = ByteBuffer.wrap(bytes);
                while (buffer.hasRemaining()) {
                    channel.write(buffer);
                }
                channel.force(true);
            }
            verifySourceUnchanged();
            if (Files.exists(target) && Files.isSameFile(source, target)) {
                throw new IOException("Output resolves to the source map");
            }
            Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temporary);
        }
        markSaved();
        return target;
    }

    public byte[] prepareSave(Path outputFile) throws IOException {
        return prepareSave(outputFile, null);
    }

    public byte[] prepareSave(Path outputFile, NativePackageChanges nativeChanges) throws IOException {
        return prepareSave(outputFile, nativeChanges, null);
    }

    public byte[] prepareSave(Path outputFile, NativePackageChanges nativeChanges, ActorLightingChanges lighting)
            throws IOException {
        var target = outputFile.toAbsolutePath().normalize();
        if (target.equals(source) || Files.exists(target) && Files.isSameFile(source, target)) {
            throw new IOException("Save As must use a separate output map; the source client is read-only");
        }
        if (!target.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".unr")) {
            throw new IOException("The output map must have the .unr extension");
        }
        verifySourceUnchanged();
        if (nativeChanges != null) {
            nativeChanges.validateFor(source, originalSha256, original);
        }
        var body = buildBody(nativeChanges, lighting);
        var bytes = original.encode(body, target);
        var verified = new PackageEditDocument(target, bytes);
        verifySavedActors(verified);
        if (lighting != null) {
            verifyLighting(verified, lighting);
        }
        if (nativeChanges != null) {
            nativeChanges.verify(target, bytes);
        }
        return bytes;
    }

    public void markSaved() {
        for (var state : actorStates.values()) {
            state.savedTransform = state.current;
            state.savedSkins = List.copyOf(state.skins);
        }
        dirtyActors.clear();
        savedImportCount = imports.size();
        importsChanged = false;
        savedSnapshot = snapshot();
    }

    public void verifySourceUnchanged() throws IOException {
        if (!sha256(Files.readAllBytes(source)).equals(originalSha256)) {
            throw new IOException("Source map changed since editing began; reopen it before saving");
        }
    }

    public boolean canWriteBeastLightmaps() {
        if (original.licenseVersion < UStaticMeshInstance.BEAST_LIGHTMAP_LICENSE) {
            return false;
        }
        try {
            for (var entry : original.exports) {
                if (isBeastTexture(entry)) {
                    BeastTextureCodec.readTemplate(original, entry);
                    return true;
                }
            }
        } catch (IOException unreadable) {
            return false;
        }
        return false;
    }

    private LightState newLight(LightState template, int index, @Nullable String name) throws IOException {
        var prefix = "Cruma" + template.light.className;
        var objectName = name;
        if (objectName == null) {
            var suffix = index;
            objectName = prefix + suffix;
            while (names.contains(objectName) || lightStates.containsKey(original.packageName + "." + objectName)) {
                objectName = prefix + ++suffix;
            }
        }
        var saved = template.light.entry;
        var entry = new ExportEntry(
                index,
                saved.classIndex(),
                0,
                0,
                intern(objectName),
                saved.flags(),
                saved.serialSize(),
                saved.serialOffset(),
                0,
                0,
                0);
        return new LightState(
                template.light.copy(entry, original.packageName + "." + objectName), true, template.light.path);
    }

    private int nextCreatedIndex() {
        return original.exports.size() + createdExportCount() + 1;
    }

    private int createdExportCount() {
        return (int) (actorStates.values().stream()
                        .filter(state -> state.created)
                        .count()
                + lightStates.values().stream().filter(state -> state.created).count());
    }

    private String placementRestriction(LightState state, LightColor color, LightPlacement placement) {
        var reason = state.light.getRestriction(color, placement, brightnessType, radiusType);
        if (!reason.isEmpty() || placement.equals(state.light.getPlacement())) {
            return reason;
        }
        try {
            var edit = leafLightEdit();
            if (placement.location().equals(state.light.location)) {
                return "";
            }
            reason = edit.getRestriction(state.light.location, placement.location());
            if (!reason.isEmpty()) {
                return reason;
            }
            var before = edit.getRegion(state.light.location);
            var after = edit.getRegion(placement.location());
            if (before == null || after == null) {
                return "";
            }
            if (before.zoneNumber() != after.zoneNumber()) {
                if (state.light.region == null) {
                    return "Its zone is saved in an unusual way, so it can only move inside its own zone";
                }
                if (isSkyZone(before.zone()) != isSkyZone(after.zone())) {
                    return "A light cannot move into or out of a sky zone";
                }
            }
            return state.light.getRestriction(
                    color, placement, newRegion(state, placement), state.shape, brightnessType, radiusType);
        } catch (IOException unavailable) {
            return unavailable.getMessage();
        }
    }

    private @Nullable LightRegion newRegion(LightState state, LightPlacement placement) throws IOException {
        if (placement.location().equals(state.light.location) || state.light.region == null) {
            return null;
        }
        return leafLightEdit().getRegion(placement.location());
    }

    private boolean isSkyZone(int reference) throws IOException {
        return reference > 0
                && reference <= original.exports.size()
                && original.getClassName(original.exports.get(reference - 1)).equals("SkyZoneInfo");
    }

    private int zoneAt(LightState state, LightPlacement placement) {
        try {
            var region = newRegion(state, placement);
            if (region != null) {
                return region.zoneNumber();
            }
        } catch (IOException unavailable) {
        }
        return state.light.region == null ? -1 : state.light.region.zoneNumber();
    }

    private synchronized BspLeafLightEdit leafLightEdit() throws IOException {
        if (leafLightEdit == null && leafLightFailure == null) {
            if (level == null) {
                leafLightFailure = structuralRestriction == null ? "its Level cannot be read" : structuralRestriction;
            } else {
                try {
                    leafLightEdit = BspLeafLightEdit.open(source, original, level.actors);
                } catch (IOException unavailable) {
                    leafLightFailure = unavailable.getMessage();
                }
            }
        }
        if (leafLightEdit == null) {
            throw new IOException(
                    "The light lists of this map cannot be rebuilt, so its lights cannot move: " + leafLightFailure);
        }
        return leafLightEdit;
    }

    private synchronized @Nullable LeafLights leafLightLists() throws IOException {
        var moved = new LinkedHashMap<Integer, NativeBspLeafLights.Light>();
        var removed = new TreeSet<Integer>();
        for (var state : lightStates.values()) {
            if (!state.isPlaced()) {
                continue;
            }
            var index = state.light.entry.index();
            if (state.deleted) {
                removed.add(index);
                continue;
            }
            var location = state.placement.location();
            moved.put(
                    index,
                    new NativeBspLeafLights.Light(
                            index, location.x(), location.y(), location.z(), state.placement.reach(), false));
        }
        if (moved.isEmpty() && removed.isEmpty()) {
            return null;
        }
        var key = new LeafListsKey(Map.copyOf(moved), Set.copyOf(removed), appendedActors());
        if (!key.equals(leafLightsKey)) {
            var edit = leafLightEdit();
            var lists = edit.buildLists(moved, removed, key.appended());
            leafLightsCached = lists == null || lists.equals(edit.getSaved()) ? null : lists;
            leafLightsKey = key;
        }
        return leafLightsCached;
    }

    private record LeafListsKey(
            Map<Integer, NativeBspLeafLights.Light> moved, Set<Integer> removed, List<Integer> appended) {}

    private List<Integer> appendedActors() {
        var result = new TreeSet<Integer>();
        for (var state : actorStates.values()) {
            if (state.created && !state.deleted) {
                result.add(state.entry.index());
            }
        }
        for (var state : lightStates.values()) {
            if (state.created && !state.deleted) {
                result.add(state.light.entry.index());
            }
        }
        return List.copyOf(result);
    }

    private synchronized BspSurfaceEdit surfaceEdit() throws IOException {
        if (surfaceEdit == null && surfaceFailure == null) {
            try {
                surfaceEdit = BspSurfaceEdit.open(source, original);
            } catch (IOException unavailable) {
                surfaceFailure = unavailable.getMessage();
            }
        }
        if (surfaceEdit == null) {
            throw new IOException("The BSP surfaces of this map cannot be written: " + surfaceFailure);
        }
        return surfaceEdit;
    }

    private void refreshSurfaceDirty(int surface) {
        var saved = savedSnapshot == null ? null : savedSnapshot.surfaces.get(surface);
        if (Objects.equals(saved, surfaceMappings.get(surface))) {
            dirtyActors.remove(surfaceKey(surface));
        } else {
            dirtyActors.add(surfaceKey(surface));
        }
    }

    private RestoredRecovery restoreRecoveryBundle(Bundle bundle) throws IOException {
        var baseline = savedSnapshot;
        var identities = new ArrayList<ActorState>();
        var originalDefinitions = new HashSet<Integer>();
        for (var definition : bundle.definitions()) {
            if (!definition.created()) {
                var state = actorStates.get(definition.path());
                if (state == null
                        || state.entry.index() != definition.exportIndex()
                        || !originalDefinitions.add(definition.exportIndex())) {
                    throw malformed("Invalid recovery source actor identity");
                }
                identities.add(state);
            } else {
                requireStructural();
                if (definition.exportIndex() <= original.exports.size()
                        || definition.exportIndex() > PackageBytes.MAX_ENTRIES) {
                    throw malformed("Invalid recovery created actor layout");
                }
                var scalars = new ArrayList<ScalarProperty>();
                var seen = new HashSet<String>();
                for (var scalar : definition.scalars()) {
                    var expectedSize = switch (scalar.type()) {
                        case 1 -> 1;
                        case 2, 4 -> 4;
                        case 3 -> 0;
                        default -> -1;
                    };
                    if (!COPY_SCALARS.contains(scalar.name().toLowerCase(Locale.ROOT))
                            || !seen.add(scalar.name().toLowerCase(Locale.ROOT))
                            || scalar.payload().length != expectedSize) {
                        throw malformed("Invalid recovery copied actor property");
                    }
                    scalars.add(new ScalarProperty(
                            scalar.name(),
                            scalar.type(),
                            scalar.truth(),
                            scalar.payload().clone()));
                }
                if (!Arrays.equals(definition.tail(), creationTail(scalars))) {
                    throw malformed("Invalid recovery created actor layout");
                }
                var entry = new ExportEntry(
                        definition.exportIndex(),
                        definition.classReference(),
                        0,
                        0,
                        definition.nameIndex(),
                        0x02070001,
                        0,
                        0,
                        0,
                        0,
                        0);
                var state = new ActorState(definition.path(), "StaticMeshActor", entry);
                state.created = true;
                state.meshReference = definition.meshReference();
                state.meshPath = definition.meshPath();
                state.template = definition.template();
                state.newTail = definition.tail().clone();
                state.scalarProperties = List.copyOf(scalars);
                identities.add(state);
            }
        }
        var decoded = new IdentityHashMap<Frame, Snapshot>();
        var createdLights = new HashMap<String, LightState>();
        var requested = new ArrayList<Frame>();
        requested.add(bundle.current());
        requested.add(bundle.saved());
        requested.addAll(bundle.history());
        for (var frame : requested) {
            if (decoded.containsKey(frame)) {
                continue;
            }
            restore(baseline);
            restoreRecoveryTables(frame.tables(), baseline);
            var used = new HashSet<Integer>();
            var createdIndices = new HashSet<Integer>();
            for (var value : frame.values()) {
                if (!used.add(value.definition())) {
                    throw malformed("Duplicate recovery actor state");
                }
                var state = identities.get(value.definition());
                if (state.created) {
                    validateRecoveryCreatedActor(state);
                    if (!createdIndices.add(state.entry.index())
                            || actorStates.putIfAbsent(state.path, state) != null) {
                        throw malformed("Duplicate recovery created actor slot");
                    }
                } else if (!state.editable || state.baselineDeleted) {
                    throw malformed("Recovery modifies a protected source actor");
                }
                if (!state.created && value.deleted() != state.baselineDeleted) {
                    requireStructural();
                    if (level.actors.stream().limit(2).anyMatch(index -> index == state.entry.index())) {
                        throw malformed("Recovery deletes a reserved Level actor");
                    }
                }
                for (var reference : value.skins()) {
                    checkRecoveryReference(reference);
                    if (reference != 0
                            && !state.originalSkins.contains(reference)
                            && !MATERIAL_CLASSES.contains(referenceClass(reference))) {
                        throw malformed("Recovery skin is not a material");
                    }
                }
                validateFixedEdits(state, value.transform(), value.skins());
                state.current = value.transform();
                state.skins = new ArrayList<>(value.skins());
                state.deleted = value.deleted();
            }
            var lights = new HashSet<String>();
            for (var value : frame.lights()) {
                if (!lights.add(value.path())) {
                    throw malformed("Duplicate recovery light");
                }
                LightState state;
                if (value.template() != null) {
                    state = recoveryCreatedLight(value, createdLights);
                    if (!createdIndices.add(state.light.entry.index())
                            || lightStates.putIfAbsent(value.path(), state) != null) {
                        throw malformed("Duplicate recovery created light slot");
                    }
                } else {
                    state = lightStates.get(value.path());
                    if (state == null || state.created) {
                        throw malformed("Recovery changes a light that cannot take this colour");
                    }
                }
                var placement = value.placement() == null ? state.light.getPlacement() : value.placement();
                var shape =
                        value.aim() == null ? state.light.shape : value.aim().applyTo(state.light.shape);
                if (!placementRestriction(state, value.color(), placement).isEmpty()) {
                    throw malformed("Recovery changes a light that cannot take this colour or place");
                }
                if (!state.light
                        .getRestriction(value.color(), placement, null, shape, brightnessType, radiusType)
                        .isEmpty()) {
                    throw malformed("Recovery turns a light that cannot take this direction or cone");
                }
                if (value.deleted() && (level == null || !state.light.restriction.isEmpty())) {
                    throw malformed("Recovery deletes a light that cannot be deleted");
                }
                state.current = value.color();
                state.placement = placement;
                state.shape = shape;
                state.deleted = value.deleted();
            }
            for (var index = original.exports.size() + 1;
                    index <= original.exports.size() + createdIndices.size();
                    index++) {
                if (!createdIndices.contains(index)) {
                    throw malformed("Recovery created exports are not contiguous");
                }
            }
            for (var value : frame.surfaces()) {
                if (surfaceMappings.containsKey(value.surface())
                        || !getSurfaceMappingRestriction(value.surface(), value.mapping())
                                .isEmpty()
                        || value.mapping().equals(getSourceSurfaceMapping(value.surface()))) {
                    throw malformed("Recovery changes a BSP surface that cannot take this mapping");
                }
                surfaceMappings.put(value.surface(), value.mapping());
            }
            decoded.put(frame, snapshot());
        }
        savedSnapshot = decoded.get(bundle.saved());
        savedImportCount = savedSnapshot.imports.size();
        restore(decoded.get(bundle.current()));
        var candidate = new PackageEditDocument(source, original.encode(buildBody(), source));
        verifySavedActors(candidate);
        return new RestoredRecovery(
                this, bundle.history().stream().map(decoded::get).toList());
    }

    private void restoreRecoveryTables(Tables table, Snapshot baseline) throws IOException {
        if ((long) names.size() + table.names().size() > PackageBytes.MAX_ENTRIES
                || (long) imports.size() + table.imports().size() > PackageBytes.MAX_ENTRIES) {
            throw malformed("Recovery package tables exceed limits");
        }
        var uniqueNames = new HashSet<>(names);
        for (var name : table.names()) {
            if (name.isEmpty() || name.indexOf('\0') >= 0 || !uniqueNames.add(name)) {
                throw malformed("Invalid recovery package name");
            }
            names.add(name);
        }
        for (var entry : table.imports()) {
            var packageName = recoveryName(entry.classPackage());
            var className = recoveryName(entry.className());
            recoveryName(entry.objectName());
            if (entry.outer() > 0 || entry.outer() < -imports.size()) {
                throw malformed("Invalid recovery import outer");
            }
            if (className.equals("Class") || className.equals("Package")) {
                if (!packageName.equals("Core")) {
                    throw malformed("Invalid recovery class package");
                }
            } else if (!packageName.equals("Engine")
                    || !className.equals("StaticMesh") && !MATERIAL_CLASSES.contains(className)) {
                throw malformed("Unsupported recovery import class");
            }
            var outer = entry.outer();
            var depth = 0;
            while (outer < 0) {
                if (++depth > 64) {
                    throw malformed("Recovery import nesting exceeds limit");
                }
                outer = imports.get(-outer - 1).outer();
            }
            imports.add(entry);
        }
        materialReferences.clear();
        for (var material : table.materials().values()) {
            checkRecoveryReference(material.objectIndex());
            if (!MATERIAL_CLASSES.contains(material.className())
                    || !referenceClass(material.objectIndex()).equals(material.className())
                    || !objectPath(material.objectIndex()).equalsIgnoreCase(material.sourcePath())) {
                throw malformed("Invalid recovery material identity");
            }
            if (materialReferences.put(material.sourcePath(), material) != null) {
                throw malformed("Duplicate recovery material identity");
            }
        }
        for (var original : baseline.materials.keySet()) {
            if (!materialReferences.containsKey(original)) {
                throw malformed("Recovery removed a source material registration");
            }
        }
    }

    private LightState recoveryCreatedLight(LightValue value, Map<String, LightState> known) throws IOException {
        requireStructural();
        var key = value.path() + '\n' + value.template() + '\n' + value.exportIndex();
        var state = known.get(key);
        if (state != null) {
            return state;
        }
        var template = lightStates.get(value.template());
        var prefix = original.packageName + ".";
        var name = value.path().startsWith(prefix) ? value.path().substring(prefix.length()) : "";
        if (template == null
                || template.created
                || !template.light.relocatable
                || !template.light.restriction.isEmpty()
                || !name.matches("Cruma" + template.light.className + "[0-9]+")
                || original.names.contains(name)
                || !names.contains(name)) {
            throw malformed("Invalid recovery created light");
        }
        if (value.exportIndex() <= original.exports.size() || value.exportIndex() > PackageBytes.MAX_ENTRIES) {
            throw malformed("Invalid recovery created light layout");
        }
        state = newLight(template, value.exportIndex(), name);
        known.put(key, state);
        return state;
    }

    private void validateRecoveryCreatedActor(ActorState state) throws IOException {
        var name = recoveryName(state.entry.objectName());
        if (!name.matches("CrumaStaticMeshActor[0-9]+")
                || original.names.contains(name)
                || !state.path.equals(original.packageName + "." + name)) {
            throw malformed("Invalid recovery created actor name");
        }
        checkRecoveryReference(state.entry.classIndex());
        checkRecoveryReference(state.meshReference);
        if (!objectPath(state.entry.classIndex()).equalsIgnoreCase("Engine.StaticMeshActor")
                || !referenceClass(state.entry.classIndex()).equals("Class")
                || !referenceClass(state.meshReference).equals("StaticMesh")
                || !objectPath(state.meshReference).equalsIgnoreCase(state.meshPath)) {
            throw malformed("Invalid recovery created actor asset identity");
        }
    }

    private String recoveryName(int index) throws IOException {
        if (index < 0 || index >= names.size()) {
            throw malformed("Invalid recovery name reference");
        }
        return names.get(index);
    }

    private void checkRecoveryReference(int reference) throws IOException {
        if (reference > original.exports.size() || (long) reference < -(long) imports.size()) {
            throw malformed("Invalid recovery object reference");
        }
    }

    private record ActorCheckpoint(ActorState state, ActorTransform transform, List<Integer> skins, boolean deleted) {}

    private void addSavedBeast(List<SavedBeast> result, int lod, int instance, Decoded decoded) throws IOException {
        var references = decoded.beastLightmaps();
        if (references.size() != 2
                || !BeastTextureCodec.isValidSize(decoded.beastWidth(), decoded.beastHeight())
                || !isSameSizeBeastTexture(references.get(0), 0, decoded.beastWidth(), decoded.beastHeight())
                || !isSameSizeBeastTexture(references.get(1), 1, decoded.beastWidth(), decoded.beastHeight())) {
            return;
        }
        result.add(new SavedBeast(
                lod, instance, decoded.beastWidth(), decoded.beastHeight(), references.get(0), references.get(1)));
    }

    private MeshReference meshReference(String meshSourcePath) throws IOException {
        for (var entry : original.exports) {
            if (original.getObjectPath(entry.classIndex()).equalsIgnoreCase("Engine.StaticMesh")
                    && original.getObjectPath(entry.index()).equalsIgnoreCase(meshSourcePath)) {
                return new MeshReference(entry.index(), original.getObjectPath(entry.index()));
            }
        }
        for (var i = 0; i < imports.size(); i++) {
            if (names.get(imports.get(i).className()).equals("StaticMesh")
                    && names.get(imports.get(i).classPackage()).equalsIgnoreCase("Engine")
                    && objectPath(-i - 1).equalsIgnoreCase(meshSourcePath)) {
                return new MeshReference(-i - 1, objectPath(-i - 1));
            }
        }
        throw malformed("Mesh is not referenced by this map: " + meshSourcePath);
    }

    private void requireStructural() throws IOException {
        if (level == null) {
            throw malformed(structuralRestriction);
        }
    }

    private ActorRecord createActor(
            int mesh,
            String meshPath,
            ActorTransform placement,
            List<Integer> skins,
            String template,
            List<ScalarProperty> scalarProperties)
            throws IOException {
        Objects.requireNonNull(placement);
        if (mesh == 0) {
            throw malformed("A new actor requires a StaticMesh");
        }
        var reusable = actorStates.values().stream()
                .filter(state -> state.created && state.deleted)
                .min(Comparator.comparingInt(state -> state.entry.index()))
                .orElse(null);
        var next = reusable == null ? nextCreatedIndex() : reusable.entry.index();
        var suffix = next;
        var objectName = reusable == null ? "CrumaStaticMeshActor" + suffix : names.get(reusable.entry.objectName());
        while (reusable == null && names.contains(objectName)) {
            objectName = "CrumaStaticMeshActor" + ++suffix;
        }
        var classReference = importPath("Engine.StaticMeshActor", "Core", "Class");
        var entry = new ExportEntry(next, classReference, 0, 0, intern(objectName), 0x02070001, 0, 0, 0, 0, 0);
        var state = new ActorState(original.packageName + "." + objectName, "StaticMeshActor", entry);
        state.created = true;
        state.meshReference = mesh;
        state.meshPath = meshPath;
        state.template = template;
        state.scalarProperties = scalarProperties;
        state.current = placement;
        state.skins = new ArrayList<>(skins);
        state.newTail = creationTail(scalarProperties);
        actorStates.put(state.path, state);
        refreshDirty(state);
        return state.snapshot();
    }

    private byte[] creationTail(List<ScalarProperty> scalars) {
        if (original.fileVersion < BEAST_TAIL_VERSION) {
            return new byte[0];
        }
        var tail = new byte[2];
        for (var scalar : scalars) {
            for (var i = 0; i < BEAST_PROPERTIES.size(); i++) {
                if (scalar.name.equalsIgnoreCase(BEAST_PROPERTIES.get(i))) {
                    tail[i] = scalar.payload[0];
                }
            }
        }
        return tail;
    }

    private List<ScalarProperty> copiedScalars(ActorState state) throws IOException {
        if (state.created) {
            return state.scalarProperties;
        }
        if (!state.tailMatchesTags) {
            throw malformed("Cannot copy this actor: its native BeastMapScale bytes differ from its tagged values");
        }
        var properties = new ArrayList<ScalarProperty>();
        var used = new HashSet<String>();
        for (var tag : state.tags) {
            if (!COPY_SCALARS.contains(tag.name().toLowerCase(Locale.ROOT))) {
                continue;
            }
            if (!used.add(tag.name().toLowerCase(Locale.ROOT))
                    || tag.arrayIndex() != 0
                    || tag.type() < 1
                    || tag.type() > 4
                    || tag.type() == 1 && tag.end() - tag.payload() != 1
                    || (tag.type() == 2 || tag.type() == 4) && tag.end() - tag.payload() != 4) {
                throw malformed("Unsupported copied scalar property " + tag.name());
            }
            var header = new Cursor(original.body, tag.start(), tag.end());
            header.readIndex();
            var truth = (header.readU8() & 128) != 0;
            properties.add(new ScalarProperty(
                    tag.name(), tag.type(), truth, Arrays.copyOfRange(original.body, tag.payload(), tag.end())));
        }
        return List.copyOf(properties);
    }

    private String objectPath(int reference) throws IOException {
        if (reference >= 0) {
            return original.getObjectPath(reference);
        }
        var entry = imports.get(-reference - 1);
        return entry.outer() == 0
                ? names.get(entry.objectName())
                : objectPath(entry.outer()) + "." + names.get(entry.objectName());
    }

    private String referenceClass(int reference) throws IOException {
        if (reference == 0) {
            throw malformed("Null asset reference");
        }
        return reference > 0
                ? original.getClassName(original.exports.get(reference - 1))
                : names.get(imports.get(-reference - 1).className());
    }

    private int importReference(PackageEditDocument source, int reference, String expectedClass) throws IOException {
        var type = source.referenceClass(reference);
        if (expectedClass == null ? !MATERIAL_CLASSES.contains(type) : !type.equals(expectedClass)) {
            throw malformed("Unsupported transferred asset class " + type);
        }
        var path = source.objectPath(reference);
        if (reference > 0
                && !source.original
                        .getObjectPath(
                                source.original.exports.get(reference - 1).classIndex())
                        .equalsIgnoreCase("Engine." + type)) {
            throw malformed("Transferred asset has a custom class");
        }
        if (reference > 0) {
            validateAssetOuter(
                    source.original, source.original.exports.get(reference - 1).outer());
        }
        if (reference < 0
                && !source.names
                        .get(source.imports.get(-reference - 1).classPackage())
                        .equalsIgnoreCase("Engine")) {
            throw malformed("Transferred asset has a custom class package");
        }
        return importPath(path, "Engine", type);
    }

    private int importPath(String path, String classPackage, String className) throws IOException {
        for (var entry : original.exports) {
            if (original.getObjectPath(entry.index()).equalsIgnoreCase(path)
                    && original.getClassName(entry).equals(className)) {
                return entry.index();
            }
        }
        var parts = path.split("\\.");
        if (parts.length < 2) {
            throw malformed("Unsupported asset path " + path);
        }
        var outer = 0;
        for (var i = 0; i < parts.length; i++) {
            var last = i == parts.length - 1;
            var entry = new ImportEntry(
                    intern(last ? classPackage : "Core"),
                    intern(last ? className : "Package"),
                    outer,
                    intern(parts[i]));
            var found = imports.indexOf(entry);
            if (found < 0) {
                imports.add(entry);
                importsChanged = true;
                found = imports.size() - 1;
            }
            outer = -found - 1;
        }
        return outer;
    }

    private MaterialReference importMaterial(PackageBytes asset, String materialSourcePath) throws IOException {
        var existing = materialReferences.get(materialSourcePath);
        if (existing != null) {
            return existing;
        }
        ExportEntry selected = null;
        for (var entry : asset.exports) {
            if (asset.getObjectPath(entry.index()).equalsIgnoreCase(materialSourcePath)) {
                if (selected != null) {
                    throw malformed("Ambiguous material path " + materialSourcePath);
                }
                selected = entry;
            }
        }
        if (selected == null) {
            throw malformed("Material export not found: " + materialSourcePath);
        }
        var className = asset.getClassName(selected);
        if (!MATERIAL_CLASSES.contains(className)) {
            throw malformed("Object is not a supported material: " + className);
        }
        if (!asset.getObjectPath(selected.classIndex()).equalsIgnoreCase("Engine." + className)) {
            throw malformed("Material is not an Engine material class");
        }
        validateAssetOuter(asset, selected.outer());
        var canonical = asset.getObjectPath(selected.index());
        var segments = canonical.split("\\.");
        if (segments.length < 2 || !segments[0].equalsIgnoreCase(asset.packageName)) {
            throw malformed("Material has an unsupported outer chain");
        }
        var outer = 0;
        for (var i = 0; i < segments.length; i++) {
            var last = i == segments.length - 1;
            var next = new ImportEntry(
                    intern(last ? "Engine" : "Core"), intern(last ? className : "Package"), outer, intern(segments[i]));
            var found = imports.indexOf(next);
            if (found < 0) {
                imports.add(next);
                importsChanged = true;
                found = imports.size() - 1;
            }
            outer = -found - 1;
        }
        var result = new MaterialReference(canonical, className, outer);
        materialReferences.put(canonical, result);
        return result;
    }

    private void refreshDirty(ActorState state) {
        var saved = savedSnapshot == null ? null : savedSnapshot.actors.get(state.path);
        if (saved != null
                && saved.state == state
                && state.current.equals(saved.transform)
                && state.skins.equals(saved.skins)
                && state.deleted == saved.deleted) {
            dirtyActors.remove(state.path);
        } else {
            dirtyActors.add(state.path);
        }
    }

    private void refreshDirty(LightState state) {
        var saved = savedSnapshot == null ? null : savedSnapshot.lights.get(state.light.path);
        if (state.getCheckpoint().equals(saved)) {
            dirtyActors.remove(state.light.path);
        } else {
            dirtyActors.add(state.light.path);
        }
    }

    private void verifySavedActors(PackageEditDocument verified) throws IOException {
        for (var state : lightStates.values()) {
            var written = verified.lightStates.get(verified.original.getObjectPath(state.light.entry.index()));
            if (state.deleted) {
                if (written != null) {
                    throw malformed("Deleted light is still in the Level: " + state.light.path);
                }
                continue;
            }
            if (state.created && (written == null || !written.light.className.equals(state.light.className))) {
                throw malformed("Written new light did not round-trip: " + state.light.path);
            }
            var region = newRegion(state, state.placement);
            if (written == null
                    || !written.light.color.equals(state.current)
                    || !written.light.getPlacement().equals(state.placement)
                    || !written.light.shape.equals(state.shape)
                    || !Objects.equals(written.light.region, region == null ? state.light.region : region)) {
                throw malformed("Written light did not round-trip: " + state.light.path);
            }
        }
        var lists = leafLightLists();
        if (lists != null) {
            var entry = verified.original.exports.get(leafLightEdit.modelExport - 1);
            var payload = Arrays.copyOfRange(
                    verified.original.body, entry.serialOffset(), entry.serialOffset() + entry.serialSize());
            if (!BspLeafLightEdit.read(verified.original, payload, entry.serialOffset(), entry.flags())
                    .equals(lists)) {
                throw malformed("Written BSP leaf light lists did not round-trip");
            }
        }
        if (!surfaceMappings.isEmpty()) {
            var written = BspSurfaceEdit.open(verified.original, surfaceEdit.modelExport);
            if (written.getSurfaceCount() != surfaceEdit.getSurfaceCount()) {
                throw malformed("Written BSP surfaces did not round-trip");
            }
            for (var surface = 0; surface < written.getSurfaceCount(); surface++) {
                var expected = surfaceMappings.getOrDefault(surface, surfaceEdit.getMapping(surface));
                if (!written.getMapping(surface).equals(expected)) {
                    throw malformed("Written BSP surface mapping did not round-trip: " + surface);
                }
            }
        }
        for (var state : actorStates.values()) {
            var exported = verified.original.exports.get(state.entry.index() - 1);
            var path = verified.original.getObjectPath(exported.index());
            var candidate = verified.actorStates.get(path);
            if (candidate == null
                    || !candidate.current.equals(state.current)
                    || !candidate.skins.equals(state.skins)
                    || candidate.deleted != state.deleted
                    || !candidate.meshPath.equalsIgnoreCase(state.meshPath)
                    || !Arrays.equals(candidate.tail, state.created ? state.newTail : state.tail)) {
                throw malformed("Written actor did not round-trip: " + state.path);
            }
            if (state.created) {
                var copied = verified.copiedScalars(candidate);
                if (copied.size() != state.scalarProperties.size()) {
                    throw malformed("Copied actor properties did not round-trip");
                }
                for (var i = 0; i < copied.size(); i++) {
                    var expected = state.scalarProperties.get(i);
                    var actual = copied.get(i);
                    if (!expected.name.equals(actual.name)
                            || expected.type != actual.type
                            || expected.truth != actual.truth
                            || !Arrays.equals(expected.payload, actual.payload)) {
                        throw malformed("Copied actor property did not round-trip: " + expected.name);
                    }
                }
            }
        }
    }

    private ActorState requireEditable(String path) {
        var state = actorStates.get(path);
        if (state == null || state.deleted) {
            throw new IllegalArgumentException("Unknown actor " + path);
        }
        if (!state.editable) {
            throw new IllegalArgumentException(state.restriction);
        }
        return state;
    }

    private void validateFixedEdits(ActorState state, ActorTransform value, List<Integer> skins) {
        if (state.relocatable || state.created) {
            return;
        }
        var required = new ArrayList<String>();
        if (!state.transform.location().equals(value.location())) {
            required.add("Location");
        }
        if (!state.transform.rotation().equals(value.rotation())) {
            required.add("Rotation");
        }
        if (Float.compare(state.transform.drawScale(), value.drawScale()) != 0) {
            required.add("DrawScale");
        }
        if (!state.transform.drawScale3d().equals(value.drawScale3d())) {
            required.add("DrawScale3D");
        }
        if (!state.transform.prePivot().equals(value.prePivot())) {
            required.add("PrePivot");
        }
        for (var name : required) {
            if (state.tags.stream().noneMatch(tag -> tag.name().equalsIgnoreCase(name))) {
                throw new IllegalArgumentException("Cannot add " + name + ": this actor has an unaudited native tail");
            }
        }
        if (!skins.equals(state.originalSkins)) {
            var tag = state.tags.stream()
                    .filter(valueTag -> valueTag.name().equalsIgnoreCase("Skins"))
                    .findFirst();
            var payload = new ByteArrayOutputStream();
            writeIndex(payload, skins.size());
            for (var reference : skins) {
                writeIndex(payload, reference);
            }
            if (tag.isEmpty() || payload.size() != tag.get().end() - tag.get().payload()) {
                throw new IllegalArgumentException("Cannot resize Skins: this actor has an unaudited native tail");
            }
        }
    }

    private byte[] buildBody() throws IOException {
        return buildBody(null, null);
    }

    private byte[] buildBody(NativePackageChanges nativeChanges) throws IOException {
        return buildBody(nativeChanges, null);
    }

    private byte[] buildBody(NativePackageChanges nativeChanges, ActorLightingChanges lighting) throws IOException {
        var created = new ArrayList<ExportEntry>();
        for (var state : actorStates.values()) {
            if (state.created) {
                created.add(state.entry);
            }
        }
        for (var state : lightStates.values()) {
            if (state.created) {
                created.add(state.light.entry);
            }
        }
        created.sort(Comparator.comparingInt(ExportEntry::index));
        var plan = lighting == null || lighting.isEmpty() ? LightingPlan.EMPTY : planLighting(lighting, created.size());
        var changed = new LinkedHashMap<Integer, byte[]>();
        try {
            for (var state : actorStates.values()) {
                state.lightingInstance = plan.actorReferences().getOrDefault(state.path, 0);
                if (state.created
                        || !state.current.equals(state.transform)
                        || !state.skins.equals(state.originalSkins)
                        || state.lightingInstance != 0) {
                    changed.put(state.entry.index(), buildActor(state));
                }
            }
        } finally {
            for (var state : actorStates.values()) {
                state.lightingInstance = 0;
            }
        }
        for (var state : lightStates.values()) {
            if (state.created
                    || !state.deleted
                            && (!state.current.equals(state.light.color) || state.isMoved() || state.isTurned())) {
                changed.put(
                        state.light.entry.index(),
                        state.light.write(
                                original,
                                state.current,
                                state.placement,
                                newRegion(state, state.placement),
                                state.shape,
                                brightnessType,
                                radiusType,
                                this::intern));
            }
        }
        changed.putAll(plan.bodies());
        var removed = new HashSet<Integer>();
        for (var state : actorStates.values()) {
            if (!state.created && state.deleted != state.baselineDeleted) {
                removed.add(state.entry.index());
            }
        }
        for (var state : lightStates.values()) {
            if (!state.created && state.deleted) {
                removed.add(state.light.entry.index());
            }
        }
        var added = appendedActors();
        if (!removed.isEmpty() || !added.isEmpty()) {
            requireStructural();
            changed.put(level.entry.index(), level.rewrite(removed, added));
        }
        if (nativeChanges != null) {
            nativeChanges.contribute(changed);
        }
        var lists = leafLightLists();
        if (lists != null) {
            var model = original.exports.get(leafLightEdit.modelExport - 1);
            var written = changed.get(model.index());
            if (written == null) {
                changed.put(model.index(), levelModelPayload(lists, model.serialOffset()));
            } else if (!BspLeafLightEdit.read(original, written, model.serialOffset(), model.flags())
                    .equals(lists)) {
                throw malformed("A native level Model change does not carry the lists of the edited lights");
            }
        }
        var surfaceModel = surfaceMappings.isEmpty() ? null : original.exports.get(surfaceEdit.modelExport - 1);
        byte[] surfaceBase = null;
        if (surfaceModel != null) {
            var written = changed.get(surfaceModel.index());
            if (nativeChanges != null && nativeChanges.contains(surfaceModel.index())) {
                if (!surfaceEdit.carries(written, surfaceModel.serialOffset(), surfaceMappings)) {
                    throw malformed("A native level Model change does not carry the edited BSP surfaces");
                }
            } else {
                surfaceBase = written != null
                        ? written
                        : Arrays.copyOfRange(
                                original.body,
                                surfaceModel.serialOffset(),
                                surfaceModel.serialOffset() + surfaceModel.serialSize());
                changed.put(
                        surfaceModel.index(),
                        surfaceEdit.apply(
                                surfaceBase,
                                surfaceModel.serialOffset(),
                                surfaceModel.serialOffset(),
                                surfaceMappings));
            }
        }
        if (changed.isEmpty() && imports.size() == original.imports.size()) {
            return original.body.clone();
        }
        var out = new ByteArrayOutputStream();
        out.writeBytes(original.body);
        var offsets = new LinkedHashMap<Integer, Integer>();
        var patched = original.body.clone();
        for (var change : changed.entrySet()) {
            if (change.getKey() > original.exports.size()) {
                offsets.put(change.getKey(), out.size());
                out.writeBytes(plan.placed(change.getKey(), change.getValue(), out.size()));
                continue;
            }
            var entry = original.exports.get(change.getKey() - 1);
            if (change.getValue().length == entry.serialSize()) {
                System.arraycopy(
                        plan.placed(entry.index(), change.getValue(), entry.serialOffset()),
                        0,
                        patched,
                        entry.serialOffset(),
                        entry.serialSize());
            } else {
                if (nativeChanges != null && nativeChanges.contains(entry.index())) {
                    if (!nativeChanges.mayRelocate(entry.index())) {
                        throw malformed("Native export has no audited relocation policy");
                    }
                    var placed = nativeChanges.getPayloadAt(entry.index(), out.size());
                    if (placed.length != change.getValue().length) {
                        throw malformed("A relocated native export changed its size");
                    }
                    change.setValue(placed);
                } else if (plan.bodies().containsKey(entry.index())) {
                } else if (surfaceBase != null && entry.index() == surfaceModel.index()) {
                    change.setValue(surfaceEdit.apply(surfaceBase, entry.serialOffset(), out.size(), surfaceMappings));
                } else if (lists != null && entry.index() == leafLightEdit.modelExport) {
                    change.setValue(levelModelPayload(lists, out.size()));
                } else if (level == null || entry.index() != level.entry.index()) {
                    var light = lightStates.values().stream()
                            .filter(candidate -> candidate.light.entry.index() == entry.index())
                            .findFirst();
                    if (light.isPresent()) {
                        if (!light.orElseThrow().light.relocatable) {
                            throw malformed("Cannot relocate a light with a native tail");
                        }
                    } else {
                        var state = actorStates.values().stream()
                                .filter(actor -> actor.entry.index() == entry.index())
                                .findFirst()
                                .orElseThrow();
                        if (!state.relocatable) {
                            throw malformed("Cannot relocate an actor with an unaudited native tail");
                        }
                    }
                }
                offsets.put(entry.index(), out.size());
                out.writeBytes(plan.placed(entry.index(), change.getValue(), out.size()));
            }
        }
        var newNameOffset = -1;
        if (names.size() != original.names.size()) {
            newNameOffset = out.size();
            out.write(original.body, original.nameOffset, original.nameEnd - original.nameOffset);
            for (var i = original.names.size(); i < names.size(); i++) {
                PackageBytes.writeName(out, names.get(i));
            }
        }
        var newImportOffset = -1;
        if (imports.size() != original.imports.size()) {
            newImportOffset = out.size();
            out.write(original.body, original.importOffset, original.importEnd - original.importOffset);
            for (var i = original.imports.size(); i < imports.size(); i++) {
                var entry = imports.get(i);
                writeIndex(out, entry.classPackage());
                writeIndex(out, entry.className());
                writeInt(out, entry.outer());
                writeIndex(out, entry.objectName());
            }
        }
        var newExportOffset = -1;
        if (!offsets.isEmpty()) {
            newExportOffset = out.size();
            for (var entry : original.exports) {
                if (offsets.containsKey(entry.index())) {
                    out.write(original.body, entry.rowStart(), entry.sizeOffset() - entry.rowStart());
                    writeIndex(out, changed.get(entry.index()).length);
                    writeIndex(out, offsets.get(entry.index()));
                } else {
                    out.write(original.body, entry.rowStart(), entry.rowEnd() - entry.rowStart());
                }
            }
            for (var entry : created) {
                writeIndex(out, entry.classIndex());
                writeIndex(out, 0);
                writeInt(out, 0);
                writeIndex(out, entry.objectName());
                writeInt(out, entry.flags());
                writeIndex(out, changed.get(entry.index()).length);
                writeIndex(out, offsets.get(entry.index()));
            }
            for (var entry : plan.appended()) {
                writeIndex(out, entry.classIndex());
                writeIndex(out, 0);
                writeInt(out, 0);
                writeIndex(out, entry.objectName());
                writeInt(out, entry.flags());
                writeIndex(out, changed.get(entry.index()).length);
                writeIndex(out, offsets.get(entry.index()));
            }
        }
        var result = out.toByteArray();
        System.arraycopy(patched, 0, result, 0, patched.length);
        var header = littleEndian(result);
        if (newNameOffset >= 0) {
            header.putInt(12, names.size());
            header.putInt(16, newNameOffset);
            if (original.lastGenerationNameOffset >= 0) {
                header.putInt(original.lastGenerationNameOffset, names.size());
            }
        }
        if (newImportOffset >= 0) {
            header.putInt(28, imports.size());
            header.putInt(32, newImportOffset);
        }
        if (newExportOffset >= 0) {
            var exportCount =
                    original.exports.size() + created.size() + plan.appended().size();
            header.putInt(24, newExportOffset);
            header.putInt(20, exportCount);
            if (original.lastGenerationNameOffset >= 0) {
                header.putInt(original.lastGenerationNameOffset - 4, exportCount);
            }
        }
        return result;
    }

    private byte[] levelModelPayload(LeafLights lists, int serialOffset) throws IOException {
        return leafLightEdit.getPayload(lists, serialOffset);
    }

    private record LightingPlan(
            Map<Integer, byte[]> bodies,
            List<ExportEntry> appended,
            Map<String, Integer> actorReferences,
            Map<Integer, IntFunction<byte[]>> positioned) {
        static final LightingPlan EMPTY = new LightingPlan(Map.of(), List.of(), Map.of(), Map.of());

        byte[] placed(int index, byte[] body, int offset) {
            var builder = positioned.get(index);
            if (builder == null) {
                return body;
            }
            var result = builder.apply(offset);
            if (result.length != body.length) {
                throw new IllegalStateException("A placed Beast texture changed its size");
            }
            return result;
        }
    }

    @FunctionalInterface
    private interface TextureReplacement {
        void accept(int index, BeastTexture texture) throws IOException;
    }

    @FunctionalInterface
    private interface TextureAppender {
        int apply(String name, BeastTexture texture) throws IOException;
    }

    private LightingPlan planLighting(ActorLightingChanges lighting, int createdCount) throws IOException {
        var owners = new HashMap<Integer, Integer>();
        for (var state : actorStates.values()) {
            if (!state.created) {
                var reference = instanceReference(state);
                if (reference != 0) {
                    owners.merge(reference, 1, Integer::sum);
                }
            }
        }
        var bodies = new LinkedHashMap<Integer, byte[]>();
        var appended = new ArrayList<ExportEntry>();
        var references = new LinkedHashMap<String, Integer>();
        var positioned = new LinkedHashMap<Integer, IntFunction<byte[]>>();
        var used = new HashSet<Integer>();
        var next = new int[] {original.exports.size() + createdCount + 1};
        var flags = instanceFlags();
        var none = intern("None");
        var classReference = new int[1];
        var pendingNames = new HashSet<String>();
        Function<Integer, Integer> allocate = ignored -> {
            if (classReference[0] == 0) {
                try {
                    classReference[0] = importPath("Engine.StaticMeshInstance", "Core", "Class");
                } catch (IOException failure) {
                    throw new IllegalStateException(failure.getMessage(), failure);
                }
            }
            var index = next[0]++;
            var suffix = index;
            var name = "StaticMeshInstance" + suffix;
            while (names.contains(name) || pendingNames.contains(name)) {
                name = "StaticMeshInstance" + ++suffix;
            }
            pendingNames.add(name);
            appended.add(new ExportEntry(index, classReference[0], 0, 0, intern(name), flags, 0, 0, 0, 0, 0));
            return index;
        };
        ExportEntry[] templateEntry = new ExportEntry[1];
        Template[] template = new Template[1];
        TextureReplacement replaceTexture = (index, texture) -> {
            if (index <= 0 || index > original.exports.size() || !isBeastTexture(original.exports.get(index - 1))) {
                throw malformed("Beast texture replacement does not name a Beast lightmap texture export");
            }
            var entry = original.exports.get(index - 1);
            var own = BeastTextureCodec.readTemplate(original, entry);
            var saved = BeastTextureCodec.read(original, entry);
            if (saved.width() != texture.width() || saved.height() != texture.height()) {
                throw malformed("A replaced Beast texture must keep its size");
            }
            if (bodies.containsKey(index)) {
                throw malformed("A Beast texture is replaced twice");
            }
            positioned.put(
                    index,
                    offset -> BeastTextureCodec.writeBody(
                            own, texture.width(), texture.height(), texture.mips(), offset));
            bodies.put(
                    index,
                    BeastTextureCodec.writeBody(
                            own, texture.width(), texture.height(), texture.mips(), entry.serialOffset()));
        };
        TextureAppender appendTexture = (name, texture) -> {
            if (template[0] == null) {
                for (var candidate : original.exports) {
                    if (isBeastTexture(candidate)) {
                        templateEntry[0] = candidate;
                        template[0] = BeastTextureCodec.readTemplate(original, candidate);
                        break;
                    }
                }
                if (template[0] == null) {
                    throw malformed("The map has no Beast lightmap texture to copy the texture layout from");
                }
            }
            var layout = template[0];
            var index = next[0]++;
            var unique = name;
            var suffix = 1;
            while (names.contains(unique) || pendingNames.contains(unique)) {
                unique = name + "_" + suffix++;
            }
            pendingNames.add(unique);
            appended.add(new ExportEntry(
                    index,
                    templateEntry[0].classIndex(),
                    0,
                    0,
                    intern(unique),
                    templateEntry[0].flags() & ~0x02000000,
                    0,
                    0,
                    0,
                    0,
                    0));
            positioned.put(
                    index,
                    offset -> BeastTextureCodec.writeBody(
                            layout, texture.width(), texture.height(), texture.mips(), offset));
            bodies.put(
                    index, BeastTextureCodec.writeBody(layout, texture.width(), texture.height(), texture.mips(), 0));
            return index;
        };
        for (var change : lighting.getActors().entrySet()) {
            var state = actorStates.get(change.getKey());
            if (state == null || state.deleted) {
                throw malformed("Rebuilt lighting names an actor that is not in the map: " + change.getKey());
            }
            var actor = change.getValue();
            var existing = state.created ? 0 : instanceReference(state);
            Decoded decoded = null;
            if (existing > 0
                    && owners.getOrDefault(existing, 0) == 1
                    && isInstanceExport(existing)
                    && used.add(existing)) {
                decoded = StaticMeshInstanceCodec.read(original, original.exports.get(existing - 1));
            }
            int lod0;
            if (decoded != null) {
                lod0 = existing;
            } else {
                if (!state.created && !state.editable) {
                    throw malformed("Cannot add lighting to " + state.path + ": " + state.restriction);
                }
                lod0 = allocate.apply(0);
                references.put(state.path, lod0);
            }
            var lod1 = 0;
            if (actor.lod1() != null) {
                lod1 = decoded != null && claimReusable(decoded.lod1(), owners, used)
                        ? decoded.lod1()
                        : allocate.apply(1);
            }
            var lod2 = 0;
            if (actor.lod2SharesLod1()) {
                lod2 = lod1;
            } else if (actor.lod2() != null) {
                lod2 = decoded != null && claimReusable(decoded.lod2(), owners, used)
                        ? decoded.lod2()
                        : allocate.apply(2);
            }
            var beast0 = beastReferences(lod0, 0, actor.lod0(), appended, replaceTexture, appendTexture);
            bodies.put(lod0, instanceBody(lod0, none, actor.lod0(), lod1, lod2, beast0));
            if (actor.lod1() != null) {
                var beast1 = beastReferences(lod1, 1, actor.lod1(), appended, replaceTexture, appendTexture);
                bodies.put(lod1, instanceBody(lod1, none, actor.lod1(), 0, 0, beast1));
            }
            if (actor.lod2() != null) {
                var beast2 = beastReferences(lod2, 2, actor.lod2(), appended, replaceTexture, appendTexture);
                bodies.put(lod2, instanceBody(lod2, none, actor.lod2(), 0, 0, beast2));
            }
        }
        for (var texture : lighting.getTextures().entrySet()) {
            replaceTexture.accept(texture.getKey(), texture.getValue());
        }
        return new LightingPlan(
                Collections.unmodifiableMap(bodies),
                List.copyOf(appended),
                Map.copyOf(references),
                Map.copyOf(positioned));
    }

    private int[] beastReferences(
            int instanceIndex,
            int lod,
            Instance instance,
            List<ExportEntry> appended,
            TextureReplacement replaceTexture,
            TextureAppender appendTexture)
            throws IOException {
        var bake = instance.beast();
        if (bake == null) {
            return new int[0];
        }
        if (original.licenseVersion < UStaticMeshInstance.BEAST_LIGHTMAP_LICENSE) {
            throw malformed("This package version stores no Beast lightmaps");
        }
        if (instanceIndex <= original.exports.size()) {
            var decoded = StaticMeshInstanceCodec.read(original, original.exports.get(instanceIndex - 1));
            var saved = decoded.beastLightmaps();
            if (saved.size() == 2
                    && decoded.beastWidth() == bake.width()
                    && decoded.beastHeight() == bake.height()
                    && isSameSizeBeastTexture(saved.get(0), 0, bake.width(), bake.height())
                    && isSameSizeBeastTexture(saved.get(1), 1, bake.width(), bake.height())) {
                replaceTexture.accept(saved.get(0), bake.slot0());
                replaceTexture.accept(saved.get(1), bake.slot1());
                return new int[] {saved.get(0), saved.get(1)};
            }
        }
        var instanceName = instanceIndex <= original.exports.size()
                ? original.getName(original.exports.get(instanceIndex - 1).objectName())
                : appendedName(appended, instanceIndex);
        var slot0 = appendTexture.apply(instanceName + "_Lightmap_0_" + lod, bake.slot0());
        var slot1 = appendTexture.apply(instanceName + "_Lightmap_1_" + lod, bake.slot1());
        return new int[] {slot0, slot1};
    }

    private boolean isSameSizeBeastTexture(int reference, int slot, int width, int height) throws IOException {
        if (reference <= 0 || reference > original.exports.size()) {
            return false;
        }
        var entry = original.exports.get(reference - 1);
        if (!isBeastTexture(entry) || UnrealLoader.beastLightmapSlotOf(original.getName(entry.objectName())) != slot) {
            return false;
        }
        var saved = BeastTextureCodec.read(original, entry);
        return saved.width() == width && saved.height() == height;
    }

    private String appendedName(List<ExportEntry> appended, int index) {
        for (var entry : appended) {
            if (entry.index() == index) {
                return names.get(entry.objectName());
            }
        }
        throw new IllegalStateException("Unknown appended export " + index);
    }

    private boolean isBeastTexture(ExportEntry entry) throws IOException {
        return original.getClassName(entry).equals("Texture")
                && original.getName(entry.objectName()).contains("_Lightmap_");
    }

    private boolean claimReusable(int reference, Map<Integer, Integer> owners, Set<Integer> used) throws IOException {
        return reference > 0 && !owners.containsKey(reference) && isInstanceExport(reference) && used.add(reference);
    }

    private boolean isInstanceExport(int reference) throws IOException {
        return reference > 0
                && reference <= original.exports.size()
                && original.getClassName(original.exports.get(reference - 1)).equals("StaticMeshInstance")
                && original.getObjectPath(original.exports.get(reference - 1).classIndex())
                        .equalsIgnoreCase("Engine.StaticMeshInstance");
    }

    private byte[] instanceBody(int index, int none, Instance instance, int lod1, int lod2, int[] beast)
            throws IOException {
        var width = instance.beast() == null ? 0 : instance.beast().width();
        var height = instance.beast() == null ? 0 : instance.beast().height();
        if (index > original.exports.size()) {
            return StaticMeshInstanceCodec.write(
                    original.fileVersion, original.licenseVersion, none, instance, lod1, lod2, beast, width, height);
        }
        var entry = original.exports.get(index - 1);
        var decoded = StaticMeshInstanceCodec.read(original, entry);
        var out = new ByteArrayOutputStream();
        out.write(original.body, entry.serialOffset(), decoded.prefixEnd() - entry.serialOffset());
        out.writeBytes(StaticMeshInstanceCodec.writeNative(
                original.fileVersion, original.licenseVersion, instance, lod1, lod2, beast, width, height));
        return out.toByteArray();
    }

    private int instanceFlags() throws IOException {
        for (var entry : original.exports) {
            if (original.getClassName(entry).equals("StaticMeshInstance")) {
                return entry.flags() & ~0x02000000;
            }
        }
        return original.licenseVersion >= 39 ? 0x00060000 : 0x00070000;
    }

    private int instanceReference(ActorState state) throws IOException {
        var tag = tag(state, "StaticMeshInstance");
        if (tag == null) {
            return 0;
        }
        if (tag.type() != 5 || tag.arrayIndex() != 0) {
            throw malformed("Unsupported StaticMeshInstance property layout");
        }
        var cursor = new Cursor(original.body, tag.payload(), tag.end());
        var reference = cursor.readIndex();
        original.checkReference(reference);
        return reference;
    }

    private void verifyLighting(PackageEditDocument verified, ActorLightingChanges lighting) throws IOException {
        for (var change : lighting.getActors().entrySet()) {
            var candidate = verified.actorStates.get(change.getKey());
            if (candidate == null) {
                throw malformed("Lit actor did not round-trip: " + change.getKey());
            }
            var lod0 = verified.instanceReference(candidate);
            var decoded = verified.decodeInstance(lod0);
            var actor = change.getValue();
            verifySameInstance(change.getKey(), actor.lod0(), decoded.instance());
            verified.verifySameBeast(change.getKey(), actor.lod0(), decoded);
            if ((actor.lod1() == null) != (decoded.lod1() == 0)) {
                throw malformed("LOD1 lighting did not round-trip: " + change.getKey());
            }
            if (actor.lod1() != null) {
                var lod1 = verified.decodeInstance(decoded.lod1());
                verifySameInstance(change.getKey(), actor.lod1(), lod1.instance());
                verified.verifySameBeast(change.getKey(), actor.lod1(), lod1);
            }
            if (actor.lod2SharesLod1()
                    ? decoded.lod2() != decoded.lod1()
                    : (actor.lod2() == null) != (decoded.lod2() == 0)) {
                throw malformed("LOD2 lighting did not round-trip: " + change.getKey());
            }
            if (actor.lod2() != null) {
                var lod2 = verified.decodeInstance(decoded.lod2());
                verifySameInstance(change.getKey(), actor.lod2(), lod2.instance());
                verified.verifySameBeast(change.getKey(), actor.lod2(), lod2);
            }
        }
        for (var texture : lighting.getTextures().entrySet()) {
            var saved = BeastTextureCodec.read(verified.original, verified.original.exports.get(texture.getKey() - 1));
            if (!doMipsMatch(texture.getValue().mips(), saved.mips())) {
                throw malformed("Replaced Beast texture did not round-trip: " + texture.getKey());
            }
        }
    }

    private void verifySameBeast(String path, Instance expected, Decoded actual) throws IOException {
        var bake = expected.beast();
        var references = actual.beastLightmaps();
        if (bake == null) {
            if (!references.isEmpty()) {
                throw malformed("Beast lightmaps did not round-trip: " + path);
            }
            return;
        }
        if (references.size() != 2 || actual.beastWidth() != bake.width() || actual.beastHeight() != bake.height()) {
            throw malformed("Beast lightmaps did not round-trip: " + path);
        }
        for (var slot = 0; slot < 2; slot++) {
            var reference = references.get(slot);
            if (reference <= 0 || reference > original.exports.size()) {
                throw malformed("Beast lightmap reference did not round-trip: " + path);
            }
            var entry = original.exports.get(reference - 1);
            if (UnrealLoader.beastLightmapSlotOf(original.getName(entry.objectName())) != slot) {
                throw malformed("Beast lightmap name did not round-trip: " + path);
            }
            var saved = BeastTextureCodec.read(original, entry);
            var texture = slot == 0 ? bake.slot0() : bake.slot1();
            if (saved.width() != texture.width()
                    || saved.height() != texture.height()
                    || !doMipsMatch(texture.mips(), saved.mips())) {
                throw malformed("Beast lightmap texture did not round-trip: " + path);
            }
        }
    }

    private Decoded decodeInstance(int reference) throws IOException {
        if (!isInstanceExport(reference)) {
            throw malformed("StaticMeshInstance reference does not name an instance export");
        }
        return StaticMeshInstanceCodec.read(original, original.exports.get(reference - 1));
    }

    private byte[] buildActor(ActorState state) throws IOException {
        if (state.created) {
            return buildCreatedActor(state);
        }
        var replacements = new LinkedHashMap<String, byte[]>();
        if (!state.transform.location().equals(state.current.location())) {
            replacements.put("Location", encodeVector(state.current.location()));
        }
        if (!state.transform.rotation().equals(state.current.rotation())) {
            replacements.put("Rotation", encodeRotation(state.current.rotation()));
        }
        if (Float.compare(state.transform.drawScale(), state.current.drawScale()) != 0) {
            replacements.put(
                    "DrawScale",
                    littleEndian(new byte[4])
                            .putFloat(state.current.drawScale())
                            .array());
        }
        if (!state.transform.drawScale3d().equals(state.current.drawScale3d())) {
            replacements.put("DrawScale3D", encodeVector(state.current.drawScale3d()));
        }
        if (!state.transform.prePivot().equals(state.current.prePivot())) {
            replacements.put("PrePivot", encodeVector(state.current.prePivot()));
        }
        if (!state.skins.equals(state.originalSkins)) {
            var skins = new ByteArrayOutputStream();
            writeIndex(skins, state.skins.size());
            for (var reference : state.skins) {
                writeIndex(skins, reference);
            }
            replacements.put("Skins", skins.toByteArray());
        }
        var instanceTag = state.lightingInstance == 0 ? null : tag(state, "StaticMeshInstance");
        var out = new ByteArrayOutputStream();
        var position = state.entry.serialOffset();
        for (var tag : state.tags) {
            if (tag == instanceTag) {
                out.write(original.body, position, tag.start() - position);
                var value = new ByteArrayOutputStream();
                writeIndex(value, state.lightingInstance);
                if (value.size() == tag.end() - tag.payload()) {
                    out.write(original.body, tag.start(), tag.payload() - tag.start());
                    out.writeBytes(value.toByteArray());
                } else {
                    writeObjectProperty(out, "StaticMeshInstance", state.lightingInstance);
                }
                position = tag.end();
                continue;
            }
            var key = replacements.keySet().stream()
                    .filter(name -> name.equalsIgnoreCase(tag.name()))
                    .findFirst()
                    .orElse(null);
            var replacement = key == null ? null : replacements.remove(key);
            if (replacement == null) {
                continue;
            }
            out.write(original.body, position, tag.start() - position);
            if (replacement.length == tag.end() - tag.payload()) {
                out.write(original.body, tag.start(), tag.payload() - tag.start());
                out.writeBytes(replacement);
            } else {
                writeProperty(out, key, replacement);
            }
            position = tag.end();
        }
        out.write(original.body, position, state.terminator - position);
        for (var change : replacements.entrySet()) {
            writeProperty(out, change.getKey(), change.getValue());
        }
        if (state.lightingInstance != 0 && instanceTag == null) {
            writeObjectProperty(out, "StaticMeshInstance", state.lightingInstance);
        }
        var end = state.entry.serialOffset() + state.entry.serialSize();
        out.write(original.body, state.terminator, end - state.terminator);
        return out.toByteArray();
    }

    private byte[] buildCreatedActor(ActorState state) throws IOException {
        var out = new ByteArrayOutputStream();
        out.writeBytes(new byte[14]);
        writeProperty(out, "Location", encodeVector(state.current.location()));
        writeProperty(out, "Rotation", encodeRotation(state.current.rotation()));
        writeProperty(
                out,
                "DrawScale",
                littleEndian(new byte[4]).putFloat(state.current.drawScale()).array());
        writeProperty(out, "DrawScale3D", encodeVector(state.current.drawScale3d()));
        writeProperty(out, "PrePivot", encodeVector(state.current.prePivot()));
        var skins = new ByteArrayOutputStream();
        writeIndex(skins, state.skins.size());
        state.skins.forEach(reference -> writeIndex(skins, reference));
        writeProperty(out, "Skins", skins.toByteArray());
        writeObjectProperty(out, "StaticMesh", state.meshReference);
        writeObjectProperty(out, "Level", level.getLevelInfo());
        if (state.lightingInstance != 0) {
            writeObjectProperty(out, "StaticMeshInstance", state.lightingInstance);
        }
        for (var property : state.scalarProperties) {
            writeIndex(out, intern(property.name));
            if (property.type == 3) {
                out.write(3 | (property.truth ? 128 : 0));
            } else {
                out.write(property.type | (property.payload.length == 4 ? 0x20 : 0));
                out.writeBytes(property.payload);
            }
        }
        writeIndex(out, intern("None"));
        out.writeBytes(state.newTail);
        return out.toByteArray();
    }

    private void writeObjectProperty(ByteArrayOutputStream out, String name, int reference) {
        var value = new ByteArrayOutputStream();
        writeIndex(value, reference);
        writeIndex(out, intern(name));
        out.write(5 | 0x50);
        out.write(value.size());
        out.writeBytes(value.toByteArray());
    }

    private void writeProperty(ByteArrayOutputStream out, String name, byte[] payload) {
        writeIndex(out, intern(name));
        var type = name.equals("Skins") ? 9 : name.equals("DrawScale") ? 4 : 10;
        var sizeType = switch (payload.length) {
            case 1 -> 0;
            case 2 -> 1;
            case 4 -> 2;
            case 12 -> 3;
            case 16 -> 4;
            default -> 7;
        };
        out.write(type | sizeType << 4);
        if (type == 10) {
            writeIndex(out, intern(name.equals("Rotation") ? "Rotator" : "Vector"));
        }
        if (sizeType == 7) {
            writeInt(out, payload.length);
        }
        out.writeBytes(payload);
    }

    private int intern(String name) {
        for (var i = 0; i < names.size(); i++) {
            if (names.get(i).equalsIgnoreCase(name)) {
                return i;
            }
        }
        names.add(name);
        return names.size() - 1;
    }

    private ActorState readActor(String path, String className, ExportEntry entry) {
        var state = new ActorState(path, className, entry);
        try {
            var cursor = new Cursor(original.body, entry.serialOffset(), entry.serialOffset() + entry.serialSize());
            if ((entry.flags() & 0x02000000) != 0) {
                var node = cursor.readIndex();
                cursor.readIndex();
                cursor.skip(12);
                if (node != 0) {
                    cursor.readIndex();
                }
            }
            while (true) {
                var start = cursor.position;
                var name = original.getName(cursor.readIndex());
                if (name.equalsIgnoreCase("None")) {
                    state.terminator = start;
                    break;
                }
                var info = cursor.readU8();
                var type = info & 15;
                if (type == 0) {
                    throw malformed("Invalid property type");
                }
                var struct = type == 10 ? original.getName(cursor.readIndex()) : "";
                var size = switch (info >> 4 & 7) {
                    case 0 -> 1;
                    case 1 -> 2;
                    case 2 -> 4;
                    case 3 -> 12;
                    case 4 -> 16;
                    case 5 -> cursor.readU8();
                    case 6 -> cursor.readU16();
                    default -> cursor.readI32();
                };
                var index = type != 3 && (info & 128) != 0 ? cursor.readArrayIndex() : 0;
                var payload = cursor.position;
                original.skipValue(cursor, name, type, size);
                state.tags.add(new Tag(name, type, struct, index, start, payload, cursor.position));
            }
            state.tail = Arrays.copyOfRange(original.body, cursor.position, cursor.end);
            if (state.tail.length != (original.fileVersion < BEAST_TAIL_VERSION ? 0 : 2)) {
                state.relocatable = false;
                state.restriction = "Existing fixed-size properties only; the unaudited native tail is preserved";
            } else if (state.tail.length == 2) {
                state.tailMatchesTags = Arrays.equals(state.tail, taggedBeastScales(state));
            }
            state.transform = new ActorTransform(
                    readVector(state, "Location", Vector3.ZERO),
                    readRotation(state),
                    readScale(state),
                    readVector(state, "DrawScale3D", Vector3.ONE),
                    readVector(state, "PrePivot", Vector3.ZERO));
            var meshTag = tag(state, "StaticMesh");
            if (meshTag != null) {
                if (meshTag.type() != 5 || meshTag.arrayIndex() != 0) {
                    throw malformed("Unsupported StaticMesh property layout");
                }
                var meshCursor = new Cursor(original.body, meshTag.payload(), meshTag.end());
                state.meshReference = meshCursor.readIndex();
                original.checkReference(state.meshReference);
                if (meshCursor.position != meshCursor.end) {
                    throw malformed("Unsupported StaticMesh property padding");
                }
                state.meshPath = original.getObjectPath(state.meshReference);
            }
            var skinTag = tag(state, "Skins");
            if (skinTag != null) {
                if (skinTag.type() != 9 || skinTag.arrayIndex() != 0) {
                    throw malformed("Unsupported Skins property layout");
                }
                var skinCursor = new Cursor(original.body, skinTag.payload(), skinTag.end());
                var count = PackageBytes.count(skinCursor.readIndex());
                if (count > MAX_SKIN_SLOTS) {
                    throw malformed("Too many authored material slots");
                }
                for (var i = 0; i < count; i++) {
                    var reference = skinCursor.readIndex();
                    original.checkReference(reference);
                    state.originalSkins.add(reference);
                }
                if (skinCursor.position != skinCursor.end) {
                    throw malformed("Unsupported Skins property padding");
                }
            }
        } catch (IOException | IllegalArgumentException failure) {
            state.restriction = failure.getMessage();
            state.editable = false;
        }
        state.current = state.transform;
        state.skins = new ArrayList<>(state.originalSkins);
        state.savedTransform = state.current;
        state.savedSkins = List.copyOf(state.skins);
        return state;
    }

    private byte[] taggedBeastScales(ActorState state) {
        var values = new byte[BEAST_PROPERTIES.size()];
        for (var tag : state.tags) {
            for (var i = 0; i < BEAST_PROPERTIES.size(); i++) {
                if (!tag.name().equalsIgnoreCase(BEAST_PROPERTIES.get(i))) {
                    continue;
                }
                if (tag.type() != 1 || tag.arrayIndex() != 0 || tag.end() - tag.payload() != 1) {
                    return null;
                }
                values[i] = original.body[tag.payload()];
            }
        }
        return values;
    }

    private Tag tag(ActorState state, String name) throws IOException {
        Tag found = null;
        for (var tag : state.tags) {
            if (tag.name().equalsIgnoreCase(name)) {
                if (found != null) {
                    throw malformed("Duplicate authored property " + name);
                }
                found = tag;
            }
        }
        return found;
    }

    private Vector3 readVector(ActorState state, String name, Vector3 fallback) throws IOException {
        var tag = tag(state, name);
        if (tag == null) {
            return fallback;
        }
        validateStruct(tag, "Vector");
        var input = littleEndian(original.body);
        return new Vector3(
                input.getFloat(tag.payload()), input.getFloat(tag.payload() + 4), input.getFloat(tag.payload() + 8));
    }

    private Rotator readRotation(ActorState state) throws IOException {
        var tag = tag(state, "Rotation");
        if (tag == null) {
            return new Rotator(0, 0, 0);
        }
        validateStruct(tag, "Rotator");
        var input = littleEndian(original.body);
        return new Rotator(
                input.getInt(tag.payload()), input.getInt(tag.payload() + 4), input.getInt(tag.payload() + 8));
    }

    private void validateStruct(Tag tag, String struct) throws IOException {
        if (tag.type() != 10
                || !tag.struct().equalsIgnoreCase(struct)
                || tag.arrayIndex() != 0
                || tag.end() - tag.payload() != 12) {
            throw malformed("Unsupported " + tag.name() + " property layout");
        }
    }

    private float readScale(ActorState state) throws IOException {
        var tag = tag(state, "DrawScale");
        if (tag == null) {
            return 1f;
        }
        if (tag.type() != 4 || tag.arrayIndex() != 0 || tag.end() - tag.payload() != 4) {
            throw malformed("Unsupported DrawScale property layout");
        }
        return littleEndian(original.body).getFloat(tag.payload());
    }

    private static String surfaceKey(int surface) {
        return "#bsp-surface-" + surface;
    }

    private static boolean names(Instance instance, Set<Integer> lights) {
        return instance.sceneLights().stream().anyMatch(light -> lights.contains(light.reference()));
    }

    private static Instance unapplied(Instance instance, Set<Integer> lights) {
        var scene = instance.sceneLights().stream()
                .map(light ->
                        lights.contains(light.reference()) ? new Light(light.reference(), light.rawBits(), 0) : light)
                .toList();
        return new Instance(
                instance.vertexCount(), instance.rawColors(), instance.revision(), scene, instance.environmentLights());
    }

    private static void validateAssetOuter(PackageBytes packageBytes, int outer) throws IOException {
        while (outer != 0) {
            if (outer > 0) {
                var entry = packageBytes.exports.get(outer - 1);
                if (!packageBytes.getClassName(entry).equals("Package")) {
                    throw malformed("Asset is nested inside a non-package object");
                }
                outer = entry.outer();
            } else {
                var entry = packageBytes.imports.get(-outer - 1);
                if (!packageBytes.getName(entry.className()).equals("Package")) {
                    throw malformed("Asset import has a non-package outer");
                }
                outer = entry.outer();
            }
        }
    }

    private static boolean doMipsMatch(List<byte[]> expected, List<byte[]> actual) {
        if (expected.size() != actual.size()) {
            return false;
        }
        for (var i = 0; i < expected.size(); i++) {
            if (!Arrays.equals(expected.get(i), actual.get(i))) {
                return false;
            }
        }
        return true;
    }

    private static void verifySameInstance(String path, Instance expected, Instance actual) throws IOException {
        if (expected.vertexCount() != actual.vertexCount()
                || expected.revision() != actual.revision()
                || !Arrays.equals(expected.rawColors(), actual.rawColors())
                || !lightsMatch(expected.sceneLights(), actual.sceneLights())
                || !lightsMatch(expected.environmentLights(), actual.environmentLights())) {
            throw malformed("Rebuilt lighting did not round-trip: " + path);
        }
    }

    private static boolean lightsMatch(List<Light> expected, List<Light> actual) {
        if (expected.size() != actual.size()) {
            return false;
        }
        for (var i = 0; i < expected.size(); i++) {
            var a = expected.get(i);
            var b = actual.get(i);
            if (a.reference() != b.reference()
                    || a.applied() != b.applied()
                    || !Arrays.equals(a.rawBits(), b.rawBits())) {
                return false;
            }
        }
        return true;
    }

    private static byte[] encodeVector(Vector3 value) {
        return littleEndian(new byte[12])
                .putFloat(value.x())
                .putFloat(value.y())
                .putFloat(value.z())
                .array();
    }

    private static byte[] encodeRotation(Rotator value) {
        return littleEndian(new byte[12])
                .putInt(value.pitch())
                .putInt(value.yaw())
                .putInt(value.roll())
                .array();
    }
}
