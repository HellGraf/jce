package com.rost.cruma.core.spawn;

import com.rost.cruma.core.npc.LegacyItemLooks;
import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.L2TextTable;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class WeaponGrpTable {
    private static final int SHIELD = 0;
    private static final int ONE_HANDED = 1;
    private static final int TWO_HANDED = 2;
    private static final int DUAL = 3;
    private static final int POLE = 4;
    private static final int BOW = 5;

    private final Map<Integer, Weapon> byId;
    private final Map<Integer, String> icons;

    private WeaponGrpTable(Map<Integer, Weapon> byId) {
        this(byId, Map.of());
    }

    private WeaponGrpTable(Map<Integer, Weapon> byId, Map<Integer, String> icons) {
        this.byId = Map.copyOf(byId);
        this.icons = Map.copyOf(icons);
    }

    public record Weapon(int id, int handness, List<String> meshes, List<String> textures) {}

    static WeaponGrpTable of(Map<Integer, Weapon> weapons) {
        return new WeaponGrpTable(weapons);
    }

    public static WeaponGrpTable empty() {
        return new WeaponGrpTable(Map.of());
    }

    public static WeaponGrpTable read(Path system) throws IOException {
        return read(system, WorldVariant.MAIN);
    }

    public static WeaponGrpTable read(Path system, WorldVariant variant) throws IOException {
        var file = variant.find(system, "Weapongrp.dat");
        if (file == null) {
            var text = variant.find(system, "weapongrp.txt");
            if (text != null) {
                return parseText(L2TextTable.read(text));
            }
            throw new IOException("No Weapongrp.dat in " + system);
        }
        var namesFile = find(system, "L2GameDataName.dat");
        if (namesFile != null) {
            return parse(L2DataFile.read(file), NpcGrpTable.gameDataNames(L2DataFile.read(namesFile)));
        }
        var legacy = LegacyItemLooks.readWeapons(L2DataFile.read(file));
        if (legacy == null) {
            throw new IOException(file.getFileName() + " matches no known layout");
        }
        var weapons = new HashMap<Integer, Weapon>(legacy.size() * 2);
        var icons = new HashMap<Integer, String>(legacy.size() * 2);
        for (var weapon : legacy) {
            weapons.putIfAbsent(
                    weapon.id(), new Weapon(weapon.id(), weapon.handness(), weapon.meshes(), weapon.textures()));
            if (weapon.icon() != null
                    && !weapon.icon().isBlank()
                    && !weapon.icon().equalsIgnoreCase("None")) {
                icons.putIfAbsent(weapon.id(), weapon.icon());
            }
        }
        return new WeaponGrpTable(weapons, icons);
    }

    static WeaponGrpTable parseText(List<Map<String, String>> records) throws IOException {
        var weapons = new HashMap<Integer, Weapon>(records.size() * 2);
        var icons = new HashMap<Integer, String>(records.size() * 2);
        for (var record : records) {
            var id = L2TextTable.integer(record, "object_id", -1);
            if (id < 0) {
                continue;
            }
            weapons.putIfAbsent(
                    id,
                    new Weapon(
                            id,
                            handness(record),
                            L2TextTable.references(record.get("mesh")),
                            L2TextTable.references(record.get("texture"))));
            var icon = L2TextTable.references(record.get("icon"));
            if (!icon.isEmpty()) {
                icons.putIfAbsent(id, icon.getFirst());
            }
        }
        if (weapons.isEmpty()) {
            throw new IOException("weapongrp.txt has no item records");
        }
        return new WeaponGrpTable(weapons, icons);
    }

    static WeaponGrpTable parse(byte[] bytes, List<String> names) throws IOException {
        var data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        var count = data.getInt();
        var weapons = new HashMap<Integer, Weapon>(count * 2);
        var icons = new HashMap<Integer, String>(count * 2);
        try {
            for (var record = 0; record < count; record++) {
                u8(data);
                var id = data.getInt();
                skip(data, 4);
                var drops = u8(data);
                for (var i = 0; i < drops; i++) {
                    data.getInt();
                    skip(data, u8(data) * 4);
                }
                var icon = name(data.getInt(), names);
                skip(data, 4 * 4);
                if (!icon.isEmpty() && !icon.equalsIgnoreCase("None")) {
                    icons.putIfAbsent(id, icon);
                }
                skip(data, 2 + 2 + 1 + 1);
                skip(data, u8(data) * 2);
                skip(data, 1 + 1 + 2 + 4 + 4 + 1);
                u8(data);
                var handness = u8(data);
                var meshCount = u8(data);
                var meshes = new ArrayList<String>(meshCount);
                for (var i = 0; i < meshCount; i++) {
                    meshes.add(name(data.getInt(), names));
                }
                skip(data, meshCount);
                var textureCount = u8(data);
                var textures = new ArrayList<String>(textureCount);
                for (var i = 0; i < textureCount; i++) {
                    textures.add(name(data.getInt(), names));
                }
                skip(data, u8(data) * 4);
                skip(data, 4 + 4 + 4);
                skip(data, 1 + 1 + 1 + 1 + 1 + 1 + 2 + 1 + 1 + 1 + 4 + 2);
                skip(data, u8(data) * (4 + 12 + 12 + 12 + 4 + 4 + 4 + 12 + 12 + 12));
                skip(data, 6);
                skip(data, u8(data) * 4);
                skip(data, 2);
                weapons.putIfAbsent(id, new Weapon(id, handness, List.copyOf(meshes), List.copyOf(textures)));
            }
        } catch (RuntimeException failure) {
            throw new IOException("Weapongrp.dat does not match the P152 layout: " + failure.getMessage(), failure);
        }
        if (data.remaining() > 32) {
            throw new IOException("Weapongrp.dat does not match the P152 layout: " + data.remaining() + " bytes left");
        }
        return new WeaponGrpTable(weapons, icons);
    }

    public String getIcon(int itemId) {
        return icons.get(itemId);
    }

    public Map<Integer, String> getIcons() {
        return icons;
    }

    public List<Weapon> getAll() {
        return byId.values().stream()
                .sorted(Comparator.comparingInt(Weapon::id))
                .toList();
    }

    public Weapon getWeapon(int itemId) {
        return byId.get(itemId);
    }

    public int size() {
        return byId.size();
    }

    private static int u8(ByteBuffer data) {
        return data.get() & 0xff;
    }

    private static void skip(ByteBuffer data, int bytes) {
        data.position(data.position() + bytes);
    }

    private static String name(int index, List<String> names) {
        return index >= 0 && index < names.size() ? NpcGrpTable.cleanReference(names.get(index)) : "";
    }

    private static int handness(Map<String, String> record) {
        var part = record.getOrDefault("body_part", "").toLowerCase(Locale.ROOT);
        var type = record.getOrDefault("weapon_type", "").strip().toLowerCase(Locale.ROOT);
        if (part.contains("lrhand")) {
            return switch (type) {
                case "bow" -> BOW;
                case "pole" -> POLE;
                case "dual", "dualfist" -> DUAL;
                default -> TWO_HANDED;
            };
        }
        return part.contains("lhand") ? SHIELD : ONE_HANDED;
    }

    private static Path find(Path folder, String name) throws IOException {
        if (!Files.isDirectory(folder)) {
            return null;
        }
        try (var entries = Files.list(folder)) {
            return entries.filter(path -> path.getFileName().toString().equalsIgnoreCase(name))
                    .findFirst()
                    .orElse(null);
        }
    }
}
