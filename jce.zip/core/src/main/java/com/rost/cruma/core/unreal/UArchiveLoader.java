package com.rost.cruma.core.unreal;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

public class UArchiveLoader {
    private static final Set<String> REPORTED_MISSING_ARCHIVES = ConcurrentHashMap.newKeySet();

    private static final Logger log = LogManager.getLogger(UArchiveLoader.class);

    private final Path rootPath;
    private final List<USearchConfig> configs;
    private final Map<String, UArchive> archives = new HashMap<>();
    private final Map<Path, Map<String, Path>> directoryEntries = new HashMap<>();
    private final Set<String> missingArchives = new HashSet<>();
    private final @Nullable DecryptedPackages sharedPackages;

    public UArchiveLoader(Path rootPath, List<USearchConfig> configs) {
        this(rootPath, configs, null);
    }

    public UArchiveLoader(Path rootPath, List<USearchConfig> configs, @Nullable DecryptedPackages sharedPackages) {
        this.rootPath = rootPath;
        this.configs = configs;
        this.sharedPackages = sharedPackages;
    }

    public record USearchConfig(String directory, String extension) {}

    public @Nullable UArchive loadArchive(String name) {
        return loadArchive(name, true);
    }

    public @Nullable UArchive loadArchiveIfPresent(String name) {
        return loadArchive(name, false);
    }

    public UArchive createMemoryArchive(String name, ByteBuffer body) {
        return new UArchive(name, body, this);
    }

    public @Nullable UArchive replaceArchive(String name, UArchive archive) {
        missingArchives.remove(name);
        return archives.put(name, archive);
    }

    public void restoreArchive(String name, @Nullable UArchive previous) {
        if (previous == null) {
            archives.remove(name);
        } else {
            archives.put(name, previous);
        }
    }

    public void removeArchive(String name) {
        var removed = archives.remove(name);
        if (removed != null) {
            removed.close();
        }
    }

    public int getArchiveCount() {
        return archives.size();
    }

    public void clearArchives() {
        for (var archive : archives.values()) {
            archive.close();
        }
        archives.clear();
    }

    private @Nullable UArchive loadArchive(String name, boolean warnIfMissing) {
        var archive = archives.get(name);
        if (archive != null) {
            return archive;
        }
        if (missingArchives.contains(name)) {
            reportMissing(name, warnIfMissing);
            return null;
        }

        for (var config : configs) {
            var directory = rootPath.resolve(config.directory());
            if (!Files.isDirectory(directory)) {
                directory = caseInsensitiveEntry(rootPath, config.directory());
            }
            if (directory == null) {
                continue;
            }
            var filename = name + "." + config.extension();
            var path = directory.resolve(filename);
            if (!Files.isRegularFile(path)) {
                path = caseInsensitiveEntry(directory, filename);
            }
            if (path != null && Files.isRegularFile(path)) {
                log.debug("Loading archive package: {}", name);
                archive = loadArchive(name, path);
                archives.put(name, archive);
                return archive;
            }
        }

        missingArchives.add(name);
        reportMissing(name, warnIfMissing);
        return null;
    }

    private @Nullable Path caseInsensitiveEntry(Path directory, String name) {
        var entries = directoryEntries.computeIfAbsent(directory, source -> {
            var result = new HashMap<String, Path>();
            try (var children = Files.list(source)) {
                children.sorted()
                        .forEach(path ->
                                result.putIfAbsent(path.getFileName().toString().toLowerCase(Locale.ROOT), path));
            } catch (IOException failure) {
                log.debug("Cannot list package directory: {}", source, failure);
            }
            return result;
        });
        return entries.get(name.toLowerCase(Locale.ROOT));
    }

    private void reportMissing(String name, boolean warnIfMissing) {
        if (!warnIfMissing) {
            return;
        }
        var normalizedName = name.toLowerCase(Locale.ROOT);
        var reportKey = rootPath.toAbsolutePath().normalize() + "\0" + normalizedName;
        if (REPORTED_MISSING_ARCHIVES.add(reportKey)) {
            log.warn(
                    "Archive package not found: {} " + "(identical misses from parallel loaders will be DEBUG-only)",
                    name);
        } else {
            log.debug("Repeated missing archive package: {}", name);
        }
    }

    private UArchive loadArchive(String name, Path path) {
        var decrypted = sharedPackages == null ? UDecryptor.decryptManaged(path) : sharedPackages.open(path);
        final UArchive archive;
        try {
            archive = new UArchive(name, decrypted, this);
        } catch (Throwable failure) {
            decrypted.close();
            throw failure;
        }
        var header = archive.getHeader();
        log.debug(
                "Loaded archive package: {} (file ver: {}, license ver: {})",
                name,
                header.getFileVersion(),
                header.getLicenseVersion());
        return archive;
    }
}
