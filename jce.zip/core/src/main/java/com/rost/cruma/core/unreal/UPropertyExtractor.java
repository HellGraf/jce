package com.rost.cruma.core.unreal;

import com.rost.cruma.core.unreal.UProperty.Type;
import com.rost.cruma.core.unreal.primitives.UColor;
import com.rost.cruma.core.unreal.primitives.URotator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UPropertyExtractor {
    private static final Logger log = LogManager.getLogger(UPropertyExtractor.class);
    private static final Set<String> REGION_FIELDS = Set.of("Zone", "iLeaf", "ZoneNumber");
    private static final Set<String> SKILL_PHASES = Set.of(
            "CastingAction", "ChannelingAction", "PreshotAction", "ShotAction", "ExplosionAction", "UnionTargetAction");
    private final UArchive archive;

    public UPropertyExtractor(UArchive archive) {
        this.archive = archive;
    }

    public static boolean isRegionLongerThanItsTag(
            String structName, Collection<String> fields, long consumed, long size) {
        return "PointRegion".equals(structName)
                && consumed > size
                && consumed - size <= 2
                && fields.contains("Zone")
                && REGION_FIELDS.containsAll(fields);
    }

    public List<UProperty> extractProperties() {
        var properties = new ArrayList<UProperty>();

        while (true) {
            var property = extractProperty();
            if (property == null) {
                break;
            }
            properties.add(property);
        }

        return properties;
    }

    private UProperty extractProperty() {
        var name = archive.readName();
        if (UArchive.NONE_NAME.equals(name)) {
            return null;
        }

        var builder = UProperty.builder().name(name);

        var info = archive.readUInt8();
        var type = Type.fromId(info & 0x0F);
        var sizeType = (info >> 4) & 0x07;
        var isArray = ((info >> 7) & 0x01) == 1;

        builder.info(info).type(type).sizeType(sizeType).array(isArray);

        var structName = "";
        if (type == Type.Struct) {
            structName = archive.readName();
            builder.structName(structName);
        }

        var size = extractSize(sizeType, archive);
        builder.size(size);

        if (type == Type.Bool) {
            return builder.build();
        }

        if (isArray) {
            builder.arrayIndex(archive.readArrayIndex());
        }

        var subProperties = new ArrayList<Map<String, UProperty>>();

        switch (type) {
            case Type.Byte -> builder.uInt8Value(archive.readUInt8());
            case Type.Int -> builder.int32Value(archive.readInt());
            case Type.Float -> builder.floatValue(archive.readFloat());
            case Type.Object, Type.Name -> builder.indexValue(archive.readIndex());
            case Type.Array -> {
                var startPosition = archive.getOffset();
                var propertyArraySize = archive.readIndex();
                builder.arraySize(propertyArraySize);

                int sizeSize = archive.getOffset() - startPosition;
                int arraySize = (int) (size - sizeSize);

                if (name.equals("Materials")
                        || name.equals("NpcInfo")
                        || name.equals("PcInfo")
                        || name.equals("VisualItemList")) {
                    int arrayStartPosition = archive.getOffset();
                    try {
                        for (int i = 0; i < propertyArraySize; ++i) {
                            subProperties.add(extractPropertiesMap());
                        }
                    } catch (RuntimeException e) {
                        subProperties.clear();
                    }
                    if (archive.getOffset() - arrayStartPosition != arraySize) {
                        archive.setPosition(arrayStartPosition + arraySize);
                    }
                } else if (name.equals("Emitters")
                        || SKILL_PHASES.contains(name)
                        || name.equals("Skins")
                        || name.equals("CustomMaterials")
                        || name.equals("SpawnSound")
                        || name.equals("ManualExcludes")) {
                    int arrayStartPosition = archive.getOffset();
                    var refs = new int[propertyArraySize];
                    for (int i = 0; i < propertyArraySize; ++i) {
                        refs[i] = archive.readIndex();
                    }
                    int consumed = archive.getOffset() - arrayStartPosition;
                    if (consumed < arraySize) {
                        archive.skipBytes(arraySize - consumed);
                    }
                    builder.objectArray(refs);
                } else if (name.equals("ColorScale")
                        || name.equals("BeamEndPoints")
                        || name.equals("SizeScale")
                        || name.equals("RevolutionScale")
                        || name.equals("WeatherRangeTime")
                        || name.equals("DecoLayers")
                        || (name.equals("Colors") && propertyArraySize > 0 && propertyArraySize <= arraySize / 6)) {
                    int arrayStartPosition = archive.getOffset();
                    try {
                        for (int i = 0; i < propertyArraySize; ++i) {
                            subProperties.add(extractPropertiesMap());
                        }
                    } catch (RuntimeException e) {
                        subProperties.clear();
                    }
                    int consumed = archive.getOffset() - arrayStartPosition;
                    var validL2FogColors = !name.equals("Colors")
                            || (consumed == arraySize
                                    && subProperties.size() == propertyArraySize
                                    && subProperties.stream()
                                            .allMatch(element -> element.containsKey("Time")
                                                    && element.containsKey("FogColor")
                                                    && element.containsKey("SkyColor")
                                                    && element.containsKey("CloudColor")
                                                    && element.containsKey("HazeRingColor")));
                    if (consumed != arraySize || !validL2FogColors) {
                        subProperties.clear();
                        archive.setPosition(arrayStartPosition + arraySize);
                    }
                    if (name.equals("Colors") && !validL2FogColors) {
                        archive.setPosition(arrayStartPosition);
                        var dataValue = new short[arraySize];
                        for (int i = 0; i < arraySize; ++i) {
                            dataValue[i] = archive.readUInt8();
                        }
                        builder.dataValue(dataValue);
                    }
                } else if (name.equals("StateFog")) {
                    int arrayStartPosition = archive.getOffset();
                    try {
                        for (int i = 0; i < propertyArraySize; ++i) {
                            subProperties.add(extractPropertiesMap());
                        }
                    } catch (RuntimeException e) {
                        subProperties.clear();
                    }
                    if (archive.getOffset() - arrayStartPosition != arraySize
                            || subProperties.size() != propertyArraySize) {
                        subProperties.clear();
                        archive.setPosition(arrayStartPosition);
                        var dataValue = new short[arraySize];
                        for (int i = 0; i < arraySize; ++i) {
                            dataValue[i] = archive.readUInt8();
                        }
                        builder.dataValue(dataValue);
                    }
                } else if (name.equals("ZonePlayState")) {
                    int arrayStartPosition = archive.getOffset();
                    if (propertyArraySize > 0 && arraySize == propertyArraySize * 4L) {
                        var states = new int[propertyArraySize];
                        for (int i = 0; i < propertyArraySize; ++i) {
                            states[i] = archive.readInt();
                        }
                        builder.intArray(states);
                    } else {
                        var dataValue = new short[arraySize];
                        for (int i = 0; i < arraySize; ++i) {
                            dataValue[i] = archive.readUInt8();
                        }
                        builder.dataValue(dataValue);
                    }
                    archive.setPosition(arrayStartPosition + arraySize);
                } else if (name.equals("ZoneRenderState")) {
                    int arrayStartPosition = archive.getOffset();
                    try {
                        for (int i = 0; i < propertyArraySize; ++i) {
                            subProperties.add(extractPropertiesMap());
                        }
                    } catch (RuntimeException e) {
                        subProperties.clear();
                    }
                    var zoneStates = subProperties.size() == propertyArraySize
                            && subProperties.stream().allMatch(element -> element.containsKey("ZoneState"));
                    if (!zoneStates || archive.getRemainingInObject() < 0) {
                        subProperties.clear();
                        archive.setPosition(arrayStartPosition);
                        if (propertyArraySize > 0 && arraySize == propertyArraySize * 4L) {
                            var states = new int[propertyArraySize];
                            for (int i = 0; i < propertyArraySize; ++i) {
                                states[i] = archive.readInt();
                            }
                            builder.intArray(states);
                        }
                        archive.setPosition(arrayStartPosition + arraySize);
                    }
                } else {
                    var dataValue = new short[arraySize];
                    for (int i = 0; i < arraySize; ++i) {
                        dataValue[i] = archive.readUInt8();
                    }
                    builder.dataValue(dataValue);
                }
            }
            case Type.Struct -> {
                switch (structName) {
                    case "Rotator" ->
                        builder.rotatorValue(new URotator(archive.readInt(), archive.readInt(), archive.readInt()));
                    case "Vector" -> builder.vectorValue(archive.readVector());
                    case "TerrainLayer" -> subProperties.add(extractPropertiesMap());
                    case "Color" -> builder.colorValue(UColor.of(archive));
                    case "Range", "RangeVector", "PointRegion", "Plane", "CameraItem", "ScreenItem", "MusicItem" -> {
                        var startPos = archive.getOffset();
                        try {
                            var map = extractPropertiesMap();
                            var consumed = archive.getOffset() - startPos;
                            if (consumed == size
                                    || isRegionLongerThanItsTag(structName, map.keySet(), consumed, size)) {
                                subProperties.add(map);
                            } else {
                                archive.skipBytes((int) (size - (archive.getOffset() - startPos)));
                            }
                        } catch (RuntimeException e) {
                            archive.skipBytes((int) (size - (archive.getOffset() - startPos)));
                        }
                    }
                    default -> {
                        log.debug("Unknown struct: {}", structName);
                        archive.skipBytes((int) size);
                    }
                }
            }
            case Type.Vector -> builder.vectorValue(archive.readVector());
            case Type.Rotator -> builder.rotatorValue(URotator.of(archive));
            case Type.Str -> {
                var startPos = archive.getOffset();
                try {
                    builder.stringValue(archive.readString());
                } catch (RuntimeException e) {
                    log.debug("Unreadable string: {}", name);
                }
                archive.setPosition(startPos + (int) size);
            }
            default -> {
                log.debug("Unknown property type: {}", type);
                archive.skipBytes((int) size);
            }
        }

        return builder.subProperties(subProperties).build();
    }

    private Map<String, UProperty> extractPropertiesMap() {
        var propertiesByNames = new HashMap<String, UProperty>();
        var properties = extractProperties();
        for (var property : properties) {
            var name = property.getName();
            var earlier = propertiesByNames.put(name, property);
            if (property.getArrayIndex() > 0) {
                propertiesByNames.put(name + "[" + property.getArrayIndex() + "]", property);
                if (earlier != null && earlier.getArrayIndex() == 0) {
                    propertiesByNames.put(name + "[0]", earlier);
                }
            } else if (earlier != null) {
                log.debug("Property already exists: {}", name);
            }
        }
        return propertiesByNames;
    }

    private static long extractSize(int sizeType, UArchive archive) {
        return switch (sizeType) {
            case 0 -> 1;
            case 1 -> 2;
            case 2 -> 4;
            case 3 -> 12;
            case 4 -> 16;
            case 5 -> archive.readUInt8();
            case 6 -> archive.readUInt16();
            case 7 -> archive.readUInt32();
            default -> throw new IllegalArgumentException("Unknown size type: " + sizeType);
        };
    }
}
