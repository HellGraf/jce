package com.rost.cruma.core.world;

import com.rost.cruma.core.audio.SoundClip;
import glm_.vec3.Vec3;

public record AmbientSound(
        Vec3 position,
        float radius,
        float volume,
        float pitch,
        Type type,
        int randomSeconds,
        SoundClip clip,
        String actor,
        int zoneStateMask,
        int zoneDefault) {
    public AmbientSound {
        if (position == null || type == null || clip == null) {
            throw new IllegalArgumentException("an ambient sound needs its position, type and clip");
        }
        if (radius <= 0f || !Float.isFinite(radius)) {
            throw new IllegalArgumentException("SoundRadius must be positive, got " + radius);
        }
        position = new Vec3(position);
        volume = Math.clamp(volume, 0f, 1f);
        pitch = pitch > 0f && Float.isFinite(pitch) ? pitch : 1f;
        randomSeconds = Math.max(0, randomSeconds);
        actor = actor == null ? "" : actor;
    }

    public AmbientSound(
            Vec3 position,
            float radius,
            float volume,
            float pitch,
            Type type,
            int randomSeconds,
            SoundClip clip,
            String actor) {
        this(position, radius, volume, pitch, type, randomSeconds, clip, actor, 0, 0);
    }

    public AmbientSound(
            Vec3 position, float radius, float volume, float pitch, Type type, int randomSeconds, SoundClip clip) {
        this(position, radius, volume, pitch, type, randomSeconds, clip, "");
    }

    public enum Type {
        ALWAYS,
        DAY,
        NIGHT,
        WATER;

        public static Type of(int ordinal) {
            var values = values();
            return ordinal >= 0 && ordinal < values.length ? values[ordinal] : ALWAYS;
        }
    }

    public boolean isLooping() {
        return randomSeconds == 0;
    }

    public boolean playsInZoneState(int choice) {
        return MapEventState.showsInZoneState(zoneStateMask, zoneDefault, choice);
    }

    public float gainAt(float distance) {
        if (distance <= radius) {
            return volume;
        }
        return volume * radius / distance;
    }
}
