package com.rost.cruma.core.editing;

import java.util.List;

public record ActorRecord(
        String sourcePath,
        int exportIndex,
        String className,
        ActorTransform transform,
        List<Integer> skinReferences,
        boolean editable,
        String restriction,
        String meshSourcePath,
        String templateSourcePath,
        boolean created) {
    public ActorRecord {
        skinReferences = List.copyOf(skinReferences);
    }
}
