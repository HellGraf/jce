package com.rost.cruma.core.unreal;

import com.rost.cruma.core.unreal.UObject.ObjectFlags;
import com.rost.cruma.core.unreal.UObject.StateFrame;
import com.rost.cruma.core.unreal.primitives.URotator;
import glm_.vec3.Vec3;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.jetbrains.annotations.Nullable;

public final class SkillEffects {
    public static final int AM_NONE = 0;

    public static final int AM_LOCATION = 1;
    public static final int AM_RH = 2;
    public static final int AM_LH = 3;
    public static final int AM_RA = 4;
    public static final int AM_LA = 5;
    public static final int AM_WING = 6;
    public static final int AM_BONE_SPECIFIED = 7;
    public static final int AM_ALIAS_SPECIFIED = 8;
    public static final int AM_TRAIL = 9;
    public static final int AM_AGATHION = 10;

    public record Action(
            String effect,
            int attachOn,
            String bone,
            boolean onTarget,
            boolean onMultiTarget,
            boolean relativeToCylinder,
            Vec3 offset,
            float scale,
            float delay,
            boolean absolute,
            URotator turn) {
        public static final URotator NO_TURN = new URotator(0, 0, 0);

        public Action(
                String effect,
                int attachOn,
                String bone,
                boolean onTarget,
                boolean onMultiTarget,
                boolean relativeToCylinder,
                Vec3 offset,
                float scale,
                float delay) {
            this(
                    effect,
                    attachOn,
                    bone,
                    onTarget,
                    onMultiTarget,
                    relativeToCylinder,
                    offset,
                    scale,
                    delay,
                    false,
                    NO_TURN);
        }
    }

    public record Skill(int skillId, String className, float flyingTime, Map<Phase, List<Action>> phases) {
        public Skill {
            var copy = new EnumMap<Phase, List<Action>>(Phase.class);
            phases.forEach((phase, actions) -> copy.put(phase, List.copyOf(actions)));
            phases = copy;
        }

        public List<Action> actions(Phase phase) {
            return phases.getOrDefault(phase, List.of());
        }

        public int count() {
            return phases.values().stream().mapToInt(List::size).sum();
        }
    }

    private SkillEffects() {}

    public enum Phase {
        CASTING("CastingAction"),
        CHANNELING("ChannelingAction"),
        PRESHOT("PreshotAction"),
        SHOT("ShotAction"),
        EXPLOSION("ExplosionAction"),
        UNION_TARGET("UnionTargetAction");

        private final String property;

        Phase(String property) {
            this.property = property;
        }

        public String getProperty() {
            return property;
        }
    }

    public static List<Skill> list(UArchive archive) {
        var exports = archive.getExportMap();
        var skills = new ArrayList<Skill>();
        for (var index = 1; index <= exports.size(); index++) {
            var export = exports.get(index - 1);
            if (!"None".equals(export.getClassName()) || !"L2SkillEffect".equals(export.getSuperName())) {
                continue;
            }
            var skill = skill(archive, index);
            if (skill != null) {
                skills.add(skill);
            }
        }
        skills.sort(Comparator.comparingInt(Skill::skillId).thenComparing(Skill::className));
        return List.copyOf(skills);
    }

    public static String key(String effectPath) {
        return effectPath.toLowerCase(Locale.ROOT);
    }

    private static @Nullable Skill skill(UArchive archive, int index) {
        var defaults = EffectClasses.defaults(archive, index);
        if (defaults == null) {
            return null;
        }
        var name = archive.getExportMap().get(index - 1).getObjectName();
        var skillId = idOf(name);
        var flyingTime = 0f;
        var phases = new EnumMap<Phase, List<Action>>(Phase.class);
        for (var property : defaults) {
            switch (property.getName()) {
                case "SkillID" -> {
                    if (skillId < 0) {
                        skillId = property.getInt32Value();
                    }
                }
                case "FlyingTime" -> flyingTime = property.getFloatValue();
                default -> {
                    for (var phase : Phase.values()) {
                        if (phase.property.equals(property.getName()) && property.getObjectArray() != null) {
                            var actions = new ArrayList<Action>();
                            for (var ref : property.getObjectArray()) {
                                var action = action(archive, ref);
                                if (action != null) {
                                    actions.add(action);
                                }
                            }
                            phases.put(phase, actions);
                        }
                    }
                }
            }
        }
        return skillId < 0 ? null : new Skill(skillId, name, flyingTime, phases);
    }

    private static int idOf(String className) {
        var matcher = Pattern.compile("(?i)l2_(\\d+)_skill").matcher(className);
        return matcher.matches() ? Integer.parseInt(matcher.group(1)) : -1;
    }

    private static @Nullable Action action(UArchive archive, int ref) {
        if (ref <= 0 || ref > archive.getExportMap().size()) {
            return null;
        }
        var export = archive.getExportMap().get(ref - 1);
        var saved = archive.getObjectEnd();
        List<UProperty> properties;
        try {
            archive.setPosition(export.getSerialOffset());
            archive.setObjectEnd(export.getSerialOffset() + export.getSerialSize());
            if ((export.getObjectFlags() & ObjectFlags.RF_HasStack.getId()) != 0) {
                StateFrame.deserialize(archive);
            }
            properties = archive.getPropertyExtractor().extractProperties();
        } catch (RuntimeException failure) {
            return null;
        } finally {
            archive.setObjectEnd(saved);
        }
        String effect = null;
        var attachOn = AM_NONE;
        var bone = "";
        var onTarget = true;
        var onMultiTarget = false;
        var relativeToCylinder = true;
        var offset = new Vec3();
        var scale = 0f;
        var delay = 0f;
        var absolute = false;
        var turn = Action.NO_TURN;
        for (var property : properties) {
            switch (property.getName()) {
                case "EffectClass" -> effect = path(archive, property.getIndexValue());
                case "AttachOn" -> attachOn = property.getUInt8Value() & 0xff;
                case "AttachBoneName" -> bone = archive.resolveName(property.getIndexValue());
                case "bSpawnOnTarget" -> onTarget = property.isTrue();
                case "bOnMultiTarget" -> onMultiTarget = property.isTrue();
                case "bRelativeToCylinder" -> relativeToCylinder = property.isTrue();
                case "offset" -> offset = property.getVectorValue() == null ? offset : property.getVectorValue();
                case "ScaleSize" -> scale = property.getFloatValue();
                case "SpawnDelay" -> delay = property.getFloatValue();
                case "bAbsolute" -> absolute = property.isTrue();
                case "RelativeRotation" ->
                    turn = property.getRotatorValue() == null ? turn : property.getRotatorValue();
                default -> {
                }
            }
        }
        return effect == null
                ? null
                : new Action(
                        effect,
                        attachOn,
                        bone,
                        onTarget,
                        onMultiTarget,
                        relativeToCylinder,
                        offset,
                        scale,
                        delay,
                        absolute,
                        turn);
    }

    private static @Nullable String path(UArchive archive, int index) {
        if (index < 0) {
            var imported = archive.getImportMap().get(-index - 1);
            var outer = imported.getPackageIndex();
            var name = imported.getObjectName();
            return outer < 0 ? archive.getImportMap().get(-outer - 1).getObjectName() + "." + name : name;
        }
        if (index > 0) {
            return archive.getName() + "."
                    + archive.getExportMap().get(index - 1).getObjectName();
        }
        return null;
    }
}
