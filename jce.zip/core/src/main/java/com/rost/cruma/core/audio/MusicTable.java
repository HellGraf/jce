package com.rost.cruma.core.audio;

import com.rost.cruma.core.npc.ClientCatalog;
import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.L2TextTable;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.eclipse.collections.api.map.primitive.IntObjectMap;
import org.eclipse.collections.impl.map.mutable.primitive.IntObjectHashMap;
import org.jetbrains.annotations.Nullable;

public final class MusicTable {
    private static final String TAIL = "SafePackage";

    private final IntObjectMap<List<String>> playlists;

    private MusicTable(IntObjectMap<List<String>> playlists) {
        this.playlists = playlists;
    }

    public static MusicTable load(Path clientPath) throws IOException {
        return load(clientPath, WorldVariant.MAIN);
    }

    public static MusicTable load(Path clientPath, WorldVariant variant) throws IOException {
        var system = clientPath.resolve("system");
        var file = variant.find(system, "musicinfo.dat");
        if (file == null) {
            var text = variant.find(system, "musicinfo.txt");
            if (text != null) {
                return parseText(L2TextTable.read(text));
            }
        }
        var names = variant.find(system, "L2GameDataName.dat");
        return parse(
                L2DataFile.read(file == null ? system.resolve("musicinfo.dat") : file),
                names == null ? List.of() : ClientCatalog.gameDataNames(L2DataFile.read(names)));
    }

    static MusicTable parse(byte[] payload, List<String> names) {
        var byNumber = names.isEmpty() ? null : parseNumbers(payload, names);
        return byNumber == null ? parse(payload) : byNumber;
    }

    static MusicTable parseText(List<Map<String, String>> records) {
        var playlists = new IntObjectHashMap<List<String>>(records.size());
        for (var record : records) {
            var id = L2TextTable.integer(record, "id", -1);
            if (id >= 0) {
                playlists.put(id, List.copyOf(L2TextTable.names(record.getOrDefault("title", ""))));
            }
        }
        return new MusicTable(playlists);
    }

    public static MusicTable parse(byte[] payload) {
        var buffer = ByteBuffer.wrap(payload).order(ByteOrder.LITTLE_ENDIAN);
        var count = buffer.getInt();
        if (count < 0) {
            throw new IllegalArgumentException("musicinfo.dat declares " + count + " rows");
        }
        var playlists = new IntObjectHashMap<List<String>>(count);
        for (var row = 0; row < count; row++) {
            var id = buffer.getInt();
            var trackCount = buffer.getInt();
            if (trackCount < 0) {
                throw new IllegalArgumentException("music " + id + " declares " + trackCount + " tracks");
            }
            var tracks = new ArrayList<String>(trackCount);
            for (var track = 0; track < trackCount; track++) {
                var bytes = buffer.getInt();
                if (bytes < 0 || bytes > buffer.remaining()) {
                    throw new IllegalArgumentException("music " + id + " track name of " + bytes + " bytes");
                }
                var name = new String(payload, buffer.position(), bytes, StandardCharsets.UTF_16LE);
                buffer.position(buffer.position() + bytes);
                var trimmed = name.trim();
                if (!trimmed.isEmpty()) {
                    tracks.add(trimmed);
                }
            }
            playlists.put(id, List.copyOf(tracks));
        }
        return new MusicTable(playlists);
    }

    public List<String> getPlaylist(int musicId) {
        var tracks = playlists.get(musicId);
        return tracks == null ? List.of() : tracks;
    }

    public int size() {
        return playlists.size();
    }

    private static @Nullable MusicTable parseNumbers(byte[] payload, List<String> names) {
        var buffer = ByteBuffer.wrap(payload).order(ByteOrder.LITTLE_ENDIAN);
        try {
            var count = buffer.getInt();
            if (count < 0 || count > payload.length) {
                return null;
            }
            var playlists = new IntObjectHashMap<List<String>>(count);
            for (var row = 0; row < count; row++) {
                var id = buffer.getInt();
                var trackCount = buffer.getInt();
                if (trackCount < 0 || trackCount > buffer.remaining()) {
                    return null;
                }
                var tracks = new ArrayList<String>(trackCount);
                for (var track = 0; track < trackCount; track++) {
                    var number = buffer.getInt();
                    if (number < -1 || number >= names.size()) {
                        return null;
                    }
                    if (number >= 0 && !names.get(number).isBlank()) {
                        tracks.add(names.get(number).trim());
                    }
                }
                playlists.put(id, List.copyOf(tracks));
            }
            return isEnded(buffer) ? new MusicTable(playlists) : null;
        } catch (BufferUnderflowException failure) {
            return null;
        }
    }

    private static boolean isEnded(ByteBuffer buffer) {
        if (!buffer.hasRemaining()) {
            return true;
        }
        var mark = new byte[buffer.remaining()];
        buffer.get(mark);
        return mark.length == TAIL.length() + 2
                && TAIL.equals(new String(mark, 1, TAIL.length(), StandardCharsets.US_ASCII));
    }
}
