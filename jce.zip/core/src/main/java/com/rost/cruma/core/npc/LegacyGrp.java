package com.rost.cruma.core.npc;

import java.util.List;

final class LegacyGrp {
    private static final String GRACIA_HEAD =
            "i i:id i i i i i U U U U U U U U U U U U i i i U:icon U U U U i i i i i Li i U";

    static final List<DatLayout> ETC_ITEMS = List.of(
            new DatLayout("i i:id i i i i i U U U U U U U:icon U U U U i i i i i LU LU U U i i i"),
            new DatLayout(GRACIA_HEAD + " LU LU U U i i i"),
            new DatLayout("i i:id i i i i i U U U U U U U:icon i i i i i LU LU U U i i i"));

    static final List<DatLayout> WEAPONS = List.of(
            new DatLayout("i i:id i i i i i U U U U U U U:icon U U U U i i i i i i i L=n U LU LU U U U s72 "
                    + "*n U *n s12 *n s8 *n U *n s24"),
            new DatLayout(GRACIA_HEAD + " i i L=n U *n i LU LU U U U s72 *n U *n s20 *n U *n s24 s32"));

    static final List<DatLayout> ARMORS = List.of(
            new DatLayout("i i:id i i i i i U U U U U U U:icon U U U U i i i i i i " + "LU LU LU LU ".repeat(15)
                    + "LU LU U LU U U s32"),
            new DatLayout(GRACIA_HEAD + " i " + "LU LU L(U b b) LU U ".repeat(17) + "U LU U U s36"));

    private LegacyGrp() {}
}
