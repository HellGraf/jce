package com.rost.cruma.core.spawn;

import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.L2TextTable;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class NpcGrpTable {
    private static final List<Layout> LAYOUTS = List.of(
            new Layout() {
                @Override
                public String name() {
                    return "High Five";
                }

                @Override
                public Appearance read(ByteBuffer data, List<String> names) {
                    var textures = new ArrayList<String>();
                    var head = legacyHead(data, textures);
                    skip(data, count(compact(data)) * 4);
                    skip(data, count(compact(data)) * 4);
                    readUnicode(data);
                    skip(data, 4 + 12 + 4 + 4);
                    var dialogs = count(data.getInt());
                    for (var i = 0; i < dialogs; i++) {
                        ascf(data);
                    }
                    data.getInt();
                    return new Appearance(head.id(), head.mesh(), textures, 1, head.npcClass());
                }
            },
            new Layout() {
                @Override
                public String name() {
                    return "Epilogue";
                }

                @Override
                public Appearance read(ByteBuffer data, List<String> names) {
                    var textures = new ArrayList<String>();
                    var head = legacyHead(data, textures);
                    skip(data, count(compact(data)) * 4);
                    readUnicode(data);
                    skip(data, 4 + 12 + 4 + 4);
                    var ends = count(data.getInt());
                    for (var i = 0; i < ends; i++) {
                        ascf(data);
                    }
                    return new Appearance(head.id(), head.mesh(), textures, 1, head.npcClass());
                }
            },
            new Layout() {
                @Override
                public String name() {
                    return "Interlude and Gracia";
                }

                @Override
                public Appearance read(ByteBuffer data, List<String> names) {
                    var textures = new ArrayList<String>();
                    var head = legacyHead(data, textures);
                    skip(data, count(compact(data)) * 4);
                    readUnicode(data);
                    skip(data, 4 + 12 + 4 + 4);
                    return new Appearance(head.id(), head.mesh(), textures, 1, head.npcClass());
                }
            },
            new Layout() {
                @Override
                public String name() {
                    return "Chronicle 5";
                }

                @Override
                public Appearance read(ByteBuffer data, List<String> names) {
                    var textures = new ArrayList<String>();
                    var head = legacyStart(data, textures);
                    skip(data, count(compact(data)) * 4);
                    readUnicode(data);
                    skip(data, 4 + 12 + 4 + 4);
                    return new Appearance(head.id(), head.mesh(), textures, 1, head.npcClass());
                }
            },
            new Layout() {
                @Override
                public String name() {
                    return "indexed (Grand Crusade and later)";
                }

                @Override
                public Appearance read(ByteBuffer data, List<String> names) {
                    var id = data.getShort() & 0xffff;
                    var npcClass = readMappedName(data, names);
                    var mesh = readMappedName(data, names);
                    var textures = new ArrayList<String>();
                    var textureCount = count(compact(data));
                    for (var i = 0; i < textureCount; i++) {
                        textures.add(readMappedName(data, names));
                    }
                    var second = count(data.getInt());
                    skip(data, second * 4);
                    skip(data, count(compact(data)) * 2);
                    data.getFloat();
                    for (var list = 0; list < 3; list++) {
                        skip(data, count(compact(data)) * 4);
                    }
                    skip(data, count(compact(data)) * 8);
                    skip(data, count(compact(data)) * 3);
                    skip(data, 4 + 3 + 2);
                    skip(data, count(data.getInt()) * 4);
                    skip(data, 4);
                    var drawScale = data.getFloat();
                    skip(data, 4 + 4 + 1);
                    var runSpeed = data.getShort() & 0xffff;
                    var walkSpeed = data.getShort() & 0xffff;
                    skip(data, 16);
                    var rightHand = data.getInt();
                    var leftHand = data.getInt();
                    skip(data, 4 + 16 + 2);
                    return new Appearance(
                            id,
                            mesh,
                            textures,
                            drawScale > 0 ? drawScale : 1,
                            npcClass,
                            rightHand,
                            leftHand,
                            walkSpeed,
                            runSpeed);
                }
            },
            new Layout() {
                @Override
                public String name() {
                    return "Chronicle 4";
                }

                @Override
                public Appearance read(ByteBuffer data, List<String> names) {
                    var textures = new ArrayList<String>();
                    var head = legacyStart(data, textures);
                    data.getInt();
                    skip(data, count(compact(data)) * 4);
                    skip(data, 4 + 4);
                    readUnicode(data);
                    skip(data, 4 + 12 + 4 + 4);
                    return new Appearance(head.id(), head.mesh(), textures, 1, head.npcClass());
                }
            });

    private final Map<Integer, Appearance> byId;
    private final String layout;

    private NpcGrpTable(Map<Integer, Appearance> byId, String layout) {
        this.byId = Map.copyOf(byId);
        this.layout = layout;
    }

    public record Appearance(
            int id,
            String mesh,
            List<String> textures,
            float drawScale,
            String npcClass,
            int rightHand,
            int leftHand,
            int walkSpeed,
            int runSpeed) {
        public Appearance {
            mesh = cleanReference(mesh);
            textures = textures.stream().map(NpcGrpTable::cleanReference).toList();
            npcClass = cleanReference(npcClass);
        }

        public Appearance(int id, String mesh, List<String> textures, float drawScale) {
            this(id, mesh, textures, drawScale, "");
        }

        public Appearance(int id, String mesh, List<String> textures, float drawScale, String npcClass) {
            this(id, mesh, textures, drawScale, npcClass, 0, 0);
        }

        public Appearance(
                int id,
                String mesh,
                List<String> textures,
                float drawScale,
                String npcClass,
                int rightHand,
                int leftHand) {
            this(id, mesh, textures, drawScale, npcClass, rightHand, leftHand, 0, 0);
        }

        public boolean clear() {
            if (mesh.isBlank() || mesh.equalsIgnoreCase("None")) {
                return true;
            }
            if (textures.isEmpty()) {
                return false;
            }
            for (var texture : textures) {
                if (!texture.toLowerCase(Locale.ROOT).contains("clear_npc")) {
                    return false;
                }
            }
            return true;
        }

        public Appearance withDrawScale(float scale) {
            return new Appearance(id, mesh, textures, scale, npcClass, rightHand, leftHand, walkSpeed, runSpeed);
        }

        public String meshPackage() {
            var dot = mesh.indexOf('.');
            return dot < 0 ? "" : mesh.substring(0, dot);
        }

        public String meshObject() {
            return mesh.substring(mesh.lastIndexOf('.') + 1);
        }
    }

    private interface Layout {
        String name();

        Appearance read(ByteBuffer data, List<String> names);
    }

    public static NpcGrpTable empty() {
        return new NpcGrpTable(Map.of(), "none");
    }

    public static NpcGrpTable read(Path system) throws IOException {
        return read(system, WorldVariant.MAIN);
    }

    public static NpcGrpTable read(Path system, WorldVariant variant) throws IOException {
        var file = variant.find(system, "npcgrp.dat");
        if (file == null) {
            var text = variant.find(system, "npcgrp.txt");
            if (text != null) {
                return parseText(L2TextTable.read(text));
            }
            throw new IOException("No npcgrp.dat in " + system);
        }
        var data = L2DataFile.read(file);
        var namesFile = find(system, "L2GameDataName.dat");
        List<String> names = List.of();
        if (namesFile != null) {
            names = gameDataNames(L2DataFile.read(namesFile));
        }
        return parse(data, names);
    }

    static String cleanReference(String value) {
        var trimmed = value.strip();
        if (trimmed.length() >= 2 && trimmed.startsWith("[") && trimmed.endsWith("]")) {
            trimmed = trimmed.substring(1, trimmed.length() - 1).strip();
        }
        return trimmed;
    }

    static NpcGrpTable parse(byte[] data, List<String> names) throws IOException {
        var failures = new ArrayList<String>();
        for (var layout : LAYOUTS) {
            if (layout.name().startsWith("indexed") && names.isEmpty()) {
                continue;
            }
            var buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            try {
                var count = buffer.getInt();
                if (count < 0 || count > 1_000_000) {
                    throw new IllegalStateException("record count " + count);
                }
                var appearances = new HashMap<Integer, Appearance>(count * 2);
                for (var i = 0; i < count; i++) {
                    var start = buffer.position();
                    try {
                        var appearance = layout.read(buffer, names);
                        appearances.putIfAbsent(appearance.id(), appearance);
                    } catch (RuntimeException failure) {
                        if (i >= 100 && i >= count * 9 / 10) {
                            return new NpcGrpTable(
                                    appearances, layout.name() + ", " + (count - i) + " damaged records");
                        }
                        throw new IllegalStateException(
                                "record " + i + " at " + start + ": " + failure.getMessage(), failure);
                    }
                }
                if (buffer.remaining() > 32) {
                    throw new IllegalStateException(buffer.remaining() + " bytes left after " + count + " records");
                }
                return new NpcGrpTable(appearances, layout.name());
            } catch (RuntimeException failure) {
                failures.add(layout.name() + ": " + failure.getMessage());
            }
        }
        throw new IOException("npcgrp.dat matches no known layout (" + String.join("; ", failures) + ")");
    }

    static NpcGrpTable parseText(List<Map<String, String>> records) throws IOException {
        var appearances = new HashMap<Integer, Appearance>(records.size() * 2);
        for (var record : records) {
            var id = L2TextTable.integer(record, "npc_id", -1);
            var mesh = record.get("mesh_name");
            if (id < 0 || mesh == null) {
                continue;
            }
            var textures = L2TextTable.names(record.getOrDefault("texture_name", ""));
            appearances.putIfAbsent(id, new Appearance(id, L2TextTable.name(mesh), textures, 1));
        }
        if (appearances.isEmpty()) {
            throw new IOException("npcgrp.txt has no NPC records");
        }
        return new NpcGrpTable(appearances, "text");
    }

    static List<String> gameDataNames(byte[] data) {
        var buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        var count = buffer.getInt();
        var names = new ArrayList<String>(Math.max(0, count));
        for (var i = 0; i < count && buffer.remaining() >= 4; i++) {
            var length = buffer.getInt(buffer.position());
            if (length < 0 || length > buffer.remaining() - 4 || (length & 1) != 0) {
                break;
            }
            names.add(readUnicode(buffer));
        }
        return names;
    }

    public Appearance getAppearance(int id) {
        return byId.get(id);
    }

    public int size() {
        return byId.size();
    }

    public Collection<Appearance> getAppearances() {
        return Collections.unmodifiableCollection(byId.values());
    }

    public boolean hasScales() {
        return layout.startsWith("indexed");
    }

    public float getScale(Appearance appearance, float classScale) {
        return hasScales() ? appearance.drawScale() : classScale;
    }

    public String getLayout() {
        return layout;
    }

    private static Path find(Path folder, String name) throws IOException {
        if (!Files.isDirectory(folder)) {
            return null;
        }
        try (var entries = Files.list(folder)) {
            return entries.filter(path -> path.getFileName().toString().equalsIgnoreCase(name))
                    .findFirst()
                    .orElse(null);
        }
    }

    private static String readUnicode(ByteBuffer data) {
        var bytes = data.getInt();
        if (bytes < 0 || bytes > 4096 || (bytes & 1) != 0) {
            throw new IllegalStateException("string of " + bytes + " bytes");
        }
        var value = new byte[bytes];
        data.get(value);
        var text = new String(value, StandardCharsets.UTF_16LE);
        return text.endsWith("\0") ? text.substring(0, text.length() - 1) : text;
    }

    private static String ascf(ByteBuffer data) {
        var length = compact(data);
        if (length == 0) {
            return "";
        }
        if (Math.abs(length) > 4096) {
            throw new IllegalStateException("string of " + length + " characters");
        }
        var bytes = new byte[length < 0 ? -length * 2 : length];
        data.get(bytes);
        var text = new String(bytes, length < 0 ? StandardCharsets.UTF_16LE : StandardCharsets.ISO_8859_1);
        return text.endsWith("\0") ? text.substring(0, text.length() - 1) : text;
    }

    private static int compact(ByteBuffer data) {
        var first = data.get() & 0xff;
        var value = first & 0x3f;
        if ((first & 0x40) != 0) {
            var shift = 6;
            int next;
            do {
                next = data.get() & 0xff;
                value |= (next & 0x7f) << shift;
                shift += 7;
            } while ((next & 0x80) != 0 && shift < 32);
        }
        return (first & 0x80) != 0 ? -value : value;
    }

    private static int count(int value) {
        if (value < 0 || value > 10_000) {
            throw new IllegalStateException("list of " + value);
        }
        return value;
    }

    private static String readMappedName(ByteBuffer data, List<String> names) {
        var index = data.getInt();
        if (index < 0 || index >= names.size()) {
            if (index == -1) {
                return "";
            }
            throw new IllegalStateException("name index " + index);
        }
        return names.get(index);
    }

    private static List<String> unicodeList(ByteBuffer data) {
        var count = count(data.getInt());
        var values = new ArrayList<String>(count);
        for (var i = 0; i < count; i++) {
            values.add(readUnicode(data));
        }
        return values;
    }

    private static void skip(ByteBuffer data, int bytes) {
        data.position(data.position() + bytes);
    }

    private static Appearance legacyStart(ByteBuffer data, List<String> textures) {
        var id = data.getInt();
        var npcClass = readUnicode(data);
        var mesh = readUnicode(data);
        textures.addAll(unicodeList(data));
        unicodeList(data);
        skip(data, count(compact(data)) * 4);
        data.getFloat();
        unicodeList(data);
        unicodeList(data);
        unicodeList(data);
        unicodeList(data);
        return new Appearance(id, mesh, List.of(), 1, npcClass);
    }

    private static Appearance legacyHead(ByteBuffer data, List<String> textures) {
        var head = legacyStart(data, textures);
        var decorations = count(data.getInt());
        for (var i = 0; i < decorations; i++) {
            readUnicode(data);
            data.getFloat();
        }
        return head;
    }
}
