package com.rost.cruma.core.world;

public record EmitterResetPolicy(
        boolean autoReset, boolean autoDestroy, float timeTillResetMin, float timeTillResetMax) {
    public static final EmitterResetPolicy NONE = new EmitterResetPolicy(false, false, 0f, 0f);
}
