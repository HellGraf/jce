package com.rost.cruma.core.world;

import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.UArchiveLoader;
import com.rost.cruma.core.unreal.UArchiveLoader.USearchConfig;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.apache.logging.log4j.LogManager;

public final class ClientFov {
    private static final String CONTROLLER = "[Engine.LineagePlayerController]";
    private static final String OLD_CONTROLLER = "[Engine.PlayerController]";
    private static final float SHIPPED = 60;
    private static final float SHIPPED_FROM_P152 = 50;
    private static final int ENGINE_FROM_P152 = 132;

    private ClientFov() {}

    public static float read(Path clientRoot) {
        var written = written(clientRoot.resolve("system").resolve("User.ini"));
        return written > 0 ? written : shipped(engineVersion(clientRoot));
    }

    static float shipped(int engineVersion) {
        return engineVersion >= ENGINE_FROM_P152 ? SHIPPED_FROM_P152 : SHIPPED;
    }

    static float of(String ini) {
        var section = "";
        var fallback = 0f;
        for (var line : ini.split("\\r?\\n")) {
            if (line.startsWith("[")) {
                section = line.strip();
            } else if (section.equals(CONTROLLER) && line.startsWith("FovAngle=")) {
                return number(line);
            } else if (section.equals(OLD_CONTROLLER) && line.startsWith("DefaultFOV=")) {
                fallback = number(line);
            }
        }
        return fallback;
    }

    private static int engineVersion(Path clientRoot) {
        var loader = new UArchiveLoader(clientRoot, List.of(new USearchConfig("System", "u")));
        try {
            var engine = loader.loadArchive("Engine");
            return engine == null ? 0 : engine.getHeader().getFileVersion();
        } catch (RuntimeException unreadable) {
            LogManager.getLogger(ClientFov.class).debug("No Engine.u to read: {}", unreadable.toString());
            return 0;
        } finally {
            loader.clearArchives();
        }
    }

    private static float written(Path file) {
        try {
            return of(text(file));
        } catch (IOException | RuntimeException unreadable) {
            LogManager.getLogger(ClientFov.class).debug("No field of view in User.ini: {}", unreadable.toString());
            return 0;
        }
    }

    private static String text(Path file) throws IOException {
        byte[] bytes;
        try {
            bytes = L2DataFile.read(file);
        } catch (IOException notEncrypted) {
            bytes = Files.readAllBytes(file);
        }
        var wide = bytes.length > 1 && (bytes[0] == (byte) 0xFF || bytes[1] == 0);
        return new String(bytes, wide ? StandardCharsets.UTF_16LE : StandardCharsets.ISO_8859_1);
    }

    private static float number(String line) {
        return Float.parseFloat(line.substring(line.indexOf('=') + 1).strip());
    }
}
