package com.rost.cruma.core.spawn;

import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class NpcGrpParts {
    private final Map<Integer, Parts> byId;

    private NpcGrpParts(Map<Integer, Parts> byId) {
        this.byId = Map.copyOf(byId);
    }

    public record Parts(
            int npcId,
            int chest,
            int legs,
            int gloves,
            int feet,
            int back,
            int hairAccessory,
            int hairStyle,
            int rightHand,
            int leftHand) {}

    static NpcGrpParts of(Map<Integer, Parts> parts) {
        return new NpcGrpParts(parts);
    }

    public static NpcGrpParts empty() {
        return new NpcGrpParts(Map.of());
    }

    public static NpcGrpParts read(Path system) throws IOException {
        return read(system, WorldVariant.MAIN);
    }

    public static NpcGrpParts read(Path system, WorldVariant variant) throws IOException {
        var file = variant.find(system, "AdditionalNpcGrpParts.dat");
        return file == null ? empty() : parse(L2DataFile.read(file));
    }

    static NpcGrpParts parse(byte[] bytes) throws IOException {
        var data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        var count = data.getInt();
        if (count < 0 || (long) count * 44 > data.remaining()) {
            throw new IOException("AdditionalNpcGrpParts.dat does not match the P152 layout");
        }
        var parts = new HashMap<Integer, Parts>(count * 2);
        for (var i = 0; i < count; i++) {
            var npcId = data.getInt();
            data.getInt();
            var part = new Parts(
                    npcId,
                    data.getInt(),
                    data.getInt(),
                    data.getInt(),
                    data.getInt(),
                    data.getInt(),
                    data.getInt(),
                    data.getInt(),
                    data.getInt(),
                    data.getInt());
            parts.putIfAbsent(npcId, part);
        }
        return new NpcGrpParts(parts);
    }

    public Parts getParts(int npcId) {
        return byId.get(npcId);
    }
}
