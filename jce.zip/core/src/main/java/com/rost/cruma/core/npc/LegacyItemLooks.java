package com.rost.cruma.core.npc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.Nullable;

public final class LegacyItemLooks {
    private static final List<String> FIGURES_C4 = List.of(
            "mfighter",
            "ffighter",
            "mdarkelf",
            "fdarkelf",
            "mdwarf",
            "fdwarf",
            "melf",
            "felf",
            "mmagic",
            "fmagic",
            "morc",
            "forc",
            "mshaman",
            "fshaman");

    private static final List<String> FIGURES_GRACIA = List.of(
            "mfighter",
            "ffighter",
            "mdarkelf",
            "fdarkelf",
            "mdwarf",
            "fdwarf",
            "melf",
            "felf",
            "mmagic",
            "fmagic",
            "morc",
            "forc",
            "mshaman",
            "fshaman",
            "mkamael",
            "fkamael",
            "npc");

    private static final String HEAD_C4 = "i i:id i i i i i U U U U U U U:icon U U U U ";

    private static final String HEAD_C3 = "i i:id i i i i i U U U U U U U:icon ";

    private static final String HEAD_GRACIA =
            "i i:id i i i i i U U U U U U U U U U U U i i i U:icon U U U U i i i i i Li i U ";

    private record ArmorLayout(DatLayout layout, List<String> figures, boolean old) {}

    private static final List<ArmorLayout> ARMORS = List.of(
            new ArmorLayout(
                    new DatLayout(HEAD_C4 + "i i i i i i:part " + c4Figures() + "LU LU LU LU LU LU U LU U U s32"),
                    FIGURES_C4,
                    true),
            new ArmorLayout(
                    new DatLayout(HEAD_GRACIA + "i:part " + graciaFigures() + "U LU U U s36"), FIGURES_GRACIA, false),
            new ArmorLayout(
                    new DatLayout(HEAD_C3 + "i i i i i i:part " + c3Figures() + "LU LU LU LU U LU U U s24"),
                    FIGURES_C4,
                    true));

    private static final List<DatLayout> WEAPONS = List.of(
            new DatLayout(
                    HEAD_C4 + "i i i i i i i:hand L=n U:mesh+ L(U:texture+) LU U U U s72 *n U *n s20 *n U *n s24"),
            new DatLayout(HEAD_C4
                    + "i i i i i i i:hand L=n U:mesh+ L(U:texture+) LU U U U s72 *n U *n s20 *n U *n s24 s16 U U U U"),
            new DatLayout(
                    HEAD_GRACIA + "i i:hand L=n U:mesh+ *n i L(U:texture+) LU U U U s72 *n U *n s20 *n U *n s24 s32"),
            new DatLayout(HEAD_GRACIA
                    + "i i:hand L=n U:mesh+ *n i L(U:texture+) LU U U U s72 *n U *n s20 *n U *n s24 s24 U U U U"),
            new DatLayout(
                    HEAD_C3 + "i i i i i i i:hand L=n U:mesh+ L(U:texture+) LU U U U s60 *n U *n s20 *n U *n s24"));

    private LegacyItemLooks() {}

    public record ArmorLook(int id, int bodyPart, String icon, Map<String, FigureLook> figures) {}

    public record FigureLook(
            List<String> meshes, List<String> textures, List<String> addMeshes, List<String> addTextures) {}

    public record WeaponLook(int id, int handness, String icon, List<String> meshes, List<String> textures) {}

    public static @Nullable List<ArmorLook> readArmors(byte[] table) {
        for (var layout : ARMORS) {
            try {
                var records = layout.layout().read(table, List.of());
                var result = new ArrayList<ArmorLook>(records.size());
                for (var record : records) {
                    var looks = new HashMap<String, FigureLook>();
                    for (var figure : layout.figures()) {
                        var look = new FigureLook(
                                readStrings(record, figure + "m"),
                                readStrings(record, figure + "t"),
                                readStrings(record, figure + "am"),
                                readStrings(record, figure + "at"));
                        if (!look.meshes().isEmpty() || !look.addMeshes().isEmpty()) {
                            looks.put(figure, look);
                        }
                    }
                    var part = (Integer) record.get("part");
                    result.add(new ArmorLook(
                            (Integer) record.get("id"),
                            layout.old() ? interludePart(part) : part,
                            (String) record.get("icon"),
                            Map.copyOf(looks)));
                }
                return List.copyOf(result);
            } catch (RuntimeException otherLayout) {
            }
        }
        return null;
    }

    public static @Nullable List<WeaponLook> readWeapons(byte[] table) {
        for (var layout : WEAPONS) {
            try {
                var records = layout.read(table, List.of());
                var result = new ArrayList<WeaponLook>(records.size());
                for (var record : records) {
                    result.add(new WeaponLook(
                            (Integer) record.get("id"),
                            (Integer) record.get("hand"),
                            (String) record.get("icon"),
                            readStrings(record, "mesh"),
                            readStrings(record, "texture")));
                }
                return List.copyOf(result);
            } catch (RuntimeException otherLayout) {
            }
        }
        return null;
    }

    private static int interludePart(int part) {
        return switch (part) {
            case 15 -> 8;
            case 16 -> 9;
            case 19 -> 10;
            default -> 1000 + part;
        };
    }

    private static String c4Figures() {
        var spec = new StringBuilder();
        for (var figure : FIGURES_C4) {
            spec.append("L(U:")
                    .append(figure)
                    .append("m+) L(U:")
                    .append(figure)
                    .append("t+) L(U:")
                    .append(figure)
                    .append("am+) L(U:")
                    .append(figure)
                    .append("at+) ");
        }
        return spec.toString();
    }

    private static String c3Figures() {
        var spec = new StringBuilder();
        for (var figure : FIGURES_C4) {
            spec.append("L(U:").append(figure).append("m+) L(U:").append(figure).append("t+) ");
        }
        return spec.toString();
    }

    private static String graciaFigures() {
        var spec = new StringBuilder();
        for (var figure : FIGURES_GRACIA) {
            spec.append("L(U:")
                    .append(figure)
                    .append("m+) L(U:")
                    .append(figure)
                    .append("t+) L(U:")
                    .append(figure)
                    .append("am+ b b) L(U:")
                    .append(figure)
                    .append("at+) U ");
        }
        return spec.toString();
    }

    @SuppressWarnings("unchecked")
    private static List<String> readStrings(Map<String, Object> record, String name) {
        var values = (List<Object>) record.get(name);
        if (values == null) {
            return List.of();
        }
        var result = new ArrayList<String>(values.size());
        for (var value : values) {
            result.add((String) value);
        }
        return List.copyOf(result);
    }
}
