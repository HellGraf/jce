package com.rost.cruma.core.spawn;

import com.rost.cruma.core.npc.LegacyItemLooks;
import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.L2TextTable;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ArmorGrpTable {
    static final List<String> FIGURES = List.of(
            "mfighter",
            "ffighter",
            "mdarkelf",
            "fdarkelf",
            "mdwarf",
            "fdwarf",
            "melf",
            "felf",
            "mmagic",
            "fmagic",
            "morc",
            "forc",
            "mshaman",
            "fshaman",
            "mkamael",
            "fkamael",
            "mertheia",
            "fertheia",
            "npc");

    public static final int ONE_PIECE = 8;

    public static final int ALL_DRESS = 9;
    public static final int HAIR_ALL = 10;

    public static final int HIDE_HAIR = 0x20;

    private static final int TEXT_PART = 1000;

    private final Map<Integer, Armor> byId;
    private final Map<Integer, String> icons;

    private ArmorGrpTable(Map<Integer, Armor> byId) {
        this(byId, Map.of());
    }

    private ArmorGrpTable(Map<Integer, Armor> byId, Map<Integer, String> icons) {
        this.byId = Map.copyOf(byId);
        this.icons = Map.copyOf(icons);
    }

    public record Look(
            List<String> meshes,
            List<String> textures,
            List<String> addMeshes,
            int[] addValues,
            List<String> addTextures,
            String addTexture) {
        public Look(List<String> meshes, List<String> textures) {
            this(meshes, textures, List.of(), new int[0], List.of(), "");
        }
    }

    public record Armor(int id, int bodyPart, Map<String, Look> looks, int hideMask) {
        public Look look(String figure) {
            var look = looks.get(figure.toLowerCase(Locale.ROOT));
            return look == null || look.meshes().isEmpty() ? null : look;
        }
    }

    static ArmorGrpTable of(Map<Integer, Armor> armors) {
        return new ArmorGrpTable(armors);
    }

    public static ArmorGrpTable empty() {
        return new ArmorGrpTable(Map.of());
    }

    public static ArmorGrpTable read(Path system) throws IOException {
        return read(system, WorldVariant.MAIN);
    }

    public static ArmorGrpTable read(Path system, WorldVariant variant) throws IOException {
        var file = variant.find(system, "Armorgrp.dat");
        if (file == null) {
            var text = variant.find(system, "armorgrp.txt");
            if (text != null) {
                return parseText(L2TextTable.read(text));
            }
            throw new IOException("No Armorgrp.dat in " + system);
        }
        var namesFile = find(system, "L2GameDataName.dat");
        if (namesFile != null) {
            return parse(L2DataFile.read(file), NpcGrpTable.gameDataNames(L2DataFile.read(namesFile)));
        }
        var legacy = LegacyItemLooks.readArmors(L2DataFile.read(file));
        if (legacy == null) {
            throw new IOException(file.getFileName() + " matches no known layout");
        }
        var armors = new HashMap<Integer, Armor>(legacy.size() * 2);
        var icons = new HashMap<Integer, String>(legacy.size() * 2);
        for (var piece : legacy) {
            var looks = new HashMap<String, Look>();
            piece.figures()
                    .forEach((figure, look) -> looks.put(
                            figure,
                            new Look(
                                    look.meshes(),
                                    look.textures(),
                                    look.addMeshes(),
                                    new int[look.addMeshes().size() * 2],
                                    look.addTextures(),
                                    "")));
            armors.putIfAbsent(piece.id(), new Armor(piece.id(), piece.bodyPart(), looks, 0));
            if (piece.icon() != null && !piece.icon().isBlank() && !piece.icon().equalsIgnoreCase("None")) {
                icons.putIfAbsent(piece.id(), piece.icon());
            }
        }
        return new ArmorGrpTable(armors, icons);
    }

    static ArmorGrpTable parseText(List<Map<String, String>> records) throws IOException {
        var armors = new HashMap<Integer, Armor>(records.size() * 2);
        var icons = new HashMap<Integer, String>(records.size() * 2);
        for (var record : records) {
            var id = L2TextTable.integer(record, "object_id", -1);
            if (id < 0) {
                continue;
            }
            var looks = new HashMap<String, Look>();
            for (var figure : FIGURES) {
                var meshes = L2TextTable.references(record.get(figure + "_mesh"));
                if (!meshes.isEmpty()) {
                    looks.put(figure, new Look(meshes, L2TextTable.references(record.get(figure + "_texture"))));
                }
            }
            var onePiece = record.getOrDefault("body_part", "").contains("CHEST");
            armors.putIfAbsent(id, new Armor(id, onePiece ? ONE_PIECE : TEXT_PART, looks, 0));
            var icon = L2TextTable.references(record.get("icon"));
            if (!icon.isEmpty()) {
                icons.putIfAbsent(id, icon.getFirst());
            }
        }
        if (armors.isEmpty()) {
            throw new IOException("armorgrp.txt has no item records");
        }
        return new ArmorGrpTable(armors, icons);
    }

    static ArmorGrpTable parse(byte[] bytes, List<String> names) throws IOException {
        var data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        var count = data.getInt();
        var armors = new HashMap<Integer, Armor>(count * 2);
        var icons = new HashMap<Integer, String>(count * 2);
        try {
            for (var record = 0; record < count; record++) {
                u8(data);
                var id = data.getInt();
                skip(data, 4);
                var drops = u8(data);
                for (var i = 0; i < drops; i++) {
                    data.getInt();
                    skip(data, u8(data) * 4);
                }
                var icon = name(data.getInt(), names);
                skip(data, 4 * 4);
                if (!icon.isEmpty() && !icon.equalsIgnoreCase("None")) {
                    icons.putIfAbsent(id, icon);
                }
                skip(data, 2 + 2 + 1 + 1);
                skip(data, u8(data) * 2);
                skip(data, 1 + 1 + 2 + 4 + 4 + 1);
                var bodyPart = u8(data);
                var looks = new HashMap<String, Look>();
                for (var figure : FIGURES) {
                    var meshes = readReferences(data, u8(data), names);
                    var textures = readReferences(data, u8(data), names);
                    var extra = u8(data);
                    var addMeshes = readReferences(data, extra, names);
                    var addValues = new int[extra * 2];
                    for (var i = 0; i < addValues.length; i++) {
                        addValues[i] = u8(data);
                    }
                    var addTextures = readReferences(data, u8(data), names);
                    var addTexture = readReferences(data, 1, names);
                    looks.put(
                            figure,
                            new Look(meshes, textures, addMeshes, addValues, addTextures, addTexture.getFirst()));
                }
                data.getInt();
                skip(data, u8(data) * 4);
                skip(data, 4 + 4 + 4 + 1 + 1 + 1 + 2);
                var hideMask = Short.toUnsignedInt(data.getShort());
                skip(data, 1 + 1 + 1);
                armors.putIfAbsent(id, new Armor(id, bodyPart, looks, hideMask));
            }
        } catch (RuntimeException failure) {
            throw new IOException("Armorgrp.dat does not match the P152 layout: " + failure.getMessage(), failure);
        }
        if (data.remaining() > 32) {
            throw new IOException("Armorgrp.dat does not match the P152 layout: " + data.remaining() + " bytes left");
        }
        return new ArmorGrpTable(armors, icons);
    }

    public String getIcon(int itemId) {
        return icons.get(itemId);
    }

    public Map<Integer, String> getIcons() {
        return icons;
    }

    public List<Armor> getAll() {
        return byId.values().stream().sorted(Comparator.comparingInt(Armor::id)).toList();
    }

    public Armor getArmor(int itemId) {
        return byId.get(itemId);
    }

    public int size() {
        return byId.size();
    }

    private static String name(int index, List<String> names) {
        return index >= 0 && index < names.size() ? NpcGrpTable.cleanReference(names.get(index)) : "";
    }

    private static List<String> readReferences(ByteBuffer data, int count, List<String> names) {
        var result = new ArrayList<String>(count);
        for (var i = 0; i < count; i++) {
            var index = data.getInt();
            result.add(index >= 0 && index < names.size() ? NpcGrpTable.cleanReference(names.get(index)) : "");
        }
        return List.copyOf(result);
    }

    private static int u8(ByteBuffer data) {
        return data.get() & 0xff;
    }

    private static void skip(ByteBuffer data, int bytes) {
        data.position(data.position() + bytes);
    }

    private static Path find(Path folder, String name) throws IOException {
        if (!Files.isDirectory(folder)) {
            return null;
        }
        try (var entries = Files.list(folder)) {
            return entries.filter(path -> path.getFileName().toString().equalsIgnoreCase(name))
                    .findFirst()
                    .orElse(null);
        }
    }
}
