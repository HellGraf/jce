package com.rost.cruma.core.npc;

import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.Nullable;

public final class EnterEvents {
    public static final int FROM_BELOW = 1;

    public static final int FROM_ABOVE = 2;

    public static final float RISE_SECONDS = 1.8f;

    private static final List<DatLayout> LAYOUTS = List.of(
            new DatLayout("i:npc A A:sound f:volume f:radius i:rise i U:effect U:anim"),
            new DatLayout("i:npc N:sound f:volume f:radius i:rise i N:effect N:anim"));
    private static final EnterEvents NONE = new EnterEvents(Map.of());

    private final Map<Integer, Entrance> entrances;

    private EnterEvents(Map<Integer, Entrance> entrances) {
        this.entrances = Map.copyOf(entrances);
    }

    public record Entrance(String sound, float volume, float radius, int rise, String effect, String animation) {}

    public static EnterEvents read(Path client, WorldVariant variant) {
        var system = client.resolve("system");
        if (variant.find(system, "EnterEventgrp.dat") == null) {
            return NONE;
        }
        List<String> names = List.of();
        var namesFile = variant.find(system, "L2GameDataName.dat");
        if (namesFile != null) {
            try {
                names = ClientCatalog.gameDataNames(L2DataFile.read(namesFile));
            } catch (IOException | RuntimeException failure) {
                names = List.of();
            }
        }
        var entrances = new HashMap<Integer, Entrance>();
        for (var record :
                ClientCatalog.readTable(system, variant, "EnterEventgrp.dat", LAYOUTS, names, new ArrayList<>())) {
            if (record.get("npc") instanceof Integer npc) {
                entrances.putIfAbsent(
                        npc,
                        new Entrance(
                                text(record.get("sound")),
                                record.get("volume") instanceof Float volume ? volume : 0f,
                                record.get("radius") instanceof Float radius ? radius : 0f,
                                record.get("rise") instanceof Integer rise ? rise : 0,
                                text(record.get("effect")),
                                text(record.get("anim"))));
            }
        }
        return new EnterEvents(entrances);
    }

    public @Nullable Entrance of(int npc) {
        return entrances.get(npc);
    }

    public int size() {
        return entrances.size();
    }

    private static String text(@Nullable Object value) {
        var text = value == null ? "" : String.valueOf(value).trim();
        return text.equalsIgnoreCase("None") ? "" : text;
    }
}
