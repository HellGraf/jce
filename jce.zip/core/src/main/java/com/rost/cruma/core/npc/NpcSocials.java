package com.rost.cruma.core.npc;

import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.UDecryptor;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.jetbrains.annotations.Nullable;

public final class NpcSocials {
    private static final int SOCIAL_KEY = 0x5C;
    private static final String DEATH = "death";
    private static final Map<Integer, String> KINDS = buildKinds();
    private static final int LATER_MAPS = 3;
    private static final int ENTRY_BYTES = 12;
    private static final Pattern SECTION = Pattern.compile("^\\[(.+)]");
    private static final Pattern NAME =
            Pattern.compile("^NpcSocialAnimName\\[(\\d+)]\\s*=\\s*(\\S+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern KIND =
            Pattern.compile("^(\\w+)AnimName\\[0]\\s*=\\s*(\\S+)", Pattern.CASE_INSENSITIVE);

    private final Path system;
    private final Map<String, Names> classes = new HashMap<>();
    private final Map<String, Boolean> readPackages = new HashMap<>();
    private final boolean fromTable;

    record Names(Map<Integer, String> socials, Map<String, String> kinds) {}

    private NpcSocials(Path system, Map<String, Names> table, boolean fromTable) {
        this.system = system;
        this.fromTable = fromTable;
        classes.putAll(table);
    }

    public static NpcSocials read(Path client, WorldVariant variant) {
        var system = client.resolve("system");
        var table = variant.find(system, "PawnAnimData.dat");
        var names = variant.find(system, "L2GameDataName.dat");
        if (table != null && names != null) {
            try {
                var read = parseTable(L2DataFile.read(table), ClientCatalog.gameDataNames(L2DataFile.read(names)));
                return new NpcSocials(system, read, true);
            } catch (IOException | RuntimeException unreadable) {
                return new NpcSocials(system, Map.of(), true);
            }
        }
        return new NpcSocials(system, Map.of(), false);
    }

    static Map<String, Names> parseText(String text) {
        var read = new HashMap<String, Names>();
        Names section = null;
        for (var raw : text.split("\r?\n")) {
            var line = raw.strip();
            var start = SECTION.matcher(line);
            if (start.find()) {
                section = read.computeIfAbsent(
                        start.group(1).toLowerCase(Locale.ROOT), _ -> new Names(new HashMap<>(), new HashMap<>()));
                continue;
            }
            if (section == null) {
                continue;
            }
            var name = NAME.matcher(line);
            var kind = KIND.matcher(line);
            if (name.find()) {
                section.socials().put(Integer.parseInt(name.group(1)), name.group(2));
            } else if (kind.find()) {
                section.kinds().put(kind.group(1).toLowerCase(Locale.ROOT), kind.group(2));
            }
        }
        return read;
    }

    static Map<String, Names> parseTable(byte[] payload, List<String> names) {
        var data = ByteBuffer.wrap(payload).order(ByteOrder.LITTLE_ENDIAN);
        var read = new HashMap<String, Names>();
        var count = data.getInt();
        for (var i = 0; i < count; i++) {
            var name = names.get(data.getInt());
            var socials = new HashMap<Integer, String>();
            var kinds = new HashMap<String, String>();
            var entries = data.getInt();
            for (var entry = 0; entry < entries; entry++) {
                var key = data.getInt();
                var index = data.getInt();
                var value = data.getInt();
                var kind = KINDS.get(key);
                if (key == SOCIAL_KEY) {
                    socials.put(index, names.get(value));
                } else if (kind != null && index == 0) {
                    kinds.put(kind, names.get(value));
                }
            }
            for (var map = 0; map < LATER_MAPS; map++) {
                var skip = compact(data) * ENTRY_BYTES;
                data.position(data.position() + skip);
            }
            read.put(name.toLowerCase(Locale.ROOT), new Names(socials, kinds));
        }
        return read;
    }

    public @Nullable String getSequence(String npcClass, int social) {
        var names = names(npcClass);
        return names == null ? null : names.socials().get(social - 1);
    }

    public @Nullable String getDeath(String npcClass) {
        return getKind(npcClass, DEATH);
    }

    public @Nullable String getKind(String npcClass, String kind) {
        var names = names(npcClass);
        return names == null ? null : names.kinds().get(kind.toLowerCase(Locale.ROOT));
    }

    public Map<String, String> getKinds(String npcClass) {
        var names = names(npcClass);
        return names == null ? Map.of() : Map.copyOf(names.kinds());
    }

    private @Nullable Names names(String npcClass) {
        var dot = npcClass.indexOf('.');
        if (!fromTable && dot > 0) {
            readPackage(npcClass.substring(0, dot).toLowerCase(Locale.ROOT));
        }
        return classes.get(npcClass.substring(dot + 1).toLowerCase(Locale.ROOT));
    }

    private void readPackage(String name) {
        if (readPackages.putIfAbsent(name, true) != null) {
            return;
        }
        var file = find(name + ".int");
        if (file != null) {
            try {
                var buffer = UDecryptor.decrypt(file);
                var bytes = new byte[buffer.remaining()];
                buffer.get(bytes);
                var unicode = bytes.length > 1 && (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE;
                classes.putAll(parseText(
                        new String(bytes, unicode ? StandardCharsets.UTF_16LE : StandardCharsets.ISO_8859_1)));
            } catch (RuntimeException unreadable) {
            }
        }
    }

    private @Nullable Path find(String lowerName) {
        try (var files = Files.list(system)) {
            return files.filter(file -> file.getFileName().toString().equalsIgnoreCase(lowerName))
                    .findFirst()
                    .orElse(null);
        } catch (IOException unreadable) {
            return null;
        }
    }

    private static Map<Integer, String> buildKinds() {
        var kinds = new HashMap<Integer, String>();
        kinds.put(0x08, "wait");
        kinds.put(0x09, "atkwait");
        kinds.put(0x14, "atk01");
        kinds.put(0x15, "atk02");
        kinds.put(0x16, "atk03");
        for (var i = 1; i <= 28; i++) {
            kinds.put(0x1B + i, String.format(Locale.ROOT, "spatk%02d", i));
        }
        kinds.put(0x38, "shieldatk");
        kinds.put(0x3C, DEATH);
        kinds.put(0x3E, "deathwait");
        kinds.put(0x42, "castshort");
        kinds.put(0x43, "castmid");
        kinds.put(0x44, "castlong");
        kinds.put(0x45, "castend");
        kinds.put(0x46, "magicthrow");
        kinds.put(0x47, "magicshot");
        kinds.put(0x48, "magicnotarget");
        kinds.put(0x49, "magicfriend");
        kinds.put(0x4A, "picitem");
        kinds.put(0x57, "castshort2");
        kinds.put(0x58, "castmid2");
        kinds.put(0x59, "castlong2");
        kinds.put(0x5A, "castend2");
        kinds.put(0x67, "specialsocial1");
        kinds.put(0x68, "specialsocial2");
        kinds.put(0x69, "specialsocial3");
        return Map.copyOf(kinds);
    }

    private static int compact(ByteBuffer data) {
        var first = data.get() & 0xFF;
        var value = first & 0x3F;
        if ((first & 0x40) != 0) {
            var shift = 6;
            int next;
            do {
                next = data.get() & 0xFF;
                value |= (next & 0x7F) << shift;
                shift += 7;
            } while ((next & 0x80) != 0);
        }
        return value;
    }
}
