package com.rost.cruma.core.editing;

import com.rost.cruma.core.editing.ActorTransform.Vector3;
import com.rost.cruma.core.editing.PackageBytes.Cursor;
import com.rost.cruma.core.unreal.UArchive;
import com.rost.cruma.core.unreal.UArchiveLoader;
import com.rost.cruma.core.unreal.ULevel;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.jetbrains.annotations.Nullable;

final class BspSurfaceEdit {
    private static final int WATER = 0x00080000;
    private static final int FAKE_BACKDROP = 0x00000080;
    private static final int VERTEX_U = 12;
    private static final int VERTEX_V = 16;
    private static final float SAVED_UV_TOLERANCE = 1e-3f;

    final int modelExport;

    private final PackageBytes source;
    private final int flags;
    private final int serialOffset;
    private final byte[] payload;
    private final Layout layout;
    private final float[] vectors;
    private final float[] points;
    private final Surface[] surfaces;
    private final Node[] nodes;
    private final int[] verts;
    private final int[][] surfaceNodes;
    private final float[][] mappingSizes;
    private final boolean[] shared;

    private record Surface(
            int start,
            int indicesStart,
            int restStart,
            int end,
            int material,
            int polyFlags,
            int base,
            int normal,
            int u,
            int v) {}

    private record Node(
            float px, float py, float pz, float pw, int pool, int surface, int count, int section, int first) {}

    private record Layout(
            int vectors,
            int vectorData,
            int points,
            int pointData,
            int nodes,
            int surfaces,
            int[] surfaceStarts,
            int verts,
            int[] sectionStarts,
            int[] sectionCounts) {}

    private BspSurfaceEdit(
            int modelExport,
            PackageBytes source,
            int flags,
            int serialOffset,
            byte[] payload,
            Layout layout,
            float[] vectors,
            float[] points,
            Surface[] surfaces,
            Node[] nodes,
            int[] verts) {
        this.modelExport = modelExport;
        this.source = source;
        this.flags = flags;
        this.serialOffset = serialOffset;
        this.payload = payload;
        this.layout = layout;
        this.vectors = vectors;
        this.points = points;
        this.surfaces = surfaces;
        this.nodes = nodes;
        this.verts = verts;
        var lists = new ArrayList<List<Integer>>();
        for (var i = 0; i < surfaces.length; i++) {
            lists.add(new ArrayList<>());
        }
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].count >= 3 && nodes[i].surface >= 0 && nodes[i].surface < surfaces.length) {
                lists.get(nodes[i].surface).add(i);
            }
        }
        surfaceNodes = new int[surfaces.length][];
        mappingSizes = new float[surfaces.length][];
        for (var i = 0; i < surfaces.length; i++) {
            surfaceNodes[i] = lists.get(i).stream().mapToInt(Integer::intValue).toArray();
            mappingSizes[i] = savedMappingSizes(i);
        }
        shared = new boolean[surfaces.length];
        var owners = new HashMap<Long, Integer>();
        for (var i = 0; i < nodes.length; i++) {
            var node = nodes[i];
            if (node.count < 3
                    || node.surface < 0
                    || node.surface >= surfaces.length
                    || !hasSavedVertices(node, layout)) {
                continue;
            }
            for (var k = 0; k < node.count; k++) {
                var other = owners.putIfAbsent((long) node.section << 32 | node.first + k, i);
                if (other != null) {
                    shared[node.surface] = true;
                    shared[nodes[other].surface] = true;
                }
            }
        }
    }

    static BspSurfaceEdit open(Path map, PackageBytes source) throws IOException {
        var directory = map.toAbsolutePath().getParent();
        int modelExport;
        try (var archive = new UArchive(
                source.packageName,
                ByteBuffer.wrap(source.body.clone()).order(ByteOrder.LITTLE_ENDIAN),
                new UArchiveLoader(directory, List.of()))) {
            var levels = new ArrayList<ULevel>();
            archive.loadObjects("Level", levels);
            if (levels.isEmpty() || levels.getFirst().getModel().isNull()) {
                throw new IOException("The map has no level model");
            }
            modelExport = levels.getFirst().getModel().getIndex();
        } catch (RuntimeException unreadable) {
            throw new IOException(
                    unreadable.getMessage() == null ? unreadable.toString() : unreadable.getMessage(), unreadable);
        }
        return open(source, modelExport);
    }

    static BspSurfaceEdit open(PackageBytes source, int modelExport) throws IOException {
        if (modelExport <= 0 || modelExport > source.exports.size()) {
            throw new IOException("The level model is not an export of this map");
        }
        if (source.fileVersion < 123 || source.fileVersion > 133) {
            throw new IOException("BSP surfaces of package version " + source.fileVersion + " cannot be written");
        }
        var entry = source.exports.get(modelExport - 1);
        var payload = Arrays.copyOfRange(source.body, entry.serialOffset(), entry.serialOffset() + entry.serialSize());
        BspLightmapTail.read(source, payload, entry.serialOffset(), entry.flags());
        var layout = layout(source, payload, entry.flags());
        var c = new Cursor(payload, layout.vectors, payload.length);
        var vectors = floats(c, 3 * c.readIndex());
        var points = floats(c, 3 * c.readIndex());
        var nodes = new Node[c.readIndex()];
        for (var i = 0; i < nodes.length; i++) {
            var px = f32(c);
            var py = f32(c);
            var pz = f32(c);
            var pw = f32(c);
            c.skip(8 + 1);
            var pool = c.readIndex();
            var surface = c.readIndex();
            for (var k = 0; k < 5; k++) {
                c.readIndex();
            }
            c.skip(32);
            c.readIndex();
            c.readIndex();
            var count = c.readU8();
            c.skip(8);
            var section = c.readI32();
            var first = c.readI32();
            c.skip(4);
            nodes[i] = new Node(px, py, pz, pw, pool, surface, count, section, first);
        }
        var surfaces = new Surface[c.readIndex()];
        for (var i = 0; i < surfaces.length; i++) {
            var start = c.position;
            var material = c.readIndex();
            var polyFlags = c.readI32();
            var indicesStart = c.position;
            var base = c.readIndex();
            var normal = c.readIndex();
            var u = c.readIndex();
            var v = c.readIndex();
            var restStart = c.position;
            c.readIndex();
            c.readIndex();
            c.skip(16 + 4);
            if (source.licenseVersion > 20) {
                c.skip(4);
            }
            surfaces[i] =
                    new Surface(start, indicesStart, restStart, c.position, material, polyFlags, base, normal, u, v);
        }
        if (c.position != layout.verts) {
            throw new IOException("The BSP surfaces do not read the same twice");
        }
        var verts = new int[c.readIndex()];
        for (var i = 0; i < verts.length; i++) {
            verts[i] = c.readIndex();
            c.readIndex();
        }
        for (var surface : surfaces) {
            if (!isValidIndex(surface.base, points)
                    || !isValidIndex(surface.normal, vectors)
                    || !isValidIndex(surface.u, vectors)
                    || !isValidIndex(surface.v, vectors)) {
                throw new IOException("A BSP surface refers to a missing point or vector");
            }
        }
        for (var node : nodes) {
            if (node.count > 0 && (node.pool < 0 || node.pool + node.count > verts.length)) {
                throw new IOException("A BSP node refers to missing vertices");
            }
            for (var k = 0; k < node.count; k++) {
                if (!isValidIndex(verts[node.pool + k], points)) {
                    throw new IOException("A BSP vertex refers to a missing point");
                }
            }
        }
        return new BspSurfaceEdit(
                modelExport,
                source,
                entry.flags(),
                entry.serialOffset(),
                payload,
                layout,
                vectors,
                points,
                surfaces,
                nodes,
                verts);
    }

    int getSurfaceCount() {
        return surfaces.length;
    }

    BspSurfaceMapping getMapping(int surface) {
        var s = surfaces[surface];
        return new BspSurfaceMapping(point(s.base), vector(s.u), vector(s.v));
    }

    Vector3 getNormal(int surface) {
        return vector(surfaces[surface].normal);
    }

    int getMaterial(int surface) {
        return surfaces[surface].material;
    }

    float @Nullable [] getMappingSizes(int surface) {
        var sizes = mappingSizes[surface];
        return sizes == null || sizes[0] == 1 && sizes[1] == 1 ? null : sizes.clone();
    }

    String getRestriction(int surface) {
        if (surface < 0 || surface >= surfaces.length) {
            return "Unknown BSP surface " + surface;
        }
        if (surfaceNodes[surface].length == 0) {
            return "This surface has no polygons";
        }
        var polyFlags = surfaces[surface].polyFlags;
        if ((polyFlags & WATER) != 0) {
            return "Water is drawn by its own rules, so its texture stays as saved";
        }
        if ((polyFlags & FAKE_BACKDROP) != 0) {
            return "This surface shows the sky, not a texture";
        }
        if (mappingSizes[surface] == null) {
            return "The saved render data of this surface does not match its mapping";
        }
        if (shared[surface]) {
            return "This surface shares its saved render data with another polygon";
        }
        return "";
    }

    List<float[]> getPolygons(int surface) {
        var result = new ArrayList<float[]>();
        for (var index : surfaceNodes[surface]) {
            var node = nodes[index];
            var polygon = new float[node.count * 3];
            for (var k = 0; k < node.count; k++) {
                var p = verts[node.pool + k] * 3;
                polygon[k * 3] = points[p];
                polygon[k * 3 + 1] = points[p + 1];
                polygon[k * 3 + 2] = points[p + 2];
            }
            result.add(polygon);
        }
        return result;
    }

    int pick(Vector3 point, float tolerance) {
        var best = -1;
        var bestDistance = Float.POSITIVE_INFINITY;
        for (var node : nodes) {
            if (node.count < 3 || node.surface < 0 || node.surface >= surfaces.length) {
                continue;
            }
            var distance = Math.abs(node.px * point.x() + node.py * point.y() + node.pz * point.z() - node.pw);
            if (distance > tolerance || distance >= bestDistance || !isInside(node, point, tolerance)) {
                continue;
            }
            best = node.surface;
            bestDistance = distance;
        }
        return best;
    }

    byte[] apply(byte[] input, int inputOffset, int targetOffset, Map<Integer, BspSurfaceMapping> edits)
            throws IOException {
        if (!Arrays.equals(input, 0, layout.verts, payload, 0, layout.verts)) {
            throw new IOException("The level model changed before its BSP surfaces");
        }
        var sorted = new TreeMap<>(edits);
        for (var edit : sorted.entrySet()) {
            var restriction = getRestriction(edit.getKey());
            if (restriction.isEmpty()) {
                restriction = edit.getValue().restriction();
            }
            if (!restriction.isEmpty()) {
                throw new IOException(restriction);
            }
        }
        var inputLayout = layout(source, input, flags);
        var out = new ByteArrayOutputStream(input.length + sorted.size() * 40 + 16);
        out.write(head(sorted));
        out.write(input, layout.verts, input.length - layout.verts);
        var result = out.toByteArray();
        var shift = result.length - input.length;
        var buffer = PackageBytes.littleEndian(result);
        for (var edit : sorted.entrySet()) {
            var surface = edit.getKey();
            for (var index : surfaceNodes[surface]) {
                var node = nodes[index];
                if (!hasSavedVertices(node, inputLayout)) {
                    continue;
                }
                var uv = coordinates(node, edit.getValue(), mappingSizes[surface]);
                var start = inputLayout.sectionStarts[node.section] + shift + node.first * vertexBytes();
                for (var k = 0; k < node.count; k++) {
                    buffer.putFloat(start + k * vertexBytes() + VERTEX_U, uv[k * 2]);
                    buffer.putFloat(start + k * vertexBytes() + VERTEX_V, uv[k * 2 + 1]);
                }
            }
        }
        var tail = BspLightmapTail.read(source, input, inputOffset, flags);
        for (var texture : tail.textures) {
            for (var variant : texture.variants()) {
                buffer.putInt(
                        variant.fullLazyAt() + shift, variant.fullEndPosition() - inputOffset + targetOffset + shift);
                buffer.putInt(
                        variant.halfLazyAt() + shift, variant.halfEndPosition() - inputOffset + targetOffset + shift);
            }
        }
        return result;
    }

    boolean carries(byte[] written, int offset, Map<Integer, BspSurfaceMapping> edits) throws IOException {
        var head = head(new TreeMap<>(edits));
        if (written.length < head.length || !Arrays.equals(written, 0, head.length, head, 0, head.length)) {
            return false;
        }
        var writtenLayout = layout(source, written, flags);
        var buffer = PackageBytes.littleEndian(written);
        for (var edit : edits.entrySet()) {
            for (var index : surfaceNodes[edit.getKey()]) {
                var node = nodes[index];
                if (!hasSavedVertices(node, writtenLayout)) {
                    continue;
                }
                var uv = coordinates(node, edit.getValue(), mappingSizes[edit.getKey()]);
                var start = writtenLayout.sectionStarts[node.section] + node.first * vertexBytes();
                for (var k = 0; k < node.count; k++) {
                    if (Float.floatToRawIntBits(buffer.getFloat(start + k * vertexBytes() + VERTEX_U))
                                    != Float.floatToRawIntBits(uv[k * 2])
                            || Float.floatToRawIntBits(buffer.getFloat(start + k * vertexBytes() + VERTEX_V))
                                    != Float.floatToRawIntBits(uv[k * 2 + 1])) {
                        return false;
                    }
                }
            }
        }
        BspLightmapTail.read(source, written, offset, flags);
        return true;
    }

    private boolean isInside(Node node, Vector3 point, float tolerance) {
        var ax = Math.abs(node.px);
        var ay = Math.abs(node.py);
        var az = Math.abs(node.pz);
        var drop = ax >= ay && ax >= az ? 0 : ay >= az ? 1 : 2;
        var a = drop == 0 ? 1 : 0;
        var b = drop == 2 ? 1 : 2;
        var target = new float[] {point.x(), point.y(), point.z()};
        var tx = target[a];
        var ty = target[b];
        var crossings = false;
        var nearEdge = false;
        for (var k = 0; k < node.count; k++) {
            var p = verts[node.pool + k] * 3;
            var q = verts[node.pool + (k + 1) % node.count] * 3;
            var x0 = points[p + a];
            var y0 = points[p + b];
            var x1 = points[q + a];
            var y1 = points[q + b];
            if ((y0 > ty) != (y1 > ty) && tx < x0 + (ty - y0) / (y1 - y0) * (x1 - x0)) {
                crossings = !crossings;
            }
            nearEdge |= segmentDistance(tx, ty, x0, y0, x1, y1) <= tolerance;
        }
        return crossings || nearEdge;
    }

    private byte[] head(TreeMap<Integer, BspSurfaceMapping> sorted) {
        var out = new ByteArrayOutputStream(layout.verts + sorted.size() * 40 + 16);
        out.write(payload, 0, layout.vectors);
        PackageBytes.writeIndex(out, vectors.length / 3 + sorted.size() * 2);
        out.write(payload, layout.vectorData, vectors.length * 4);
        for (var mapping : sorted.values()) {
            writeVector(out, mapping.u());
            writeVector(out, mapping.v());
        }
        PackageBytes.writeIndex(out, points.length / 3 + sorted.size());
        out.write(payload, layout.pointData, points.length * 4);
        for (var mapping : sorted.values()) {
            writeVector(out, mapping.base());
        }
        out.write(payload, layout.nodes, layout.surfaces - layout.nodes);
        out.write(payload, layout.surfaces, layout.surfaceStarts[0] - layout.surfaces);
        var vector = vectors.length / 3;
        var point = points.length / 3;
        for (var i = 0; i < surfaces.length; i++) {
            var s = surfaces[i];
            if (!sorted.containsKey(i)) {
                out.write(payload, s.start, s.end - s.start);
                continue;
            }
            out.write(payload, s.start, s.indicesStart - s.start);
            PackageBytes.writeIndex(out, point++);
            PackageBytes.writeIndex(out, s.normal);
            PackageBytes.writeIndex(out, vector++);
            PackageBytes.writeIndex(out, vector++);
            out.write(payload, s.restStart, s.end - s.restStart);
        }
        return out.toByteArray();
    }

    private boolean hasSavedVertices(Node node, Layout layout) {
        return node.section >= 0
                && node.section < layout.sectionStarts.length
                && node.first >= 0
                && node.first + node.count <= layout.sectionCounts[node.section];
    }

    private float[] coordinates(Node node, BspSurfaceMapping mapping, float[] sizes) {
        var u = mapping.u();
        var v = mapping.v();
        var base = mapping.base();
        var uTranslation = u.y() * -base.y() + u.x() * -base.x() + u.z() * -base.z();
        var vTranslation = v.y() * -base.y() + v.x() * -base.x() + v.z() * -base.z();
        var result = new float[node.count * 2];
        var totalU = 0f;
        var totalV = 0f;
        for (var k = 0; k < node.count; k++) {
            var p = verts[node.pool + k] * 3;
            var x = points[p];
            var y = points[p + 1];
            var z = points[p + 2];
            result[k * 2] = (u.y() * y + u.x() * x + u.z() * z + uTranslation) / sizes[0];
            result[k * 2 + 1] = (v.y() * y + v.x() * x + v.z() * z + vTranslation) / sizes[1];
            totalU += result[k * 2];
            totalV += result[k * 2 + 1];
        }
        var centerU = (float) (int) Math.floor((double) (totalU / node.count) + 0.5);
        var centerV = (float) (int) Math.floor((double) (totalV / node.count) + 0.5);
        for (var k = 0; k < node.count; k++) {
            result[k * 2] -= centerU;
            result[k * 2 + 1] -= centerV;
        }
        return result;
    }

    private float[] savedMappingSizes(int surface) {
        var mapping = getMapping(surface);
        var sizes = new float[2];
        var buffer = PackageBytes.littleEndian(payload);
        var found = false;
        for (var axis = 0; axis < 2; axis++) {
            var direction = axis == 0 ? mapping.u() : mapping.v();
            var bestSpan = 0f;
            for (var index : surfaceNodes[surface]) {
                var node = nodes[index];
                if (!hasSavedVertices(node, layout)) {
                    continue;
                }
                found = true;
                var start = layout.sectionStarts[node.section] + node.first * vertexBytes();
                for (var k = 1; k < node.count; k++) {
                    var saved = buffer.getFloat(start + k * vertexBytes() + (axis == 0 ? VERTEX_U : VERTEX_V))
                            - buffer.getFloat(start + (axis == 0 ? VERTEX_U : VERTEX_V));
                    if (Math.abs(saved) <= bestSpan) {
                        continue;
                    }
                    var p = verts[node.pool + k] * 3;
                    var q = verts[node.pool] * 3;
                    var world = direction.x() * (points[p] - points[q])
                            + direction.y() * (points[p + 1] - points[q + 1])
                            + direction.z() * (points[p + 2] - points[q + 2]);
                    bestSpan = Math.abs(saved);
                    sizes[axis] = Math.round(world / saved);
                }
            }
            if (found && bestSpan > 0 && !(sizes[axis] >= 1)) {
                return null;
            }
            if (bestSpan == 0) {
                sizes[axis] = 1;
            }
        }
        if (!found) {
            return new float[] {1, 1};
        }
        for (var index : surfaceNodes[surface]) {
            var node = nodes[index];
            if (!hasSavedVertices(node, layout)) {
                continue;
            }
            var start = layout.sectionStarts[node.section] + node.first * vertexBytes();
            var uv = coordinates(node, mapping, sizes);
            for (var k = 0; k < node.count; k++) {
                var p = verts[node.pool + k] * 3;
                var at = start + k * vertexBytes();
                if (buffer.getFloat(at) != points[p]
                        || buffer.getFloat(at + 4) != points[p + 1]
                        || buffer.getFloat(at + 8) != points[p + 2]) {
                    return null;
                }
                if (Math.abs(buffer.getFloat(at + VERTEX_U) - uv[k * 2]) > SAVED_UV_TOLERANCE
                        || Math.abs(buffer.getFloat(at + VERTEX_V) - uv[k * 2 + 1]) > SAVED_UV_TOLERANCE) {
                    return null;
                }
            }
        }
        return sizes;
    }

    private int vertexBytes() {
        return source.fileVersion > 0x6c ? 40 : 28;
    }

    private Vector3 point(int index) {
        return new Vector3(points[index * 3], points[index * 3 + 1], points[index * 3 + 2]);
    }

    private Vector3 vector(int index) {
        return new Vector3(vectors[index * 3], vectors[index * 3 + 1], vectors[index * 3 + 2]);
    }

    private static float segmentDistance(float px, float py, float x0, float y0, float x1, float y1) {
        var dx = x1 - x0;
        var dy = y1 - y0;
        var lengthSquared = dx * dx + dy * dy;
        var t = lengthSquared == 0 ? 0 : Math.clamp(((px - x0) * dx + (py - y0) * dy) / lengthSquared, 0f, 1f);
        var ex = x0 + t * dx - px;
        var ey = y0 + t * dy - py;
        return (float) Math.sqrt(ex * ex + ey * ey);
    }

    private static Layout layout(PackageBytes source, byte[] payload, int flags) throws IOException {
        var c = new Cursor(payload, 0, payload.length);
        NativeLevelEditor.skipProperties(source, c, flags);
        c.skip(25 + 16);
        var vectors = c.position;
        var vectorCount = count(c, 12);
        var vectorData = c.position;
        c.skip(vectorCount * 12);
        var points = c.position;
        var pointCount = count(c, 12);
        var pointData = c.position;
        c.skip(pointCount * 12);
        var nodes = c.position;
        for (var n = count(c, 60); n > 0; n--) {
            c.skip(16 + 8 + 1);
            for (var i = 0; i < 7; i++) {
                c.readIndex();
            }
            c.skip(32);
            c.readIndex();
            c.readIndex();
            c.skip(1 + 8 + 12);
        }
        var surfacesStart = c.position;
        var surfaceCount = count(c, 20);
        var surfaceStarts = new int[surfaceCount + 1];
        for (var n = 0; n < surfaceCount; n++) {
            surfaceStarts[n] = c.position;
            c.readIndex();
            c.skip(4);
            for (var i = 0; i < 6; i++) {
                c.readIndex();
            }
            c.skip(16 + 4);
            if (source.licenseVersion > 20) {
                c.skip(4);
            }
        }
        var verts = c.position;
        surfaceStarts[surfaceCount] = verts;
        for (var n = count(c, 2); n > 0; n--) {
            c.readIndex();
            c.readIndex();
        }
        c.skip(4);
        var zones = c.readI32();
        if (zones < 0 || zones > 64) {
            throw new IOException("Invalid BSP zone count " + zones);
        }
        for (var i = 0; i < zones; i++) {
            c.readIndex();
            c.skip(20);
        }
        c.readIndex();
        c.skip(count(c, 25) * 25);
        c.skip(count(c, 4) * 4);
        for (var n = count(c, 11); n > 0; n--) {
            c.readIndex();
            c.readIndex();
            c.readIndex();
            c.skip(8);
        }
        for (var n = count(c, 1); n > 0; n--) {
            c.readIndex();
        }
        c.skip(8);
        var vertexBytes = source.fileVersion > 0x6c ? 40 : 28;
        var sectionCount = count(c, 18);
        var sectionStarts = new int[sectionCount];
        var sectionCounts = new int[sectionCount];
        for (var n = 0; n < sectionCount; n++) {
            sectionCounts[n] = count(c, vertexBytes);
            sectionStarts[n] = c.position;
            c.skip(sectionCounts[n] * vertexBytes);
            c.skip(4);
            c.readIndex();
            c.skip(12);
        }
        return new Layout(
                vectors,
                vectorData,
                points,
                pointData,
                nodes,
                surfacesStart,
                surfaceStarts,
                verts,
                sectionStarts,
                sectionCounts);
    }

    private static int count(Cursor c, int minimumBytes) throws IOException {
        var count = c.readIndex();
        if (count < 0 || (long) count * minimumBytes > c.end - c.position) {
            throw new IOException("Invalid BSP array count " + count);
        }
        return count;
    }

    private static float[] floats(Cursor c, int count) throws IOException {
        if (count < 0 || (long) count * 4 > c.end - c.position) {
            throw new IOException("Invalid BSP array count " + count / 3);
        }
        var result = new float[count];
        for (var i = 0; i < count; i++) {
            result[i] = f32(c);
        }
        return result;
    }

    private static float f32(Cursor c) throws IOException {
        return Float.intBitsToFloat(c.readI32());
    }

    private static boolean isValidIndex(int value, float[] triples) {
        return value >= 0 && value < triples.length / 3;
    }

    private static void writeVector(ByteArrayOutputStream out, Vector3 value) {
        PackageBytes.writeInt(out, Float.floatToRawIntBits(value.x()));
        PackageBytes.writeInt(out, Float.floatToRawIntBits(value.y()));
        PackageBytes.writeInt(out, Float.floatToRawIntBits(value.z()));
    }
}
