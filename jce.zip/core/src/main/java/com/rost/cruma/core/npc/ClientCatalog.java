package com.rost.cruma.core.npc;

import com.rost.cruma.core.spawn.ArmorGrpTable;
import com.rost.cruma.core.spawn.WeaponGrpTable;
import com.rost.cruma.core.unreal.L2DataFile;
import com.rost.cruma.core.unreal.L2TextTable;
import com.rost.cruma.core.world.WorldVariant;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.apache.logging.log4j.LogManager;
import org.jetbrains.annotations.Nullable;

public final class ClientCatalog {
    static final List<DatLayout> SKILLS = layouts(
            "i:id i:level i i i:range i:style f:hit i:kind U:anim U:effect U:icon i i i i i i",
            "i:id i:level i i i i:range i:style f:hit i:kind U:anim U:effect U:icon U i i i i i i",
            "i:id i:level i i i i:range i:style f:hit i:kind U:anim U:effect U:icon U i i i A i i i i A",
            "H:id b:level H b b b h i:range b:style f:hit f f i b:kind h b L(N:anim+) N:effect N:icon i b b b i h b b",
            "i:id i:level i i i:range i:style f:hit i:kind U:anim U:effect U:icon i");

    static final List<DatLayout> NPC_SKILL_ANIMATIONS = layouts("i:npc i:skill U:anim A A A", "i:npc i:skill N:anim");

    static final List<DatLayout> SKILL_NAMES = layouts("i:id i:level A:name A:desc A A", "i:id i:level A:name A:desc");

    private static final List<DatLayout> ITEM_NAMES = layouts(
            "i:id U:name U:add A:desc i",
            "i:id U:name U:add A:desc i A A A A b b i A",
            "i:id U:name U:add A:desc i i LU A i LU A s9 i A i",
            "i:id N:name A:add A:desc h A i h b i s7");
    private static final List<DatLayout> ETC_ITEMS = List.of(
            LegacyGrp.ETC_ITEMS.get(0),
            LegacyGrp.ETC_ITEMS.get(1),
            LegacyGrp.ETC_ITEMS.get(2),
            new DatLayout("b i:id s4 B(i Bi) N:icon i i i i h h b b BH b b h i i b Bi Bi i i s6"));

    private static final List<DatLayout> COMBOS =
            layouts("N:name A:first A:second A:third i:loop", "U:name A:first A:second A:third i:loop");
    private static final List<DatLayout> NPC_NAMES = layouts("i:id A:name A:title i");
    private static final Map<String, String> TEXT_FIELDS = Map.of(
            "object_id",
            "id",
            "skill_id",
            "id",
            "skill_level",
            "level",
            "description",
            "desc",
            "nick",
            "title",
            "hit_time",
            "hit",
            "cast_range",
            "range",
            "cast_style",
            "style",
            "is_magic",
            "kind",
            "animation",
            "anim");
    private static final Set<String> TEXT_NUMBERS = Set.of("id", "level", "range", "style", "kind");

    private final Map<Integer, Item> items;
    private final Map<Integer, TreeMap<Integer, Skill>> skills;
    private final Map<Integer, Npc> npcs;
    private final List<String> notes;
    private final Map<Integer, TreeMap<Integer, Cast>> casts;
    private final Map<String, Combo> combos;
    private final SkillSounds sounds;
    private final Map<Long, String> npcAnimations;

    private ClientCatalog(
            Map<Integer, Item> items,
            Map<Integer, TreeMap<Integer, Skill>> skills,
            Map<Integer, Npc> npcs,
            List<String> notes) {
        this(items, skills, npcs, notes, Map.of(), Map.of(), SkillSounds.EMPTY, Map.of());
    }

    private ClientCatalog(
            Map<Integer, Item> items,
            Map<Integer, TreeMap<Integer, Skill>> skills,
            Map<Integer, Npc> npcs,
            List<String> notes,
            Map<Integer, TreeMap<Integer, Cast>> casts,
            Map<String, Combo> combos,
            SkillSounds sounds,
            Map<Long, String> npcAnimations) {
        this.items = items;
        this.skills = skills;
        this.npcs = npcs;
        this.notes = List.copyOf(notes);
        this.casts = casts;
        this.combos = combos;
        this.sounds = sounds;
        this.npcAnimations = npcAnimations;
    }

    public record Item(int id, String name, String addName, String description, String icon) {}

    public record Skill(int id, int level, String name, String description, String icon) {}

    public record Npc(int id, String name, String title) {}

    public record Cast(float seconds, List<String> animations, int kind, int range, int style, String effect) {
        public static final int PHYSICAL = 0;
        public static final int MAGIC = 1;
        public static final int STATIC = 2;
        public static final int DANCE = 3;

        public static final int BASE_SPEED = 333;

        public Cast {
            animations = List.copyOf(animations);
        }

        public Cast(float seconds, List<String> animations, int kind, int range) {
            this(seconds, animations, kind, range, -1, "");
        }

        public boolean magic() {
            return kind == MAGIC;
        }

        public boolean fixed() {
            return kind == STATIC;
        }

        public boolean onSelf() {
            return range < 0;
        }

        public float speedFactor(int speed) {
            return fixed() || speed <= 0 ? 1f : speed / (float) BASE_SPEED;
        }
    }

    public record Combo(String name, List<String> parts, int loop) {}

    public record SkillSound(String sound, Moment moment, boolean onTarget, float volume, float radius, float delay) {
        public enum Moment {
            CAST,
            SHOT,
            HIT
        }
    }

    public static ClientCatalog empty() {
        return new ClientCatalog(Map.of(), Map.of(), Map.of(), List.of());
    }

    public static ClientCatalog read(Path client) {
        return read(client, WorldVariant.MAIN);
    }

    public static ClientCatalog read(Path client, WorldVariant variant) {
        var system = client.resolve("system");
        var notes = new ArrayList<String>();
        List<String> names = List.of();
        var namesFile = variant.find(system, "L2GameDataName.dat");
        if (namesFile != null) {
            try {
                names = gameDataNames(L2DataFile.read(namesFile));
            } catch (IOException | RuntimeException failure) {
                notes.add("L2GameDataName.dat: " + failure.getMessage());
            }
        }
        var casts = new HashMap<Integer, TreeMap<Integer, Cast>>();
        return new ClientCatalog(
                loadItems(system, variant, names, notes),
                loadSkills(system, variant, names, notes, casts),
                loadNpcs(system, variant, notes),
                notes,
                casts,
                loadCombos(system, variant, names, notes),
                SkillSounds.read(system, variant, names, notes),
                loadNpcAnimations(system, variant, names, notes));
    }

    static Map<Integer, TreeMap<Integer, Cast>> castsOf(List<Map<String, Object>> records) {
        var casts = new HashMap<Integer, TreeMap<Integer, Cast>>();
        for (var record : records) {
            if (!(record.get("hit") instanceof Float seconds)) {
                continue;
            }
            var written = switch (record.get("anim")) {
                case String name -> List.<Object>of(name);
                case List<?> list -> list;
                case null, default -> List.of();
            };
            var animations = new ArrayList<String>();
            for (var name : written) {
                var animation = String.valueOf(name);
                if (!animation.isBlank() && !animation.equalsIgnoreCase("None") && !animations.contains(animation)) {
                    animations.add(animation);
                }
            }
            var kind = record.get("kind") instanceof Integer value ? value : -1;
            var range = record.get("range") instanceof Integer value ? value : 0;
            var style = record.get("style") instanceof Integer value ? value : -1;
            var effect = record.get("effect") == null ? "" : String.valueOf(record.get("effect"));
            casts.computeIfAbsent((Integer) record.get("id"), unused -> new TreeMap<>())
                    .putIfAbsent(
                            (Integer) record.get("level"), new Cast(seconds, animations, kind, range, style, effect));
        }
        return casts;
    }

    static String fillDescription(String description, String values) {
        if (values.isBlank() || !description.contains("$s")) {
            return description;
        }
        var parts = values.split(";");
        var out = description;
        for (var i = parts.length; i >= 1; i--) {
            out = out.replace("$s" + i, parts[i - 1].strip());
        }
        return out;
    }

    static List<Map<String, Object>> readTable(
            Path system,
            WorldVariant variant,
            String name,
            List<DatLayout> layouts,
            List<String> names,
            List<String> notes) {
        var file = variant.find(system, name);
        if (file == null) {
            return readTextTable(system, variant, name.substring(0, name.length() - ".dat".length()) + ".txt", notes);
        }
        byte[] bytes;
        try {
            bytes = L2DataFile.read(file);
        } catch (IOException | RuntimeException failure) {
            notes.add(name + ": " + failure.getMessage());
            return List.of();
        }
        var failures = new ArrayList<String>();
        for (var layout : layouts) {
            if (layout.toString().contains("N") && names.isEmpty()) {
                continue;
            }
            try {
                return layout.read(bytes, names);
            } catch (RuntimeException failure) {
                failures.add(failure.getMessage());
            }
        }
        notes.add(name + " matches no known layout");
        LogManager.getLogger(ClientCatalog.class).warn("{} matches no known layout: {}", file, failures);
        return List.of();
    }

    public static List<String> gameDataNames(byte[] bytes) {
        var data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        var count = data.getInt();
        var names = new ArrayList<String>(Math.max(0, count));
        for (var i = 0; i < count && data.remaining() >= 4; i++) {
            var length = data.getInt(data.position());
            if (length < 0 || length > data.remaining() - 4 || (length & 1) != 0) {
                break;
            }
            names.add(DatLayout.readUnicode(data));
        }
        return names;
    }

    static String findLocalizedTable(Path system, WorldVariant variant, String table) {
        if (variant != WorldVariant.MAIN) {
            var own = findLocalizedTable(system, WorldVariant.MAIN, table + variant.getSuffix());
            if (find(system, own) != null) {
                return own;
            }
        }
        var english = table + "-e.dat";
        if (find(system, english) != null) {
            return english;
        }
        try (var entries = Files.list(system)) {
            var prefix = (table + "-").toLowerCase(Locale.ROOT);
            return entries.map(path -> path.getFileName().toString())
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix)
                            && name.toLowerCase(Locale.ROOT).endsWith(".dat"))
                    .sorted()
                    .findFirst()
                    .orElse(english);
        } catch (IOException | RuntimeException unreadable) {
            return english;
        }
    }

    public @Nullable Item getItem(int id) {
        return items.get(id);
    }

    public @Nullable Skill getSkill(int id, int level) {
        var levels = skills.get(id);
        if (levels == null) {
            return null;
        }
        var entry = levels.floorEntry(level);
        return entry != null ? entry.getValue() : levels.firstEntry().getValue();
    }

    public @Nullable Cast getCast(int id, int level) {
        var levels = casts.get(id);
        if (levels == null) {
            return null;
        }
        var entry = levels.floorEntry(level);
        return entry != null ? entry.getValue() : levels.firstEntry().getValue();
    }

    public boolean hasLevel(int id, int level) {
        var levels = casts.containsKey(id) ? casts.get(id) : skills.get(id);
        return levels != null && levels.containsKey(level);
    }

    public List<Skill> getSkillsAtLevelOne() {
        var all = new ArrayList<Skill>(skills.size());
        for (var levels : skills.values()) {
            var first = levels.get(1);
            if (first != null && hasLevel(first.id(), 1)) {
                all.add(first);
            }
        }
        all.sort(
                Comparator.comparing(Skill::name, String.CASE_INSENSITIVE_ORDER).thenComparingInt(Skill::id));
        return all;
    }

    public int getTwinAtLevelOne(int id) {
        var named = getSkill(id, 1);
        if (named == null || named.name().isBlank()) {
            return 0;
        }
        var twin = 0;
        for (var levels : skills.values()) {
            var first = levels.get(1);
            if (first != null
                    && first.id() != id
                    && first.name().equals(named.name())
                    && hasLevel(first.id(), 1)
                    && (twin == 0 || first.id() < twin)) {
                twin = first.id();
            }
        }
        return twin;
    }

    public int getLastCastLevel(int id) {
        var levels = casts.get(id);
        return levels == null ? 0 : levels.lastKey();
    }

    public @Nullable Combo getCombo(String name) {
        return combos.get(name.toLowerCase(Locale.ROOT));
    }

    public @Nullable String getNpcSkillAnimation(int npc, int skill) {
        return npcAnimations.get(skillKey(npc, skill));
    }

    public List<SkillSound> getSkillSounds(int id, int level, @Nullable String figure) {
        return sounds.of(id, level, figure);
    }

    public @Nullable Npc getNpc(int id) {
        return npcs.get(id);
    }

    public Collection<Item> getItems() {
        return Collections.unmodifiableCollection(items.values());
    }

    public List<Skill> getSkills() {
        var all = new ArrayList<Skill>(skills.size());
        for (var levels : skills.values()) {
            all.add(levels.firstEntry().getValue());
        }
        return all;
    }

    public int getLevels(int id) {
        var levels = skills.get(id);
        return levels == null ? 0 : levels.size();
    }

    public int getItemCount() {
        return items.size();
    }

    public int getSkillCount() {
        return skills.size();
    }

    public int getNpcCount() {
        return npcs.size();
    }

    public Collection<Npc> getNpcs() {
        return Collections.unmodifiableCollection(npcs.values());
    }

    public List<String> getNotes() {
        return notes;
    }

    private static Map<Integer, Item> loadItems(
            Path system, WorldVariant variant, List<String> names, List<String> notes) {
        var icons = new HashMap<Integer, String>();
        for (var record : readTable(system, variant, "EtcItemgrp.dat", ETC_ITEMS, names, notes)) {
            icons.putIfAbsent((Integer) record.get("id"), (String) record.get("icon"));
        }
        var p152Weapons = false;
        if (variant.find(system, "Weapongrp.dat") != null) {
            try {
                WeaponGrpTable.read(system, variant).getIcons().forEach(icons::putIfAbsent);
                p152Weapons = true;
            } catch (IOException | RuntimeException notP152) {
            }
        }
        if (!p152Weapons) {
            for (var record : readTable(system, variant, "Weapongrp.dat", LegacyGrp.WEAPONS, names, notes)) {
                icons.putIfAbsent((Integer) record.get("id"), (String) record.get("icon"));
            }
        }
        var p152Armors = false;
        if (variant.find(system, "Armorgrp.dat") != null) {
            try {
                ArmorGrpTable.read(system, variant).getIcons().forEach(icons::putIfAbsent);
                p152Armors = true;
            } catch (IOException | RuntimeException notP152) {
            }
        }
        if (!p152Armors) {
            for (var record : readTable(system, variant, "Armorgrp.dat", LegacyGrp.ARMORS, names, notes)) {
                icons.putIfAbsent((Integer) record.get("id"), (String) record.get("icon"));
            }
        }
        var items = new HashMap<Integer, Item>();
        for (var record :
                readTable(system, variant, findLocalizedTable(system, variant, "ItemName"), ITEM_NAMES, names, notes)) {
            var id = (Integer) record.get("id");
            items.putIfAbsent(
                    id,
                    new Item(
                            id,
                            (String) record.get("name"),
                            (String) record.getOrDefault("add", ""),
                            cleanDescription((String) record.get("desc")),
                            cleanIconName(icons.get(id))));
        }
        icons.forEach((id, icon) -> items.putIfAbsent(id, new Item(id, "", "", "", cleanIconName(icon))));
        return items;
    }

    private static Map<Integer, TreeMap<Integer, Skill>> loadSkills(
            Path system,
            WorldVariant variant,
            List<String> names,
            List<String> notes,
            Map<Integer, TreeMap<Integer, Cast>> casts) {
        var icons = new HashMap<Long, String>();
        var grp = readTable(system, variant, "Skillgrp.dat", SKILLS, names, notes);
        for (var record : grp) {
            icons.putIfAbsent(
                    skillKey((Integer) record.get("id"), (Integer) record.get("level")), (String) record.get("icon"));
        }
        casts.putAll(castsOf(grp));
        var texts = new HashMap<Long, String[]>();
        var skillNames = findLocalizedTable(system, variant, "SkillName");
        var file = variant.find(system, skillNames);
        if (file == null) {
            for (var record : readTable(system, variant, skillNames, SKILL_NAMES, names, notes)) {
                texts.putIfAbsent(
                        skillKey((Integer) record.get("id"), (Integer) record.get("level")),
                        new String[] {(String) record.get("name"), (String) record.get("desc"), ""});
            }
        } else {
            try {
                var bytes = L2DataFile.read(file);
                List<Map<String, Object>> records = null;
                for (var layout : SKILL_NAMES) {
                    try {
                        records = layout.read(bytes, names);
                        break;
                    } catch (RuntimeException otherLayout) {
                    }
                }
                if (records == null) {
                    records = indexedSkillNames(bytes);
                }
                for (var record : records) {
                    texts.putIfAbsent(
                            skillKey((Integer) record.get("id"), (Integer) record.get("level")), new String[] {
                                (String) record.get("name"),
                                (String) record.get("desc"),
                                (String) record.getOrDefault("values", "")
                            });
                }
            } catch (IOException | RuntimeException failure) {
                notes.add("SkillName-e.dat: " + failure.getMessage());
            }
        }
        var skills = new HashMap<Integer, TreeMap<Integer, Skill>>();
        var values = new HashMap<Long, String>();
        var keys = new HashSet<Long>(icons.keySet());
        keys.addAll(texts.keySet());
        for (var key : keys) {
            var id = (int) (key >>> 32);
            var level = (int) (key & 0xffffffffL);
            var text = texts.getOrDefault(key, new String[] {"", "", ""});
            values.put(key, text[2]);
            skills.computeIfAbsent(id, unused -> new TreeMap<>())
                    .put(
                            level,
                            new Skill(
                                    id,
                                    level,
                                    text[0],
                                    cleanDescription(text[1]),
                                    cleanIconName(icons.getOrDefault(key, ""))));
        }
        for (var levels : skills.values()) {
            var description = "";
            var name = "";
            var icon = "";
            for (var entry : levels.entrySet()) {
                var skill = entry.getValue();
                description = skill.description().isEmpty() ? description : skill.description();
                name = skill.name().isEmpty() ? name : skill.name();
                icon = skill.icon().isEmpty() ? icon : skill.icon();
                entry.setValue(new Skill(
                        skill.id(),
                        skill.level(),
                        name,
                        fillDescription(description, values.getOrDefault(skillKey(skill.id(), skill.level()), "")),
                        icon));
            }
        }
        return skills;
    }

    private static Map<Long, String> loadNpcAnimations(
            Path system, WorldVariant variant, List<String> names, List<String> notes) {
        if (variant.find(system, "MobSkillAnimgrp.dat") == null) {
            return Map.of();
        }
        var animations = new HashMap<Long, String>();
        for (var record : readTable(system, variant, "MobSkillAnimgrp.dat", NPC_SKILL_ANIMATIONS, names, notes)) {
            if (record.get("anim") instanceof String name && !name.isBlank() && !name.equalsIgnoreCase("None")) {
                animations.putIfAbsent(
                        skillKey((Integer) record.get("npc"), (Integer) record.get("skill")), name.trim());
            }
        }
        return animations;
    }

    private static Map<String, Combo> loadCombos(
            Path system, WorldVariant variant, List<String> names, List<String> notes) {
        var records = variant.find(system, "AnimationCombo.dat") == null
                ? List.<Map<String, Object>>of()
                : readTable(system, variant, "AnimationCombo.dat", COMBOS, names, notes);
        var combos = new HashMap<String, Combo>();
        if (records.isEmpty()) {
            for (var combo : SkillCombos.BUILT_IN) {
                combos.put(combo.name().toLowerCase(Locale.ROOT), combo);
            }
            return combos;
        }
        for (var record : records) {
            var parts = new ArrayList<String>();
            for (var key : List.of("first", "second", "third")) {
                var part = SkillCombos.part((String) record.get(key));
                if (!part.isEmpty()) {
                    parts.add(part);
                }
            }
            var name = String.valueOf(record.get("name"));
            combos.putIfAbsent(
                    name.toLowerCase(Locale.ROOT), new Combo(name, List.copyOf(parts), (Integer) record.get("loop")));
        }
        return combos;
    }

    private static List<Map<String, Object>> indexedSkillNames(byte[] bytes) {
        var data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        var count = DatLayout.compact(data);
        if (count < 0 || count > 1_000_000) {
            throw new IllegalArgumentException("string table of " + count);
        }
        var strings = new ArrayList<String>(count);
        for (var i = 0; i < count; i++) {
            strings.add(DatLayout.ascf(data));
            data.getInt();
        }
        var records = data.getInt();
        return new DatLayout("H:id b:level H N:name N:desc N:values N N N N").read(data, records, strings);
    }

    private static Map<Integer, Npc> loadNpcs(Path system, WorldVariant variant, List<String> notes) {
        var npcs = new HashMap<Integer, Npc>();
        for (var record : readTable(
                system, variant, findLocalizedTable(system, variant, "NpcName"), NPC_NAMES, List.of(), notes)) {
            var id = (Integer) record.get("id");
            npcs.putIfAbsent(id, new Npc(id, (String) record.get("name"), (String) record.get("title")));
        }
        return npcs;
    }

    private static List<Map<String, Object>> readTextTable(
            Path system, WorldVariant variant, String name, List<String> notes) {
        var file = variant.find(system, name);
        if (file == null) {
            return List.of();
        }
        List<Map<String, String>> rows;
        try {
            rows = L2TextTable.read(file);
        } catch (IOException | RuntimeException failure) {
            notes.add(name + ": " + failure.getMessage());
            return List.of();
        }
        var records = new ArrayList<Map<String, Object>>(rows.size());
        for (var row : rows) {
            var record = new HashMap<String, Object>();
            for (var field : row.entrySet()) {
                var key = TEXT_FIELDS.getOrDefault(field.getKey(), field.getKey());
                var value = field.getValue();
                if (TEXT_NUMBERS.contains(key)) {
                    try {
                        record.put(key, Integer.parseInt(value));
                    } catch (NumberFormatException notANumber) {
                        record.put(key, -1);
                    }
                } else if (key.equals("hit")) {
                    try {
                        record.put(key, Float.parseFloat(value));
                    } catch (NumberFormatException notANumber) {
                    }
                } else if (value.startsWith("{")) {
                    var list = L2TextTable.names(value);
                    record.put(key, list.isEmpty() ? "" : list.getFirst());
                } else {
                    record.put(key, L2TextTable.name(value));
                }
            }
            if (record.get("id") instanceof Integer id && id >= 0) {
                records.add(record);
            }
        }
        return records;
    }

    private static List<DatLayout> layouts(String... specs) {
        var layouts = new ArrayList<DatLayout>();
        for (var spec : specs) {
            layouts.add(new DatLayout(spec));
        }
        return List.copyOf(layouts);
    }

    private static long skillKey(int id, int level) {
        return (long) id << 32 | (level & 0xffffffffL);
    }

    private static String cleanIconName(@Nullable String name) {
        return name == null || name.equalsIgnoreCase("None") ? "" : name.strip();
    }

    private static String cleanDescription(@Nullable String text) {
        return text == null ? "" : text.replace("\\n", "\n").strip();
    }

    private static @Nullable Path find(Path folder, String name) {
        if (!Files.isDirectory(folder)) {
            return null;
        }
        try (var entries = Files.list(folder)) {
            return entries.filter(path -> path.getFileName().toString().equalsIgnoreCase(name))
                    .findFirst()
                    .orElse(null);
        } catch (IOException unreadable) {
            return null;
        }
    }
}
