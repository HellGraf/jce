package com.rost.cruma.core.npc;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class DatLayout {
    private final String spec;
    private final List<Field> fields;

    DatLayout(String spec) {
        this.spec = spec;
        var tokens = new Tokens(spec);
        this.fields = tokens.parseFields(false);
    }

    private sealed interface Field permits Scalar, Skip, Repeat {}

    private record Scalar(char type, String name, boolean list) implements Field {}

    private record Skip(int bytes) implements Field {}

    private record Repeat(char count, String name, List<Field> fields) implements Field {}

    static String readUnicode(ByteBuffer data) {
        var bytes = data.getInt();
        if (bytes < 0 || bytes > 65536 || (bytes & 1) != 0) {
            throw new IllegalStateException("string of " + bytes + " bytes");
        }
        var value = new byte[bytes];
        data.get(value);
        return trimNulls(new String(value, StandardCharsets.UTF_16LE));
    }

    static String ascf(ByteBuffer data) {
        var length = compact(data);
        if (Math.abs(length) > 65536) {
            throw new IllegalStateException("string of " + length + " characters");
        }
        var bytes = new byte[length < 0 ? -length * 2 : length];
        data.get(bytes);
        return trimNulls(new String(bytes, length < 0 ? StandardCharsets.UTF_16LE : StandardCharsets.ISO_8859_1));
    }

    static int compact(ByteBuffer data) {
        var first = data.get() & 0xff;
        var value = first & 0x3f;
        if ((first & 0x40) != 0) {
            var shift = 6;
            int next;
            do {
                next = data.get() & 0xff;
                value |= (next & 0x7f) << shift;
                shift += 7;
            } while ((next & 0x80) != 0 && shift < 32);
        }
        return (first & 0x80) != 0 ? -value : value;
    }

    List<Map<String, Object>> read(byte[] table, List<String> names) {
        var data = ByteBuffer.wrap(table).order(ByteOrder.LITTLE_ENDIAN);
        var count = data.getInt();
        if (count < 0 || count > 2_000_000) {
            throw new IllegalArgumentException(spec + ": record count " + count);
        }
        return read(data, count, names);
    }

    List<Map<String, Object>> read(ByteBuffer data, int count, List<String> names) {
        var records = new ArrayList<Map<String, Object>>(count);
        for (var i = 0; i < count; i++) {
            var start = data.position();
            var record = new HashMap<String, Object>(8);
            try {
                read(data, fields, record, names);
            } catch (RuntimeException failure) {
                if (i >= 100 && i >= count * 99L / 100) {
                    return records;
                }
                throw new IllegalArgumentException(
                        spec + ": record " + i + " at " + start + ": " + failure.getMessage(), failure);
            }
            records.add(record);
        }
        if (data.remaining() > 32) {
            throw new IllegalArgumentException(
                    spec + ": " + data.remaining() + " bytes left after " + count + " records");
        }
        return records;
    }

    @Override
    public String toString() {
        return spec;
    }

    private static final class Tokens {
        private final String spec;
        private int at;

        Tokens(String spec) {
            this.spec = spec;
        }

        List<Field> parseFields(boolean group) {
            var fields = new ArrayList<Field>();
            while (true) {
                while (at < spec.length() && spec.charAt(at) == ' ') {
                    at++;
                }
                if (at >= spec.length()) {
                    if (group) {
                        throw new IllegalArgumentException("Missing ')' in " + spec);
                    }
                    return fields;
                }
                if (spec.charAt(at) == ')') {
                    if (!group) {
                        throw new IllegalArgumentException("Unexpected ')' in " + spec);
                    }
                    at++;
                    return fields;
                }
                fields.add(parseField());
            }
        }

        private Field parseField() {
            var c = spec.charAt(at++);
            if (c == 'L' || c == 'B' || c == 'C' || c == '*') {
                String name = null;
                if (c == '*' || at < spec.length() && spec.charAt(at) == '=') {
                    if (c != '*') {
                        at++;
                    }
                    var start = at;
                    while (at < spec.length() && Character.isLetterOrDigit(spec.charAt(at))) {
                        at++;
                    }
                    name = spec.substring(start, at);
                }
                while (at < spec.length() && spec.charAt(at) == ' ') {
                    at++;
                }
                if (at < spec.length() && spec.charAt(at) == '(') {
                    at++;
                    return new Repeat(c, name, parseFields(true));
                }
                return new Repeat(c, name, List.of(parseField()));
            }
            if (c == 's') {
                var start = at;
                while (at < spec.length() && Character.isDigit(spec.charAt(at))) {
                    at++;
                }
                return new Skip(Integer.parseInt(spec.substring(start, at)));
            }
            if ("ihHbfUAN".indexOf(c) < 0) {
                throw new IllegalArgumentException("Unknown field '" + c + "' in " + spec);
            }
            String name = null;
            var list = false;
            if (at < spec.length() && spec.charAt(at) == ':') {
                var start = ++at;
                while (at < spec.length() && Character.isLetterOrDigit(spec.charAt(at))) {
                    at++;
                }
                name = spec.substring(start, at);
                if (at < spec.length() && spec.charAt(at) == '+') {
                    at++;
                    list = true;
                }
            }
            return new Scalar(c, name, list);
        }
    }

    private static void read(ByteBuffer data, List<Field> fields, Map<String, Object> record, List<String> names) {
        for (var field : fields) {
            switch (field) {
                case Skip(var bytes) -> data.position(data.position() + bytes);
                case Repeat(var count, var name, var inner) -> {
                    var times = switch (count) {
                        case 'L' -> data.getInt();
                        case 'B' -> data.get() & 0xff;
                        case 'C' -> compact(data);
                        default -> (Integer) record.get(name);
                    };
                    if (count != '*' && name != null) {
                        record.put(name, times);
                    }
                    if (times < 0 || times > 100_000) {
                        throw new IllegalStateException("list of " + times);
                    }
                    for (var i = 0; i < times; i++) {
                        read(data, inner, record, names);
                    }
                }
                case Scalar(var type, var name, var list) -> {
                    var value = readScalar(data, type, names);
                    if (name != null && list) {
                        @SuppressWarnings("unchecked")
                        var values = (List<Object>) record.computeIfAbsent(name, ignored -> new ArrayList<>());
                        values.add(value);
                    } else if (name != null) {
                        record.put(name, value);
                    }
                }
            }
        }
    }

    private static Object readScalar(ByteBuffer data, char type, List<String> names) {
        return switch (type) {
            case 'i' -> data.getInt();
            case 'h' -> (int) data.getShort();
            case 'H' -> data.getShort() & 0xffff;
            case 'b' -> data.get() & 0xff;
            case 'f' -> data.getFloat();
            case 'U' -> readUnicode(data);
            case 'A' -> ascf(data);
            case 'N' -> {
                var index = data.getInt();
                if (index < -1 || index >= names.size()) {
                    throw new IllegalStateException("name index " + index);
                }
                yield index < 0 ? "" : names.get(index);
            }
            default -> throw new IllegalStateException("field " + type);
        };
    }

    private static String trimNulls(String text) {
        var end = text.length();
        while (end > 0 && text.charAt(end - 1) == '\0') {
            end--;
        }
        return text.substring(0, end);
    }
}
