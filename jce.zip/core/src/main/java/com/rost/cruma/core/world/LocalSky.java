package com.rost.cruma.core.world;

import java.util.List;

public record LocalSky(USky sky, List<SpriteEmitterDescriptor> sprites) {
    public LocalSky {
        sprites = List.copyOf(sprites);
    }
}
