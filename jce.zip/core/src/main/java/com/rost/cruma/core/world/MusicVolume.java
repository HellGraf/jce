package com.rost.cruma.core.world;

import com.rost.cruma.core.unreal.Bsp.UModel;
import glm_.mat4x4.Mat4;
import glm_.vec3.Vec3;

public final class MusicVolume {
    private final String name;
    private final BrushVolume shape;
    private final int musicId;
    private final boolean forcePlay;
    private final boolean loop;
    private final boolean hasNightMusic;
    private final int nightMusicId;

    public MusicVolume(
            UModel brush,
            Mat4 brushToWorld,
            int musicId,
            boolean forcePlay,
            boolean loop,
            boolean hasNightMusic,
            int nightMusicId) {
        this("", new BrushVolume(brush, brushToWorld), musicId, forcePlay, loop, hasNightMusic, nightMusicId);
    }

    public MusicVolume(
            BrushVolume shape, int musicId, boolean forcePlay, boolean loop, boolean hasNightMusic, int nightMusicId) {
        this("", shape, musicId, forcePlay, loop, hasNightMusic, nightMusicId);
    }

    public MusicVolume(
            String name,
            BrushVolume shape,
            int musicId,
            boolean forcePlay,
            boolean loop,
            boolean hasNightMusic,
            int nightMusicId) {
        if (shape == null) {
            throw new IllegalArgumentException("a MusicVolume needs its brush");
        }
        this.name = name;
        this.shape = shape;
        this.musicId = musicId;
        this.forcePlay = forcePlay;
        this.loop = loop;
        this.hasNightMusic = hasNightMusic;
        this.nightMusicId = nightMusicId;
    }

    public boolean contains(Vec3 point) {
        return shape.contains(point);
    }

    public String getName() {
        return name;
    }

    public BrushVolume getShape() {
        return shape;
    }

    public int getMusicId() {
        return musicId;
    }

    public boolean isForcePlay() {
        return forcePlay;
    }

    public boolean isLoop() {
        return loop;
    }

    public boolean hasNightMusic() {
        return hasNightMusic;
    }

    public int getNightMusicId() {
        return nightMusicId;
    }

    public int getMusicIdAt(boolean night) {
        return night && hasNightMusic ? nightMusicId : musicId;
    }

    @Override
    public String toString() {
        return "MusicVolume{music="
                + musicId
                + (hasNightMusic ? ", night=" + nightMusicId : "")
                + (loop ? ", loop" : "")
                + (forcePlay ? ", force" : "")
                + "}";
    }
}
