package com.rost.cruma.core.world;

import com.rost.cruma.core.unreal.EffectClasses.Effect;
import java.util.List;

public record EffectParts(
        Effect effect,
        List<SpriteEmitterDescriptor> sprites,
        List<MeshEmitterDescriptor> meshes,
        List<BeamEmitterDescriptor> beams,
        boolean setsSizeScale) {
    public EffectParts {
        sprites = List.copyOf(sprites);
        meshes = List.copyOf(meshes);
        beams = List.copyOf(beams);
    }

    public EffectParts(
            Effect effect,
            List<SpriteEmitterDescriptor> sprites,
            List<MeshEmitterDescriptor> meshes,
            List<BeamEmitterDescriptor> beams) {
        this(effect, sprites, meshes, beams, true);
    }

    public boolean isEmpty() {
        return sprites.isEmpty() && meshes.isEmpty() && beams.isEmpty();
    }

    public int count() {
        return sprites.size() + meshes.size() + beams.size();
    }
}
